plugin.video.serviziopubblico
=======================

Kodi unofficial plugin for Servizio Pubblico (tested on Kodi 15.1 Isengard).
