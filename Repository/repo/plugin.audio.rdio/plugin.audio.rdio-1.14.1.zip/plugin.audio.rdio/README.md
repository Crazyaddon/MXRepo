Rdio for Kodi
=============

Rdio for Kodi is an Kodi add-on that allows you to play your [Rdio](http://www.rdio.com) music collection through the [Kodi](http://kodi.tv) media centre.

For information on installing and using this add-on, please visit the [rdio-xbmc wiki](https://github.com/ampedandwired/rdio-xbmc/wiki).

If you find this plugin useful, please consider making a donation.

[![Click here to lend your support to Rdio Kodi and make a donation at www.pledgie.com](http://www.pledgie.com/campaigns/18296.png?skin_name=chrome "Make a donation")](http://www.pledgie.com/campaigns/18296)
