plugin.audio.resetradio
=================

XBMC plugin for Reset Radio (tested on XBMC 13.1 Gotham)

You may need to download the dependencies of this addon:
- script.module.neverwise 1.0.3 (https://github.com/NeverWise/script.module.neverwise/archive/master.zip)
- script.module.chardet 2.1.2 (http://mirrors.xbmc.org/addons/frodo/script.module.chardet/script.module.chardet-2.1.2.zip)
- script.module.beautifulsoup 3.2.1 (http://mirrors.xbmc.org/addons/frodo/script.module.beautifulsoup/script.module.beautifulsoup-3.2.1.zip)
- script.module.parsedom 2.5.2 (http://mirrors.xbmc.org/addons/frodo/script.module.parsedom/script.module.parsedom-2.5.2.zip)
