plugin.video.tubitv
================

Kodi V2 Addon for tubitv
For Kodi Isgengard and later releases

V2.0.7 fix for website change
V2.0.6 fix for website change
V2.0.5 cleanup for release
V2.0.4 fix for new url scramble
V2.0.3 fix for metadata - reset metadata in settings before running
V2.0.2 fix for release
V2.0.1 initial v2 release

