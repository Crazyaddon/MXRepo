plugin.video.gq
================

Kodi Addon for GQ website

version 1.0.1 initial release
1.0.2 - added HD resolution select setting
1.0.3 - changed static strings to translatable strings
1.0.4 - fixed the fix above
1.0.5 - website changes
1.0.6 - website changes
1.0.7 - Added metadata and views
