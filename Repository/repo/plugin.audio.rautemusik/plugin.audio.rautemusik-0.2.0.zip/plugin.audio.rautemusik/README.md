RauteMusik  Plugin
==================

About
-----

The RauteMusik Plugin integrates all radio stations of [RauteMusik
Internetradio] [1] into XBMC. RauteMusik.FM was founded in 2003 and has become
one of the largest internet radio networks in Europe. More than 300 members are
working hard in providing the best music of the last years and the current
charts.

Prerequisites
-------------

You need a working internet connection.

License
-------
This software is released under the [GPL 2.0 license] [2].

Useful Links
-------------

Official Repository Page: http://addons.xbmc.org/show/plugin.audio.rautemusik

Dedicated Repository: http://archive.yeasoft.net/repository.yeasoft.zip

Support Forum: http://forum.xbmc.org/showthread.php?tid=183456


[1]: http://rautemusik.fm
[2]: http://www.gnu.org/licenses/gpl-2.0.html
