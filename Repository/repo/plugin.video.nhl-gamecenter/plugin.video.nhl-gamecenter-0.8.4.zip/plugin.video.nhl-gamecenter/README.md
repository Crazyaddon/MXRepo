xbmc-nhl-gamecenter
===================

## Notes
+ Please note that this is not a way to view NHL Game's for free or anything like that. This addon simply allows someone with an active GCL Account to 
access games that they normally can online, through their XBMC.
+ In order to use GCL, please sign up at the following: 
https://gamecenter.nhl.com/nhlgc/secure/gclsignup

## Installation
1. Download the latest Release ZIP OR Master Zip from the side of the panel.
2. Place on XBMC machine or Samba share.
3. Go to Settings>Addons>Install from Zip.
4. Select final and install!

## Features
+ Live Games
+ Highlights
+ Archived Games
+ HD Video (720p)
+ View Home/Away Feeds

## Special Thanks
A bit shoutout goes to the original creator of this Addon, Carb0.