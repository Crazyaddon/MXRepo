# coding: utf-8
from time import time
from time import asctime
from time import localtime
from time import strftime
from time import gmtime

from peliculasaudiolatino import *
from xbmc import log
from xbmc import sleep
from xbmc import abortRequested
from xbmcaddon import Addon
import re


def update_service():
    settings = tools.Settings()
    if settings.service == 'true':
        # Begin Service
        if Addon().getSetting('peliculasEstreno') == "true":  # Peliculas Estreno
            movie = Movies()
            for page in range(1, settings.pages + 1):
                url_search = "%s/estrenos-2015/pagina/%s.html" % (settings.url_address, page)
                movie.searchMovie(url_search=url_search)
                if page % 5 == 0: sleep(1)
            if len(movie.titles) > 0:
                tools.int_pelisalacarta(channel="peliculasaudiolatino", titles=movie.titles, url=movie.url_list,
                                        type_list='MOVIE', silence=True,
                                        folder=settings.movie_folder, name_provider=settings.name_provider)

        elif Addon().getSetting('ultimasAgregadas') == "true":  # Últimas Agregadas',  #2
            movie = Movies()
            for page in range(1, settings.pages + 1):
                url_search = "%s/ultimas-agregadas/pagina/%s.html" % (settings.url_address, page)
                movie.searchMovie(url_search=url_search)
                if page % 5 == 0: sleep(1)
            if len(movie.titles) > 0:
                tools.int_pelisalacarta(channel="peliculasaudiolatino", titles=movie.titles, url=movie.url_list,
                                        type_list='MOVIE', silence=True,
                                        folder=settings.movie_folder, name_provider=settings.name_provider)

        elif Addon().getSetting('recienActualizadas') == "true":  # Recien Actualizadas',  # 3
            movie = Movies()
            for page in range(1, settings.pages + 1):
                url_search = "%s/recien-actualizadas/pagina/%s.html" % (settings.url_address, page)
                movie.searchMovie(url_search=url_search)
                if page % 5 == 0: sleep(1)
            if len(movie.titles) > 0:
                tools.int_pelisalacarta(channel="peliculasaudiolatino", titles=movie.titles, url=movie.url_list,
                                        type_list='MOVIE', silence=True,
                                        folder=settings.movie_folder, name_provider=settings.name_provider)

        elif Addon().getSetting('lasMasVistas') == "true":  # Las Más Vistas',  # 4
            movie = Movies()
            for page in range(1, settings.pages + 1):
                url_search = "%s/las-mas-vistas/pagina/%s.html" % (settings.url_address, page)
                movie.searchMovie(url_search=url_search)
                if page % 5 == 0: sleep(1)
            if len(movie.titles) > 0:
                tools.int_pelisalacarta(channel="peliculasaudiolatino", titles=movie.titles, url=movie.url_list,
                                        type_list='MOVIE', silence=True,
                                        folder=settings.movie_folder, name_provider=settings.name_provider)

        #update series
        elif Addon().getSetting('series') == "true":  # Las Más Vistas',  # 4
            for title, url in storage.database.iteritems():
                show = Shows()
                show.searchSerie(url)
                tools.int_pelisalacarta(channel="peliculasaudiolatino", titles=show.titles, url=show.url_list,
                                        type_list='SHOW', silence=True,
                                        folder=settings.show_folder, name_provider=settings.name_provider)
    del settings


if Addon().getSetting('service') == 'true':
    persistent = Addon().getSetting('persistent')
    name_provider = re.sub('.COLOR (.*?)]', '', Addon().getAddonInfo('name').replace('[/COLOR]', ''))
    every = 28800  # seconds
    previous_time = time()
    log("[%s]Update Service starting..." % name_provider)
    update_service()
    while (not abortRequested) and persistent == 'true':
        if time() >= previous_time + every:  # verification
            previous_time = time()
            update_service()
            log('[%s] Update List at %s' % (name_provider, asctime(localtime(previous_time))))
            log('[%s] Next Update in %s' % (name_provider, strftime("%H:%M:%S", gmtime(every))))
            update_service()
        sleep(500)
