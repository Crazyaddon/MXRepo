# coding: utf-8

from xbmc import sleep
from peliculasaudiolatino import *
from urllib import quote_plus

######################################
#############  MAIN MENU  ############
######################################
option_list = ['Busquedar Película',  #0
               '[COLOR FF2107a2]Películas[/COLOR] Estreno',  #1
               '[COLOR FF2107a2]Películas[/COLOR] Últimas Agregadas',  #2
               '[COLOR FF2107a2]Películas[/COLOR] Recien Actualizadas',  # 3
               '[COLOR FF2107a2]Películas[/COLOR] Las Más Vistas',  # 4
               '[COLOR FF2107a2]Películas[/COLOR] por Años',  # 5
               '[COLOR FF2107a2]Películas[/COLOR] por Géneros',  # 6
               'Todas las [COLOR FF2107a2]Películas[/COLOR]',  #7
               'Borrar una [COLOR FF2107a2]Película[/COLOR]',  #8
               'Todas las [COLOR FF07a221]Series[/COLOR]',  #9
               'Borrar una [COLOR FF07a221]Serie[/COLOR]']  #10
option_list.extend(['-CONFIGURACIÓN', '-AYUDA', 'Salir'])

ret = 0
while ret < len(option_list) - 1:
    ret = settings.dialog.select('Opción:', option_list)
    if ret == 0:  # Busqueda Manual
        search = settings.dialog.input('Palabras clave a buscar:')
        if search is not '':
            movie = Movies()
            url_search = '%s/busqueda.php?q=%s' % (settings.url_address, quote_plus(search))
            movie.searchMovie(url_search=url_search)
            rep = settings.dialog.select('Seleccionar tu opción:', movie.titles + ['CANCEL'])
            if rep < len(movie.titles):
                tools.int_pelisalacarta(channel="peliculasaudiolatino", titles=[movie.titles[rep]],
                                        url=[movie.url_list[rep]],
                                        type_list='MOVIE', folder=settings.movie_folder,
                                        name_provider=settings.name_provider)
    elif ret == 1:  # Peliculas Estreno
        movie = Movies()
        settings.pages = settings.dialog.numeric(0, 'Número de páginas a bajar:')
        if settings.pages == '' or settings.pages == 0:
            settings.pages = "1"
        settings.pages = int(settings.pages)

        optionUnica = settings.dialog.yesno("Selección", "Por favor escoga el tipo de selección", yeslabel="Individual",
                                            nolabel="Todas")
        for page in range(1, settings.pages + 1):
            url_search = "%s/estrenos-2015/pagina/%s.html" % (settings.url_address, page)
            movie.searchMovie(url_search=url_search)
            if page % 5 == 0: sleep(1)

        if optionUnica:
            rep = settings.dialog.select('Seleccionar tu opción:', movie.titles + ['CANCEL'])
            if rep < len(movie.titles):
                tools.int_pelisalacarta(channel="peliculasaudiolatino", titles=[movie.titles[rep]], url=[movie.url_list[rep]],
                                        type_list='MOVIE', folder=settings.movie_folder,
                                        name_provider=settings.name_provider)
        else:
            if len(movie.titles) > 0:
                tools.int_pelisalacarta(channel="peliculasaudiolatino", titles=movie.titles, url=movie.url_list, type_list='MOVIE',
                                        folder=settings.movie_folder, name_provider=settings.name_provider)
    elif ret == 2:  # Últimas Agregadas',  #2
        movie = Movies()
        settings.pages = settings.dialog.numeric(0, 'Número de páginas a bajar:')
        if settings.pages == '' or settings.pages == 0:
            settings.pages = "1"
        settings.pages = int(settings.pages)

        optionUnica = settings.dialog.yesno("Selección", "Por favor escoga el tipo de selección", yeslabel="Individual",
                                            nolabel="Todas")
        for page in range(1, settings.pages + 1):
            url_search = "%s/ultimas-agregadas/pagina/%s.html" % (settings.url_address, page)
            movie.searchMovie(url_search=url_search)
            if page % 5 == 0: sleep(1)

        if optionUnica:
            rep = settings.dialog.select('Seleccionar tu opción:', movie.titles + ['CANCEL'])
            if rep < len(movie.titles):
                tools.int_pelisalacarta(channel="peliculasaudiolatino", titles=[movie.titles[rep]], url=[movie.url_list[rep]],
                                        type_list='MOVIE', folder=settings.movie_folder,
                                        name_provider=settings.name_provider)
        else:
            if len(movie.titles) > 0:
                tools.int_pelisalacarta(channel="peliculasaudiolatino", titles=movie.titles, url=movie.url_list,
                                        type_list='MOVIE',
                                        folder=settings.movie_folder, name_provider=settings.name_provider)

    elif ret == 3:  # Recien Actualizadas',  # 3
        movie = Movies()
        settings.pages = settings.dialog.numeric(0, 'Número de páginas a bajar:')
        if settings.pages == '' or settings.pages == 0:
            settings.pages = "1"
        settings.pages = int(settings.pages)

        optionUnica = settings.dialog.yesno("Selección", "Por favor escoga el tipo de selección", yeslabel="Individual",
                                            nolabel="Todas")
        for page in range(1, settings.pages + 1):
            url_search = "%s/recien-actualizadas/pagina/%s.html" % (settings.url_address, page)
            movie.searchMovie(url_search=url_search)
            if page % 5 == 0: sleep(1)

        if optionUnica:
            rep = settings.dialog.select('Seleccionar tu opción:', movie.titles + ['CANCEL'])
            if rep < len(movie.titles):
                tools.int_pelisalacarta(channel="peliculasaudiolatino", titles=[movie.titles[rep]], url=[movie.url_list[rep]],
                                        type_list='MOVIE', folder=settings.movie_folder,
                                        name_provider=settings.name_provider)
        else:
            if len(movie.titles) > 0:
                tools.int_pelisalacarta(channel="peliculasaudiolatino", titles=movie.titles, url=movie.url_list,
                                        type_list='MOVIE',
                                        folder=settings.movie_folder, name_provider=settings.name_provider)

    elif ret == 4:  # Las Más Vistas',  # 4
        movie = Movies()
        settings.pages = settings.dialog.numeric(0, 'Número de páginas a bajar:')
        if settings.pages == '' or settings.pages == 0:
            settings.pages = "1"
        settings.pages = int(settings.pages)

        optionUnica = settings.dialog.yesno("Selección", "Por favor escoga el tipo de selección", yeslabel="Individual",
                                            nolabel="Todas")
        for page in range(1, settings.pages + 1):
            url_search = "%s/las-mas-vistas/pagina/%s.html" % (settings.url_address, page)
            movie.searchMovie(url_search=url_search)
            if page % 5 == 0: sleep(1)

        if optionUnica:
            rep = settings.dialog.select('Seleccionar tu opción:', movie.titles + ['CANCEL'])
            if rep < len(movie.titles):
                tools.int_pelisalacarta(channel="peliculasaudiolatino", titles=[movie.titles[rep]],
                                        url=[movie.url_list[rep]],
                                        type_list='MOVIE', folder=settings.movie_folder,
                                        name_provider=settings.name_provider)
        else:
            if len(movie.titles) > 0:
                tools.int_pelisalacarta(channel="peliculasaudiolatino", titles=movie.titles, url=movie.url_list,
                                        type_list='MOVIE',
                                        folder=settings.movie_folder, name_provider=settings.name_provider)
    elif ret == 5:  # Peliculas por Años
        response = browser.open(settings.url_address)  # getting years
        if response.code == 200:
            scraper.html = response.read().replace('<span class="icon-dot-single"></span>', '')
            scraper.find('ul class="children"', order=2)
            list_categories = dict(zip(scraper.aTexts, scraper.aHrefs))
            rep = settings.dialog.select('Categoria:', list_categories.keys())
            category = list_categories[list_categories.keys()[rep]]

            movie = Movies()
            settings.pages = settings.dialog.numeric(0, 'Número de páginas a bajar:')
            if settings.pages == '' or settings.pages == 0:
                settings.pages = "1"
            settings.pages = int(settings.pages)

            optionUnica = settings.dialog.yesno("Selección", "Por favor escoga el tipo de selección",
                                                yeslabel="Individual",
                                                nolabel="Todas")
            for page in range(1, settings.pages + 1):
                url_search = ("%s%s" % (settings.url_address, category)).replace(".html", "/pagina/%s.html" % page )
                movie.searchMovie(url_search=url_search)
                if page % 5 == 0: sleep(1)

            if optionUnica:
                rep = settings.dialog.select('Seleccionar tu opción:', movie.titles + ['CANCEL'])
                if rep < len(movie.titles):
                    tools.int_pelisalacarta(channel="peliculasaudiolatino", titles=[movie.titles[rep]],
                                            url=[movie.url_list[rep]],
                                            type_list='MOVIE', folder=settings.movie_folder,
                                            name_provider=settings.name_provider)
            else:
                if len(movie.titles) > 0:
                    tools.int_pelisalacarta(channel="peliculasaudiolatino", titles=movie.titles, url=movie.url_list,
                                            type_list='MOVIE',
                                            folder=settings.movie_folder,
                                            name_provider=settings.name_provider)
        else:
            settings.log(">>>>>>>HTTP %s<<<<<<<" % response.code)
            settings.notification(message="HTTP %s" % response.code, force=True)

    elif ret == 6:  # Peliculas por categoria
        response = browser.open(settings.url_address)  #getting the genres
        if response.code == 200:
            scraper.html=response.read().replace('<span class="icon-dot-single"></span>', '')
            scraper.find('ul class="children"', order=1)
            list_categories = dict(zip(scraper.aTexts, scraper.aHrefs))
            rep = settings.dialog.select('Categoria:', list_categories.keys())
            category = list_categories[list_categories.keys()[rep]]

            movie = Movies()
            settings.pages = settings.dialog.numeric(0, 'Número de páginas a bajar:')
            if settings.pages == '' or settings.pages == 0:
                settings.pages = "1"
            settings.pages = int(settings.pages)

            optionUnica = settings.dialog.yesno("Selección", "Por favor escoga el tipo de selección",
                                                yeslabel="Individual",
                                                nolabel="Todas")
            for page in range(1, settings.pages + 1):
                url_search = ("%s%s" % (settings.url_address, category)).replace(".html", "/pagina/%s.html" % page)
                movie.searchMovie(url_search=url_search)
                if page % 5 == 0: sleep(1)

            if optionUnica:
                rep = settings.dialog.select('Seleccionar tu opción:', movie.titles + ['CANCEL'])
                if rep < len(movie.titles):
                    tools.int_pelisalacarta(channel="peliculasaudiolatino", titles=[movie.titles[rep]],
                                            url=[movie.url_list[rep]],
                                            type_list='MOVIE', folder=settings.movie_folder,
                                            name_provider=settings.name_provider)
            else:
                if len(movie.titles) > 0:
                    tools.int_pelisalacarta(channel="peliculasaudiolatino", titles=movie.titles, url=movie.url_list,
                                            type_list='MOVIE',
                                            folder=settings.movie_folder,
            name_provider=settings.name_provider)
        else:
            settings.log(">>>>>>>HTTP %s<<<<<<<" % response.code)
            settings.notification(message="HTTP %s" % response.code, force=True)

    elif ret == 7:  # Todas Las películas',  # 7
        movie = Movies()
        settings.pages = settings.dialog.numeric(0, 'Número de páginas a bajar:')
        if settings.pages == '' or settings.pages == 0:
            settings.pages = "1"
        settings.pages = int(settings.pages)

        optionUnica = settings.dialog.yesno("Selección", "Por favor escoga el tipo de selección", yeslabel="Individual",
                                            nolabel="Todas")
        for page in range(1, settings.pages + 1):
            url_search = "%s/lista-completa/pagina/%s.html" % (settings.url_address, page)
            movie.searchMovie(url_search=url_search)
            if page % 5 == 0: sleep(1)

        if optionUnica:
            rep = settings.dialog.select('Seleccionar tu opción:', movie.titles + ['CANCEL'])
            if rep < len(movie.titles):
                tools.int_pelisalacarta(channel="peliculasaudiolatino", titles=[movie.titles[rep]],
                                        url=[movie.url_list[rep]],
                                        type_list='MOVIE', folder=settings.movie_folder,
                                        name_provider=settings.name_provider)
        else:
            if len(movie.titles) > 0:
                tools.int_pelisalacarta(channel="peliculasaudiolatino", titles=movie.titles, url=movie.url_list,
                                        type_list='MOVIE',
                                        folder=settings.movie_folder, name_provider=settings.name_provider)
    elif ret == 8:  # Borrar una Película
        from os import listdir
        from xbmc import translatePath

        folder = settings.movie_folder
        folder = folder.replace('special://temp/', translatePath('special://temp'))
        folder = folder.replace('smb:', '')  # network compatibility
        list_movies = listdir(folder)
        rep = settings.dialog.select('Seleccionar la película a borrar:', list_movies + ['-CANCELAR'])
        if rep < len(list_movies):
            if settings.dialog.yesno("Atención!", "Desea borrar los archivos strm?", nolabel="No", yeslabel="Si"):
                tools.removeDirectory(folder=settings.movie_folder, title=list_movies[rep])


    elif ret == 9:  # Todas las series
        show = Shows()
        settings.pages = settings.dialog.numeric(0, 'Número de páginas a bajar:')
        if settings.pages == '' or settings.pages == 0:
            settings.pages = "1"
        settings.pages = int(settings.pages)
        optionUnica = settings.dialog.yesno("Selección", "Por favor escoga el tipo de selección", yeslabel="Individual",
                                            nolabel="Todas")
        titles = []
        url_list = []
        list_item = []
        for page in range(1, settings.pages + 1):
            url_search = "%s/series-completas/pagina/%s.html" % (settings.url_address, page)
            settings.log(message=url_search)
            response = browser.open(url_search)
            if response.code == 200:
                scraper.html = response.read()
                scraper.findAll(key='div class="top"')
                url_list.extend(scraper.aHref[0])
                titles.extend(scraper.imgAlt[0])
                if not optionUnica:  # one selection
                    for title, url in zip(titles, url_list):
                        show.searchSerie(url)
                        storage.add(title, url)
            else:
                settings.log(">>>>>>>HTTP %s<<<<<<<" % response.code)
                settings.notification(message="HTTP %s" % response.code, force=True)
            if page % 5 == 0: sleep(1)

        if optionUnica:
            rep = settings.dialog.select('Seleccionar tu opción:', titles + ['-CANCELAR'])
            if rep < len(titles):
                show = Shows()
                show.searchSerie(url_list[rep])
                storage.add(titles[rep], url_list[rep])

        if len(show.titles) > 0:
            tools.int_pelisalacarta(channel="peliculasaudiolatino", titles=show.titles, url=show.url_list, type_list='SHOW',
                                    folder=settings.show_folder, name_provider=settings.name_provider)

    elif ret == 10:  # Borrar una serie
        rep = settings.dialog.select('Seleccionar la serie a borrar:', storage.database.keys() + ['-CANCELAR'])
        if rep < len(storage.database):
            if settings.dialog.yesno("Atención!", "Desea borrar los archivos strm también?", nolabel="No",
                                     yeslabel="Si"):
                tools.removeDirectory(folder=settings.show_folder, title=storage.database.keys()[rep])
            storage.remove(storage.database.keys()[rep])

    # common menu
    elif ret == len(option_list) - 3:  # Settings
        settings.settings.openSettings()
        settings = tools.Settings()

    elif ret == len(option_list) - 2:  # Help
        settings.dialog.ok("Ayuda",
                           "El manual de operacion se encuentra en esta dirección:\n[B]http://goo.gl/0b44BY[/B]")


# save the database
storage.save()

del storage
del settings
del browser
