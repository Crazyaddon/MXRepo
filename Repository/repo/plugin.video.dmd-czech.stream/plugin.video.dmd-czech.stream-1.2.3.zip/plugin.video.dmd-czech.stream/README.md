# plugin.video.dmd-czech.stream

Video doplněk do [kodi](http://www.kodi.tv/) pro přehrávání videí z archivu [stream.cz](https://www.stream.cz/).

Informace o instalaci najdete na stránkách repozitáře [Kodi CZ/SK](http://kodi-czsk.github.io/repository/).
