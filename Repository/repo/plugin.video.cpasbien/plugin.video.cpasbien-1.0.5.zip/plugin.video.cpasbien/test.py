# coding: utf-8
__author__ = 'Ruben'
data = '''

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <title>Index->Torrents</title>
  <if:seo_enabled>
  <tag:cano />
  <tag:meta />
  <tag:analytic />
  <tag:ggwebmaster />
  </if:seo_enabled>
  <meta http-equiv="content-type" content="text/html; charset=<tag:main_charset" />
  <meta name="Description" CONTENT="Search Discuss and Download verified torrents: movies, music, games, software" />
  <meta name="Keywords" CONTENT="mp3, avi, bittorrent, torrent, torrents, movies, music, games, applications, apps, download, upload, share, magnets, magnet, leetxtorrents" />
  <link rel="stylesheet" href="http://leetxtorrents.org/style/FS-022/main.css" type="text/css" />


    <!--[if lt IE 7.]>
    <script defer type="text/javascript" src="http://leetxtorrents.org/jscript/pngfix.js"></script>
    <![endif]-->
    <script type="text/javascript" src="http://leetxtorrents.org/jscript/ajax.js"></script>
    <script type="text/javascript" src="http://leetxtorrents.org/jscript/ajax-poller.js"></script>
    <script type="text/javascript" src="http://leetxtorrents.org/jscript/xbtit.js"></script>
	<!-- these next 3 scripts are for the animated collapse -->
	<script type="text/javascript" src="http://leetxtorrents.org/jscript/animatedcollapse.js"></script>
	<script type="text/javascript" src="http://leetxtorrents.org/jscript/1.4.2_jquery.min.js"></script>
	<script type="text/javascript" src="http://leetxtorrents.org/jscript/jquery.min.js"></script>
	<!-- // -->
    <script type="text/javascript" src="http://leetxtorrents.org/jscript/jquery.js"></script>
    <script type="text/javascript" src="http://leetxtorrents.org/jscript/interface.js"></script>
    <script type="text/javascript" src="http://leetxtorrents.org/jscript/prototype.js"></script>
    <script type="text/javascript" src="http://leetxtorrents.org/jscript/overlib.js"></script>
    <script type="text/javascript" src="http://leetxtorrents.org/jscript/TorrentName.js"></script>
    <script type="text/javascript" src="http://leetxtorrents.org/jscript/marquee.js"></script>

    <script language="JavaScript" src="http://leetxtorrents.org/jscript/jq.js"></script>
    <script language="JavaScript" src="http://leetxtorrents.org/jscript/jq.color.js"></script>


<!--[if lte IE 7]>
<style type="text/css">
#menu ul {display:inline;}
</style>
<![endif]-->

<if:balloons_enabled>
  <script type="text/javascript" src="./jscript/overlib.js"></script>
  </head>
  <div id="overDiv" style="position:absolute; visibility:hidden; z-index:1000;"></div>
<else:balloons_enabled>
  </head>
</if:balloons_enabled>
<body>
<h1>Download verified torrents: movies, music, games, software | leetxtorrents</h1>
<h2>Download verified torrents: movies, music, games, software</h2>


 <tag:season />
    <div id="main">

    <table width="100%" height="170" align="center" cellpadding="0" cellspacing="0" border="0">
      <tr>
      <td class="logo1"></td>
      </tr>
    </table>




    <table width='100%' align='center' cellpadding='0' cellspacing='0' border='0'>
      <tr>
      <td valign='top' width='5' rowspan='2'></td>
      <td valign="top" ><tag:main_adarea /></td>
      <td valign='top' width='5' rowspan='2'></td>
      </tr>
    </table>

  <br />
	<TABLE align="center" cellpadding="0" cellspacing="0" border="0">
      <TR>
      <TD valign="top">
	  <div id="dropdown">

      </div></TD>
      </TR>
    </TABLE>
	<br />

    <div id="header">
    <table width="100%" align="center" cellpadding="0" cellspacing="0" border="0">
      <tr>
      <td valign="top" width="5" rowspan="2"></td>
      <td valign="top"><div><div class="block">

<div class="block-head">
<div class="block-head-title"></div>
</div>


<div class="block-content">
<div align="justify" class="b-content"><table cellpadding="1" cellspacing="1" width="100%" border="0" align="center">
  <tr>
<td class="header" align="center"><a class="mainmenu" href="index.php">Index</a></td>
<td class="header" align="center"><a class="mainmenu" href="index.php?page=viewnews">News</a></td>
</tr><tr>
<td class="header" align="center"><a class="mainmenu" href="index.php?page=torrents">Torrents</a></td>
  </tr>
   </table><script type="text/javascript">
function newpm() {
<!--
var answer = confirm("You got unread mail ! , go to your inbox to read it before you proceed , else this popup will keep pestering you ;)")
if (answer)
window.location='index.php?page=usercp&uid=1&do=pm&action=list'
// -->
}
</script>
<link rel="stylesheet" href="css_login.css" type="text/css" />

<script type="text/javascript">

animatedcollapse.addDiv('yupylogin','fade=1,height=auto')
animatedcollapse.addDiv('yupyrecover','fade=1,height=auto')
animatedcollapse.addDiv('yupysignup','fade=1,height=auto')


animatedcollapse.ontoggle=function($, divobj, state){ }

animatedcollapse.init()

</script>
<div align="center" style="margin-top:1%;">&nbsp;&nbsp;

<img class="login" style="cursor:pointer" src="images/pic/blank.gif" onclick="javascript:animatedcollapse.toggle('yupylogin'); javascript:animatedcollapse.hide('yupyrecover'); javascript:animatedcollapse.hide('yupysignup');javascript:animatedcollapse.hide('yupykontakt')" alt="login" />&nbsp;

<img class="recover" style="cursor:pointer" src="images/pic/blank.gif" onclick="javascript:animatedcollapse.toggle('yupyrecover'); javascript:animatedcollapse.hide('yupylogin');javascript:animatedcollapse.hide('yupysignup');javascript:animatedcollapse.hide('yupykontakt')" alt="recover" />&nbsp;


<a href="index.php?page=signup" class="normal" target="_parent"><img class="signup" style="cursor:pointer" src="images/pic/blank.gif" alt="signup" /></a>&nbsp;
<div id="yupylogin" style="display:none">
<form action="index.php?page=login" name="login" method="post">

<table class="lista" border="0" cellpadding="10">
<tr><td class="tboxhead"></td></tr>
<tr><td align="center" class="tboxmidd"><pre><font size="3">User Name</font>:&nbsp;<input type="text" size="40" name="uid" value="" maxlength="40" /></pre></td></tr>
<tr><td align="center" class="tboxmidd"><pre><font size="3">Password</font>:&nbsp;<input type="password" size="40" name="pwd" maxlength="40" /></pre></td></tr>
<tr><td colspan="2" class="tboxmidd" align="center"><input type="submit" value="Login" /></td></tr>
<tr><td colspan="2" class="tboxmidd" align="center"><font size=2>You Need Cookies Enabled</font></td></tr>
<tr><td class="tboxfoot"></td></tr>
</table>
</form>
</div>
<br>
<div id="yupyrecover" style="display:none">
<div align="center">
<form action="index.php?page=recover&amp;act=takerecover" name="recover" method="post">
<table class="lista" border="0" cellpadding="15">
<tr><td class="tboxhead"></td></tr>
<tr><td align="center" class="tboxmidd"><pre><font size="3">Email:</font><input type=text size=40 name=email></pre></td></tr>
<tr>
<td colspan="2" align="center" class="tboxmidd"><pre><pre><font size="3">Security code: <input type="hidden" name="public_key" value="21d5d8" />
<img src="access_code/21d5d8.png" alt="" />
 </font><input type="text" id="captcha" name="private_key" maxlength="6" size="6" value="" /></pre></td>
</tr>

<tr><td colspan="2" class="tboxmidd" align="center"><input type="submit" value="Send" /></td></tr>
<tr><td class="tboxfoot"></td></tr>
</table>
</form>
</div>
<br />
</div>
</center>
</div>
</div>

<div class="block-foot">
</div>

</div>
  </div></td>
      <td valign="top" width="5" rowspan="2"></td>
      </tr>
    </table>
    </div>


    <div id="bodyarea" style="padding:4ex 0 0 0;">
    <table border="0" align="center" cellpadding="0" cellspacing="0" width="100%">
      <tr>
      <if:HAS_LEFT><td valign="top" width="5" rowspan="2"></td>
      <td id="lcol" valign="top" width="180"><tag:main_left /></td></if:HAS_LEFT>
      <td valign="top" width="5" rowspan="2"></td>
      <td id="mcol" valign="top"><div class="block">

<div class="block-head">
<div class="block-head-title">Torrents</div>
</div>


<div class="block-content">
<div align="center" class="b-content"><script type="text/javascript">
function SetAllCheckBoxes(FormName, FieldName, CheckValue)
{
if(!document.forms[FormName])
return;
var objCheckBoxes = document.forms[FormName].elements[FieldName];
if(!objCheckBoxes)
return;
var countCheckBoxes = objCheckBoxes.length;
if(!countCheckBoxes)
objCheckBoxes.checked = CheckValue;
else
// set the check value for all check boxes
for(var i = 0; i < countCheckBoxes; i++)
objCheckBoxes[i].checked = CheckValue;
}
</script>
	<table width="90%" align="center">
  <tr>
    <td>
      <table width="100%" class="lista" cellspacing=1>

    <br><tr><td class="block" colspan="10" align="center"><b>Our Team Recommend</td></tr>
               <tr>
          <td class="header" align="center" width="45">Cat.</td>
          <td align="center" class="header" >Filename</td>
          <td align="center" class="header" width="20">DL</td>
          <td align="center" class="header" width="85">Added</td>
          <td align="center" class="header" width="70">Size</td>
          <td align="center" class="header" width="100">Uploader</td>
          <td align="center" class="header" width="30">S</td>
          <td align="center" class="header" width="30">L</td>
          <td align="center" class="header" width="100">Recommended by</td>
          <tag:tora[].rp10 />
          </tr>
          <tr>
          <tag:tora[].rp11 />
          <tag:tora[].rp12 />
          <tag:tora[].rp13 />
          <tag:tora[].rp14 />
          <tag:tora[].rp15 />
          <tag:tora[].rp16 />
          <tag:tora[].rp17 />
          <tag:tora[].rp18 />
          <tag:tora[].rp19 />
          <tag:tora[].rp20 />
               </tr>
      </table>
    </td>
  </tr>
</table><br>

<div align="center">

<form action="index.php" method="get" name="torrent_search">
  <input type="hidden" name="page" value="torrents" />
  <table border="0" class="lista" align="center">
    <tr>
      <td class="block">Search Torrents</td>
      <td class="block">Category</td>
<td class="block">Uploader</td>

<td class="block">Search in</td>

      <td class="block">Status</td>


           <td class="block">Free</td>

                <td class="block">&nbsp;</td>
    </tr>
    <tr>
      <td><input type="text" name="search" size="25" maxlength="50" value="" /></td>
      <td>

<select name="category"><option value="0">----</option>
<optgroup label='Movies'>
<option value="31">Dubs/Dual Audio</option>
<option value="32">DVD</option>
<option value="33">h.264/x264</option>
<option value="34">HD</option>
<option value="35">Mp4</option>
<option value="36">Divx/Xvid</option>
<option value="37">PSP</option>
<option value="38">SVCD/VCD</option>
<option value="39">Album</option>
<option selected="selected" value="65">Movies-BluRay</option>
<option value="66">Movies-Asian</option>
</optgroup>
<optgroup label='Other'>
<option value="7">Other</option>
<option value="8">E-Books</option>
<option value="9">Tutorials</option>
<option value="10">Images</option>
<option value="11">Comics</option>
<option value="12">Audiobook</option>
<option value="13">Nulled Script</option>
<option value="14">Emulation</option>
<option value="15">Sounds</option>
<option value="16">Divx/Xvid</option>
<option value="17">PS1</option>
<option value="18">Mobile Phone</option>
</optgroup>
<optgroup label='Games'>
<option value="20">PC Game</option>
<option value="21">Images</option>
<option value="22">Other</option>
<option value="23">PS1</option>
<option value="24">Xbox360</option>
<option value="25">PS3</option>
<option value="26">PS2</option>
<option value="27">PSP</option>
<option value="28">DS</option>
<option value="29">Xbox</option>
<option value="67">Games-Android</option>
</optgroup>
<optgroup label='TV'>
<option value="51">HD</option>
<option value="52">Divx/Xvid</option>
<option value="53">DVD</option>
<option value="54">SVCD/VCD</option>
</optgroup>
<optgroup label='Music'>
<option value="41">MP3</option>
<option value="42">Album</option>
<option value="43">Lossless</option>
<option value="44">Box Set</option>
<option value="45">Video</option>
<option value="46">Other</option>
<option value="47">Single</option>
<option value="48">Discography</option>
<option value="49">DVD</option>
</optgroup>
<optgroup label='XXX'>
<option value="2">Video</option>
<option value="3">Magazine</option>
<option value="4">Hentai</option>
<option value="5">Picture</option>
</optgroup>
<optgroup label='Documentaries'>
<option value="56">Documentary</option>
</optgroup>
<optgroup label='Apps'>
<option value="58">PC Software</option>
<option value="59">Android</option>
<option value="60">Mac</option>
<option value="61">Linux</option>
<option value="62">Other</option>
</optgroup>
<optgroup label='Anime'>
<option value="64">Anime</option></select>
      </td>
 <td>

<select name="uploader"><option value="0">----</option>
<option value="1">Anonymous</option>
<option value="62">Blackjesus</option>
<option value="83">Ex0duS5150</option>
<option value="89">kawliga55</option>
<option value="289">SaM</option>
<option value="510">Thumper</option>
<option value="5287">deepstatus</option>
<option value="5678">extremerules</option>
<option value="7010">Azemone</option>
<option value="7473">DivaXSaya53</option>
<option value="10475">Strigoi</option>
<option value="11862">Xpoz</option>
<option value="11986">SkilletWarez</option>
<option value="12278">HDD</option>
<option value="12568">Aradrin</option>
<option value="12575">SalMovies</option>
<option value="12581">Slocate</option>
<option value="12582">0xxx</option>
<option selected="selected" value="12587">CrystalTorrent</option>
<option value="12588">CTShoN</option>
<option value="12590">isoTropic</option>
<option value="12593">sceneCD</option>
<option value="12597">SriLinks</option>
<option value="12603">KATRG</option>
<option value="12604">Gooner</option>
<option value="12608">thLullaby</option>
<option value="12795">AncientRome</option>
<option value="13262">Ric</option></select>
      </td>

      <td>
        <select name="options" size="1">
        <option value="0" selected="selected">Filename</option>
        <option value="1" >File & Description</option>
        <option value="2" >Description</option>
        </select>
      </td>

      <td>
        <select name="active" size="1">
        <option value="0" >All</option>
        <option value="1" selected="selected">Active only</option>
        <option value="2" >Dead only</option>
        </select>
      </td>
           <td>
        <select name="gold" size="1">
        <option value="0" selected="selected">All</option>
        <option value="1" >Classic</option>
        <option value="2" >Silver</option>
        <option value="3" >Gold</option>
        <option value="4" >Silver & Gold</option>

        </select>
      </td>


      <td><input type="submit" class="btn" value="Search" /></td>
     </tr>
  </table>
</form>
</div>

<table width="100%">
  <tr>
    <td colspan="2" align="center"> </td>
  </tr><form name=deltorrent action=index.php?page=torrents&do=del method=post>
  <tr>
    <td>
      <table width="100%" class="lista">
	  <tr><td class="header" colspan="17"><tag:search_msg /></td></tr>
        <tr>
          <td align="center" width="45" class="header"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=65&amp;uploader=12587&amp;order=1&amp;by=1">Cat.</a></td>
          <td align="center" class="header"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=65&amp;uploader=12587&amp;order=2&amp;by=1">Name</a></td>


          <td align="center" width="20" class="header">Dl</td>
          <td align=center width=30 class=header>Mag</td>
          <td align="center" width="20" class="header">BM</td>
          <td align="center" width="40" class="header"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=65&amp;uploader=12587&amp;order=3&amp;by=1">Date</a></td>
          <td align="center" width="30" class="header">Age</td>
          <td align="center" width="30" class="header"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=65&amp;uploader=12587&amp;order=5&amp;by=2">S</a></td>
          <td align="center" width="30" class="header"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=65&amp;uploader=12587&amp;order=6&amp;by=2">L</a></td>
          <td align="center" width="30" class="header"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=65&amp;uploader=12587&amp;order=7&amp;by=1">C</a></td>

          <td align="center" width="30" class="header">Uploader</td>

          <td align="center" width="30" class="header"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=65&amp;uploader=12587&amp;order=4&amp;by=2">Size</a></td>

          <td align="center" width="45" class="header"><a href="/index.php?page=torrents&amp;active=1&amp;gold=0&amp;category=65&amp;uploader=12587&amp;order=9&amp;by=1">Speed</a></td>

          <if:uplo>
          <td align="center" width="20" class="header">Lang</td>
          </if:uplo>
          <td align="center" width="45" class="header">Av.</td><tag:torrent_header_rec /></td><tag:torrent_header_top /><TD align='center' class='header' style="text-align: center;"></TD>
        </tr>

      </table>
    </td></tr><tr>
  </tr>
  <tr>
    <td colspan="2" align="center"> </td>
  </tr>
</table></form></div>
</div>

<div class="block-foot">
</div>

</div>
  </td>
      <td valign="top" width="5" rowspan="2"></td>
      <if:HAS_RIGHT><td id="rcol" valign="top" width="180"><tag:main_right /></td>
      <td valign="top" width="5" rowspan="2"></td></if:HAS_RIGHT>
      </tr>
    </table>


    <table align="center" width="100%" cellpadding="0" cellspacing="0" border="0">
      <tr>
      <td valign="top" width="10" rowspan="2"></td>
      <td id="fcol" valign="top"><br />
</td>
      <td valign="top" width="10" rowspan="2"></td>
      </tr>
    </table>
		<if:HAS_DIS><TABLE border="0" align="center" cellpadding="5" cellspacing="1" width="100%">
  <TR>
	  <TD valign="top">
<table cellpadding="0" cellspacing="0" width="100%" align="center">
  <tr>
    <td width="100%" height="26">&nbsp;&nbsp;<b>Site Disclaimer</b></td>
  </tr></table>
	<table border="0" align="center" cellpadding="0" cellspacing="0" width="100%" height="70">
   <tr><td class="lista" align="center" style="padding-left:20px; padding-right:20px;"><center>None of the files shown here are actually hosted on the server of (Download verified torrents: movies, music, games, software | leetxtorrents). The links are provided solely by this site's users. The administrator of this site cannot be held responsible for what its users post, or any other actions of its users. You may not use this site to distribute or download any material when you do not have the legal rights to do so. It is your own responsibility to adhere to these terms. By registering on and/or using this website, it is assumed that <u>you</u>, as the user, have read, understood, and agreed to all the terms and conditions set forth by the site's owner.</center></td>
    </tr>
  </table></TD>
</TR></TABLE></if:HAS_DIS>

    <table width="100%" height="46" align="center" cellpadding="0" cellspacing="0" border="0" >
      <tr>
      <td align="center" valign="middle">[ Queries: 27|0 ] - [ Script Execution: 0.0224 sec. ] - [ GZIP: enabled ]</td>
      </tr>
    </table>
    </div>
</body>
</html>
'''
import bs4
from ast import literal_eval

soup = bs4.BeautifulSoup(data)

# links = soup.select("optgroup")
links = soup.find("optgroup", {"label": "Movies"})
soup2 = bs4.BeautifulSoup(str(links))
options = soup2.select('option')
for option in options:
    print option['value'], option.text
# import requests
#
# url = "http://www.elitetorrent.net/categoria/1/estrenos/modo:listado/pag:1"
# browser = requests.Session()
# page = "1"
# import bs4
#
# response = browser.get( url + page)
# soup = bs4.BeautifulSoup(response.text)
# links = soup.select("a.nombre")
# for link in links:
#     print link.get("title", ""), link["href"]

# import re
#
# datos = re.search("var datos =(.*?);", data, re.DOTALL).group(1).replace("{", "").replace("}", "")
# params = {}
# for item in datos.split("\n"):
#     if item.strip() != "":
#         key, value = item.strip()[:-1].split(':')
#         params[key] = value.replace("'", "")
# #settings.debug(params)
# opciones = re.search("var options =(.*?);", data, re.DOTALL).group(1).replace("{", "").replace("}", "") + ": ''"
# params1 = {}
# for item in opciones.split("\n"):
#     if item.strip() != "":
#         key, value = item.strip()[:-1].split(':')
#         params1[key] = value.replace("'", "")
# #settings.debug(params1)
# urlPage = re.search('url: "(.*?)"', data).group(1)
