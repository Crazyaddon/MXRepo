Indy Wrestling Network
===============

The Indy Wrestling Network brings together those local promotions around the world that pose their weekly or monthly shows to YouTube.

**PLEASE NOTE:** 
The YouTube plugin for Kodi is required to be installed to use this plugin.