Welcome to Navi-X v3.8.0

Navi-X is a "content aggregator" app that provides access to all kinds of multimedia content, listed on a public directory of user contributed listings or playlists for playing on your TV, PC or mobile devices! Users can link to content and playback video, audio, pictures, podcasts, text, rss and html on the internet and share it with people around the world in seconds! Create fully customizable playlists with backgrounds, logos and icons as well as link to your favorite multimedia on the internet or browse the already existing directory of publicly available content, in one sleek, fast and unified application! Navi-X is a multi-platform addon for XBMC, a popular and free media center application available on Windows, Mac, Linux, Android and iOS (Apple TV, iPhone and iPads) as well as the original Xbox. Check out Navi-X today and tell us what you think about it at http://www.twitter.com/navi_x

Visit Navi-Xtreme Media Portal: http://www.navixtreme.com


