# vgtv-xbmc

Kodi/XBMC plugin for browsing and playing videos from VGTV.no

## License

GPL-licensed. See `LICENSE.txt` for full details.
