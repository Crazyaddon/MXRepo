# kodi-vg-podcasts
Listen to VG.no's podcasts using Kodi
