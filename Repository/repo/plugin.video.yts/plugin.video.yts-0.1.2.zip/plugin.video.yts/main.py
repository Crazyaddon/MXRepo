# coding: utf-8
# Main Addon
__author__ = 'mancuniancol'

from xbmcswift2 import Plugin
from tools2 import *

##INITIALISATION
storage = Storage(settings.storageName, type="dict")
plugin = Plugin()


###############################
###  MENU    ##################
###############################
@plugin.route('/')
def quality():
    textViewer(settings.string(32000), once=True)
    items = [{'label': "Manual Search",
              'path': plugin.url_for('search'),
              'thumbnail': dirImages("busqueda-manual.png"),
              'properties': {'fanart_image': settings.fanart}
              },
             {'label': "All",
              'path': plugin.url_for('genre', quality="all"),
              'thumbnail': dirImages("busqueda-manual.png"),
              'properties': {'fanart_image': settings.fanart}
              },
             {'label': "720p",
              'path': plugin.url_for('genre', quality="720p"),
              'thumbnail': dirImages("busqueda-manual.png"),
              'properties': {'fanart_image': settings.fanart}
              },
             {'label': "1080p",
              'path': plugin.url_for('genre', quality="1080p"),
              'thumbnail': dirImages("busqueda-manual.png"),
              'properties': {'fanart_image': settings.fanart}
              },
             {'label': "3D",
              'path': plugin.url_for('genre', quality="3D"),
              'thumbnail': dirImages("busqueda-manual.png"),
              'properties': {'fanart_image': settings.fanart}
              },
             {'label': settings.string(32017),
              'path': plugin.url_for('help'),
              'thumbnail': dirImages("ayuda.png"),
              'properties': {'fanart_image': settings.fanart}
              },
             ]
    return items


@plugin.route('/genre/<quality>')
def genre(quality="all"):
    list = ["all", "action", "adventure", "animation", "biography",
            "comedy", "crime", "documentary", "drama", "family",
            "fantasy", "film-noir", "game-show", "history", "horror",
            "music", "musical", "mystery", "news", "reality-tv", "romance",
            "sci-fi", "sport", "talk-show", "thriller", "war", "western",
            ]
    items = []
    for item in list:
        items.append(
            {'label': item.title(),
             'path': plugin.url_for('rating', quality=quality, genre=item),
             'thumbnail': dirImages("busqueda-manual.png"),
             'properties': {'fanart_image': settings.fanart}
             })
    return items


@plugin.route('/rating/<quality>/<genre>')
def rating(quality="all", genre="all"):
    list = ["all", "9", "8", "7", "6", "5", "4", "3", "2", "1",
            ]
    items = []
    for item in list:
        items.append(
            {'label': (item + '+').replace('all+', 'All'),
             'path': plugin.url_for('orderBy', quality=quality, genre=genre, rating=item),
             'thumbnail': dirImages("busqueda-manual.png"),
             'properties': {'fanart_image': settings.fanart}
             })
    return items


@plugin.route('/orderBy/<quality>/<genre>/<rating>')
def orderBy(quality="all", genre="all", rating="all"):
    list = ["latest", "oldest", "seeds", "peers", "year", "rating", "likes", "alphabetical", "downloads",
            ]
    items = []
    for item in list:
        items.append(
            {'label': item.title(),
             'path': plugin.url_for('readHTML', quality=quality, genre=genre, rating=rating, order_by=item),
             'thumbnail': dirImages("busqueda-manual.png"),
             'properties': {'fanart_image': settings.fanart}
             })
    return items


# Search
@plugin.route('/search/')
def search():
    query = settings.dialog.input(settings.string(32190))
    return readHTML(keyword=query)


####################################################
# Read the url and store the info
@plugin.route('/readHTML/<quality>/<genre>/<rating>/<order_by>', name="readHTML")
def readHTML(keyword="0", quality="all", genre="all", rating="0", order_by="latest"):
    # Firt Page
    information = plugin.get_storage('information')
    information.clear()
    return nextPage(keyword=keyword, quality=quality, genre=genre, rating=rating, order_by=order_by)


@plugin.route('/nextPage/<keyword>/<quality>/<genre>/<rating>/<order_by>/<page>', name="nextPage")
def nextPage(keyword="0", quality="all", genre="all", rating="0", order_by="latest", page="1"):
    urlSearch = settings.value['urlAddress']
    rating = rating.replace("all", "0")

    # Reading the _token
    response = ""
    if page == "1":
        response = browser.get(urlSearch)
        soup = bs4.BeautifulSoup(response.text)
        itemToken = soup.select("div#mobile-search-input input")
        token = itemToken[0]["value"]  # hidden token

        # Read
        settings.log(urlSearch)
        payload = {
            "keyword": keyword if keyword != "0" else "",
            "_token": token,
            "quality": quality,
            "genre": genre,
            "rating": rating,
            "order_by": order_by,
        }
        settings.log(payload)
        response = browser.post(urlSearch + "/search-movies", data=payload)
    else:
        # read the result
        urlSearch = urlSearch + "/browse-movies/%s/%s/%s/%s/%s?page=%s" % (
        keyword, quality, genre, rating, order_by, page)
        urlSearch = urlSearch.replace("?page=1", "")
        settings.log(urlSearch)
        response = browser.get(urlSearch)
    soup = bs4.BeautifulSoup(response.text)

    # Titles and Urls
    titles = []
    urlSources = []
    links = soup.select("div.browse-movie-bottom")
    for div in links:
        baseTitle = div.a.text  # title
        aList = div.select("div a")
        for a in aList:
            titles.append(baseTitle + ' ' + a.text)
            urlSources.append(a["href"])

    # Create Menu
    createMenu(titles, urlSources)
    items = menu1()

    # Next page
    items.append({'label': "[B]" + settings.string(32191) + "[/B]",
                  'path': plugin.url_for('nextPage', keyword=keyword, quality=quality, genre=genre, rating=rating,
                                         order_by=order_by, page=int(page) + 1),
                  'thumbnail': dirImages("next11.png"),
                  'properties': {'fanart_image': settings.fanart}
                  })

    if __name__ == '__main__':
        return plugin.finish(items=items, view_mode=settings.value['viewMode'],
                             sort_methods=['date'])
    else:
        return items


###################################################
############## COMMON NOT TO CHANGE ###############
###################################################
@plugin.route('/play/<url>')
def play(url):
    magnet = 'magnet:?xt=urn:btih:%s' % url[url.rfind("/") + 1:-8]
    # Set-up the plugin
    uri_string = quote_plus(getPlayableLink(uncodeName(magnet)))
    if settings.value["plugin"] == 'Pulsar':
        link = 'plugin://plugin.video.pulsar/play?uri=%s' % uri_string
    elif settings.value["plugin"] == 'KmediaTorrent':
        link = 'plugin://plugin.video.kmediatorrent/play/%s' % uri_string
    elif settings.value["plugin"] == "Torrenter":
        link = 'plugin://plugin.video.torrenter/?action=playSTRM&url=' + uri_string + \
               '&not_download_only=True'
    elif settings.value["plugin"] == "YATP":
        link = 'plugin://plugin.video.yatp/?action=play&torrent=' + uri_string
    else:
        link = 'plugin://plugin.video.xbmctorrent/play/%s' % uri_string
    # play media
    settings.debug("PlayMedia(%s)" % link)
    xbmc.executebuiltin("PlayMedia(%s)" % link)


@plugin.route('/help/')
def help():
    textViewer(plugin.get_string(32000), once=False)


@plugin.route('/unsubscribe/<key>')
def unsubscribe(key=""):
    storage.remove(key)
    storage.save()


@plugin.route('/subscribe/<key>/<url>')
def subscribe(key="", url=""):
    storage.add(key, url)
    storage.save()
    importAll(key, url)


@plugin.route('/importOne/<title>')
def importOne(title=""):
    information = plugin.get_storage('information')
    info = information[title][0]
    integration(titles=[title], magnets=[info.fileName], id=[info.id], typeVideo=[info.typeVideo], silence=True)


@plugin.route('/importAll/<url>')
def importAll(url=""):
    items = readHTML(url)  # only to create information
    information = plugin.get_storage('information')
    titles = []
    fileNames = []
    typeVideos = []
    ids = []
    for title in information:
        temp, level1 = information[title]
        for season in level1:
            level2 = level1[season]
            for episode in level2:
                temp, level3 = level2[episode]
                for info in level3:
                    ids.append(info.id)
                    titles.append(info.infoTitle["title"])
                    fileNames.append(info.fileName)
                    typeVideos.append(info.typeVideo)
    integration(titles=titles, magnets=fileNames, id=ids, typeVideo=typeVideos, silence=True)


@plugin.route('/rebuilt/<url>')
def rebuilt(url):
    overwrite = settings.value["overwrite"]  # save the user's value
    settings.value["overwrite"] = "true"  # force to overwrite
    importAll(url)
    settings.value["overwrite"] = overwrite  # return the user's value
    settings.log(url + " was rebuilt")


# Create the storage from titles and urls
def createMenu(titles, urlSources):
    information = plugin.get_storage('information')
    page = plugin.get_storage('page')
    page.clear()
    for title, urlSource in zip(titles, urlSources):
        # it gets all the information from the title and url
        info = UnTaggle(title, urlSource, useUrl=False)  # Untaggle
        temp, level1 = information.get(info.infoTitle["folder"], ("", {}))  # infoLabels, dictionnary seasons
        level2 = level1.get(str(info.season), {})  # dictionnary episodes
        temp, level3 = level2.get(str(info.episode), ("", []))  # list info for that episode
        level3.append(info)  # add new info video
        level2[str(info.episode)] = (info, level3)
        level1[str(info.season)] = level2
        information[info.infoTitle["folder"]] = (info, level1)
        page[info.infoTitle["folder"]] = (info, level1)


@plugin.route('/menu1')
def menu1():  # create the menu for first level
    information = plugin.get_storage('page')
    source = plugin.get_storage('source')

    items = []
    typeVideo = "MOVIE"
    if len(information.keys()) == 1:
        items = menu2(information.keys()[0])
    else:
        for title in information.keys():
            info, level1 = information.get(title, ("", {}))  # infoLabels, dictionnary seasons
            typeVideo = info.typeVideo
            try:
                items.append({'label': info.infoTitle["folder"],
                              'path': plugin.url_for('menu2', title=info.infoTitle["folder"]),
                              'thumbnail': info.infoLabels.get('cover_url', settings.icon),
                              'properties': {'fanart_image': info.fanart},
                              'info': info.infoLabels,
                              # 'context_menu': [
                              #     (plugin.get_string(32009),
                              #      'XBMC.RunPlugin(%s)' % plugin.url_for('importAll', url=title))
                              # ]
                              })
            except:
                pass
        # main
        if __name__ == '__main__':
            plugin.set_content("movies" if typeVideo == "MOVIE" else "tvshows")
    return items


@plugin.route('/menu2/<title>')
def menu2(title=""):  # create the menu for second level
    information = plugin.get_storage('information')
    items = []
    typeVideo = "MOVIE"
    info, level1 = information.get(title, ("", {}))  # infoLabels, dictionnary seasons
    if len(level1) == 1:
        items = menu3(title, level1.keys()[0])
    else:
        for season in level1.keys():
            level2 = level1[season]  # dictionnary episodes
            typeVideo = info.typeVideo
            try:
                items.append({'label': "Season %s" % season,
                              'path': plugin.url_for('menu3', title=title, season=season),
                              'thumbnail': info.infoLabels.get('cover_url', settings.icon),
                              'properties': {'fanart_image': info.fanart},
                              'info': info.infoLabels,
                              })
            except:
                pass
        # main
        if __name__ == '__main__':
            plugin.set_content("movies" if typeVideo == "MOVIE" else "tvshows")
    return items


@plugin.route('/menu3/<title>/<season>')
def menu3(title="", season=""):  # create the menu for third level
    information = plugin.get_storage('information')
    items = []
    typeVideo = "MOVIE"
    temp, level1 = information.get(title, ("", {}))  # infoLabels, dictionnary seasons
    level2 = level1[season]
    if len(level2) == 1:
        items = menu4(title, season, level2.keys()[0])
    else:
        for episode in level2.keys():
            info, level3 = level2[episode]  # dictionnary episodes
            typeVideo = info.typeVideo
            try:
                items.append({'label': info.label,
                              'path': plugin.url_for('menu4', title=title, season=season, episode=episode),
                              'thumbnail': info.cover,
                              'properties': {'fanart_image': info.fanart},
                              'info': info.info,
                              })
            except:
                pass
        # main
        if __name__ == '__main__':
            plugin.set_content("movies" if typeVideo == "MOVIE" else "episodes")
    return items


@plugin.route('/menu4/<title>/<season>/<episode>')
def menu4(title="", season="", episode=""):  # create the menu for last level
    information = plugin.get_storage('information')
    items = []
    typeVideo = "MOVIE"
    temp, level1 = information.get(title, ("", {}))  # infoLabels, dictionnary seasons
    level2 = level1[season]
    temp, level3 = level2[episode]
    for info in level3:
        typeVideo = info.typeVideo
        try:
            items.append({'label': info.label,
                          'path': plugin.url_for('play', url=info.fileName),
                          'thumbnail': info.cover,
                          'properties': {'fanart_image': info.fanart},
                          'info': info.info,
                          'stream_info': info.infoStream,
                          'is_playable': play,
                          'context_menu': [
                              (plugin.get_string(32009),
                               'XBMC.RunPlugin(%s)' % plugin.url_for('importOne', title=title))
                          ]
                          })
        except:
            pass
        # main
        if __name__ == '__main__':
            plugin.set_content("movies" if typeVideo == "MOVIE" else "episodes")
    return items


if __name__ == '__main__':
    plugin.run()
