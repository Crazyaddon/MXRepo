# coding: utf-8
__author__ = 'Ruben'

data = '''

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <!--[if IE]> <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> <![endif]-->
    <meta name="viewport" content="width=device-width, minimal-ui, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
    <meta name="description" content="Search Browse For Any YIFY Movie Downloads at YTS. Thousands of films in small file size" />
    <meta name="keywords" content="torrents, yify, yts, movies, movie, download, 720p, 1080p, 3D, browse movies, yify-torrents, yts" />
    <meta property="og:title" content="Search and Browse YIFY Movie Torrent Downloads - YTS"/>
    <meta property="og:image" content="https://yts.ag/assets/images/website/og_yts_logo.png"/>
    <meta property="og:description" content="Search Browse For Any YIFY Movie Downloads at YTS. Thousands of films in small file size"/>
    <meta property="og:url" content="https://yts.ag/browse-movies/0/all/all/0/latest" />
    <title>Search and Browse YIFY Movie Torrent Downloads - YTS</title>
    <!--[if IE]> <meta http-equiv="X-UA-Compatible" content="IE=Edge,chrome=1" /> <![endif]-->
    <link rel="shortcut icon" href="/assets/images/website/favicon.ico">
    <link rel="apple-touch-icon" sizes="57x57" href="/assets/images/website/apple-touch-icon-57x57.png">
    <link rel="apple-touch-icon" sizes="114x114" href="/assets/images/website/apple-touch-icon-114x114.png">
    <link rel="apple-touch-icon" sizes="72x72" href="/assets/images/website/apple-touch-icon-72x72.png">
    <link rel="apple-touch-icon" sizes="144x144" href="/assets/images/website/apple-touch-icon-144x144.png">
    <link rel="apple-touch-icon" sizes="60x60" href="/assets/images/website/apple-touch-icon-60x60.png">
    <link rel="apple-touch-icon" sizes="120x120" href="/assets/images/website/apple-touch-icon-120x120.png">
    <link rel="apple-touch-icon" sizes="76x76" href="/assets/images/website/apple-touch-icon-76x76.png">
    <link rel="apple-touch-icon" sizes="152x152" href="/assets/images/website/apple-touch-icon-152x152.png">
    <link rel="apple-touch-icon" sizes="180x180" href="/assets/images/website/apple-touch-icon-180x180.png">
    <link rel="icon" type="image/png" href="/assets/images/website/favicon-160x160.png" sizes="160x160">
    <link rel="icon" type="image/png" href="/assets/images/website/favicon-96x96.png" sizes="96x96">
    <link rel="icon" type="image/png" href="/assets/images/website/favicon-16x16.png" sizes="16x16">
    <link rel="icon" type="image/png" href="/assets/images/website/favicon-32x32.png" sizes="32x32">
    <meta name="msapplication-TileColor" content="#00a300">
    <meta name="msapplication-TileImage" content="/assets/images/website/mstile-144x144.png">
    <meta name="msapplication-config" content="/assets/images/website/browserconfig.xml">
    <link rel="search" type="application/opensearchdescription+xml" href="/opensearch" title="YTS - The Official Home of YIFY Movie Torrent Downloads" />
    <link href='https://fonts.googleapis.com/css?family=Arimo:400,700,400italic,700italic&amp;subset=latin,latin-ext' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="/assets/fonts/fonts.css">
    <link rel="stylesheet" href="/assets/minified/8acb5de663bc55f0cbed2b4a7d1504dc.css">
</head>

<body class="non-touch ">

    <script>
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

      ga('create', 'UA-69675816-1', 'auto');
      ga('send', 'pageview');
    </script>


    <header class="nav-bar">
        <div class="nav-logo pull-left">
            <a href="https://yts.ag/"><img src="/assets/images/website/logo-YTS.svg" alt="" /></a>
        </div>

        <span class="header-slogan hidden-xs pull-left">HD movies at the smallest file size.</span>

        <div class="main-nav-links hidden-sm hidden-xs">
            <form method="GET" action="https://yts.ag/search-movies" accept-charset="UTF-8" id="quick-search" name="quick-search">
                <div id="quick-search-container">
                    <input id="quick-search-input" name="query" autocomplete="off" type="search" value="Quick search">
                    <div class="ajax-spinner"></div>
                </div>
            </form>

            <ul class="nav-links">
                <li><a href="https://yts.ag/"> Home </a></li>
                <li><a href="https://yts.ag/browse-movies"> Browse Movies </a></li>
            </ul>

            <ul class="nav-links nav-link-guest">
                                    <li><a class="login-nav-btn" href="javascript:void(0)"> Login </a> &nbsp;|&nbsp; <a class="register-nav-btn" href="javascript:void(0)"> Register </a></li>
                            </ul>
        </div>

        <div class="nav-mobile-buttons hidden-md hidden-lg">
            <a class="touchable" id="mobile-search-btn" href="javascript:void(0)"> <span class="glyphicon glyphicon-search"></span> </a>
            <a class="touchable" href="https://yts.ag/browse-movies"> <span class="glyphicon glyphicon-list-alt"></span> </a>
            <a class="touchable" href="https://yts.ag/login"> <span class="glyphicon glyphicon-user"></span> </a>
        </div>
    </header>

    <div id="background-image" style="background: url(/assets/images/movies//background.jpg) no-repeat center center; background-size: cover; -webkit-background-size: cover;-moz-background-size: cover; -o-background-size: cover;"></div>
    <div id="background-overlay"></div>
    <div class="modal modal-auth hidden-xs hidden-sm">
        <div class="modal-container">
            <div class="modal-switcher">
                <span id="modal-login"> Login </span>
                <span id="modal-register"> Register </span>
            </div>

            <div class="modal-content">
                <div class="modal-login-content">
                    <form method="POST" action="https://yts.ag/" accept-charset="UTF-8" autocorrect="off" autocapitalize="off" spellcheck="off">
                        <input name="_token" type="hidden" value="5Vsj4rOZCMfjkM0xlHYsRx2mEprlxRFY00QpuxLp">
                        <span class="error-msg"></span>
                        <div class="inner-addon">
                            <span class="glyphicon glyphicon-user"></span>
                            <input placeholder="Username or Email" autocorrect="off" autocapitalize="off" spellcheck="off" name="username" type="text">
                        </div>
                        <div class="inner-addon">
                            <span class="glyphicon glyphicon-lock"></span>
                            <input placeholder="Password" autocorrect="off" autocapitalize="off" spellcheck="off" name="password" type="password" value="">
                        </div>
                        <button class="button-green-download-big" type="button">Login</button>
                    </form>

                    <p class="bottom-msg">
                        <a class="forgotpassword-nav-btn" href="javascript:void(0)">Forgot your password?</a>
                    </p>
                </div>

                <div class="modal-register-content">
                    <form method="POST" action="https://yts.ag/" accept-charset="UTF-8" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="off">
                        <input name="_token" type="hidden" value="5Vsj4rOZCMfjkM0xlHYsRx2mEprlxRFY00QpuxLp">
                        <span class="error-msg"></span>
                        <div class="inner-addon">
                            <span class="glyphicon glyphicon-user"></span>
                            <input placeholder="Username" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="off" name="username" type="text">
                        </div>
                        <div class="inner-addon">
                            <span class="glyphicon glyphicon-envelope"></span>
                            <input placeholder="E-Mail" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="off" name="email" type="email">
                        </div>
                        <div class="inner-addon">
                            <span class="glyphicon glyphicon-lock"></span>
                            <input placeholder="Password" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="off" name="password" type="password" value="">
                        </div>
                        <div class="inner-addon">
                            <span class="glyphicon glyphicon-lock"></span>
                            <input placeholder="Confirm Password" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="off" name="password_confirmation" type="password" value="">
                        </div>
                        <button class="button-green-download-big" type="button">Register</button>
                    </form>
                </div>

                <div class="modal-forgotpass-content">
                    <form method="POST" action="https://yts.ag/" accept-charset="UTF-8" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="off">
                        <input name="_token" type="hidden" value="5Vsj4rOZCMfjkM0xlHYsRx2mEprlxRFY00QpuxLp">
                        <span class="error-msg"></span>
                        <p class="info-msg"> If you have Forgotten your password, just type in your Email and we will send you a link to Reset your password. </p>
                        <div class="inner-addon">
                            <span class="glyphicon glyphicon-envelope"></span>
                            <input placeholder="E-Mail" autocomplete="off" autocorrect="off" autocapitalize="off" spellcheck="off" name="email" type="email">
                        </div>
                        <button class="button-green-download-big" type="button">Reset Password</button>
                    </form>

                    <p class="bottom-msg">
                        <a class="login-nav-btn" href="javascript:void(0)">Back to login</a>
                    </p>
                </div>

                <div class="modal-loading-content">
                    <img src="/assets/images/website/ajax-spinner.gif" alt="ajax spinner loading" />
                    <p class="info-msg"> Loading, please wait </p>
                </div>
            </div>
        </div>
    </div>

    <div class="main-content">
        <div id="mobile-search-input" class="hidden-md hidden-lg">
            <form method="POST" action="https://yts.ag/search-movies" accept-charset="UTF-8">
                <input name="_token" type="hidden" value="5Vsj4rOZCMfjkM0xlHYsRx2mEprlxRFY00QpuxLp">
                <div class="input-group container search-query">
                    <input class="form-control" placeholder="Search for a movie&hellip;" autocorrect="off" autocomplete="off" name="keyword" type="search">
                    <span class="input-group-btn"> <button class="btn btn-success" type="submit">Search</button> </span>
                </div>
                <div class="container">
                    <div class="row">
                        <div class="col-xs-10">
                            <div class="selects-container">
                                <p>Quality:</p>
                                <select name="quality">
                                    <option value="all" selected="selected">All</option>
                                    <option value="720p">720p</option>
                                    <option value="1080p">1080p</option>
                                    <option value="3D">3D</option>
                                </select>
                            </div>
                            <div class="selects-container">
                                <p>Genre:</p>
                                <select name="genre">
                                    <option value="all" selected="selected">All</option>
                                                                            <option value="action">Action</option>
                                                                            <option value="adventure">Adventure</option>
                                                                            <option value="animation">Animation</option>
                                                                            <option value="biography">Biography</option>
                                                                            <option value="comedy">Comedy</option>
                                                                            <option value="crime">Crime</option>
                                                                            <option value="documentary">Documentary</option>
                                                                            <option value="drama">Drama</option>
                                                                            <option value="family">Family</option>
                                                                            <option value="fantasy">Fantasy</option>
                                                                            <option value="film-noir">Film-Noir</option>
                                                                            <option value="game-show">Game-Show</option>
                                                                            <option value="history">History</option>
                                                                            <option value="horror">Horror</option>
                                                                            <option value="music">Music</option>
                                                                            <option value="musical">Musical</option>
                                                                            <option value="mystery">Mystery</option>
                                                                            <option value="news">News</option>
                                                                            <option value="reality-tv">Reality-TV</option>
                                                                            <option value="romance">Romance</option>
                                                                            <option value="sci-fi">Sci-Fi</option>
                                                                            <option value="sport">Sport</option>
                                                                            <option value="talk-show">Talk-Show</option>
                                                                            <option value="thriller">Thriller</option>
                                                                            <option value="war">War</option>
                                                                            <option value="western">Western</option>
                                                                    </select>
                            </div>
                        </div>
                        <div class="col-xs-10">
                            <div class="selects-container">
                                <p>Rating:</p>
                                <select name="rating">
                                    <option value="0" selected="selected">All</option>
                                    <option value="9">9+</option>
                                    <option value="8">8+</option>
                                    <option value="7">7+</option>
                                    <option value="6">6+</option>
                                    <option value="5">5+</option>
                                    <option value="4">4+</option>
                                    <option value="3">3+</option>
                                    <option value="2">2+</option>
                                    <option value="1">1+</option>
                                </select>
                            </div>
                            <div class="selects-container selects-container-last">
                                <p>Order By:</p>
                                <select name="order_by">
                                    <option value="latest" selected="selected">Latest</option>
                                    <option value="oldest">Oldest</option>
                                    <option value="seeds">Seeds</option>
                                    <option value="peers">Peers</option>
                                    <option value="year">Year</option>
                                    <option value="rating">Rating</option>
                                    <option value="likes">Likes</option>
                                    <option value="alphabetical">Alphabetical</option>
                                    <option value="downloads">Downloads</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <div class="ac-results hidden-sm hidden-xs">
            <ul></ul>
        </div>

        <noscript>
            <div class="container">
                <div class="row">
                    <div class="col-xs-20 text-center">
                        <p class="no-javascript-warning">Javascript not supported on your browser, please enable Javascript in order to fully utilize the website</p>
                    </div>
                </div>
            </div>
        </noscript>

<div id="main-search" class="content-dark hidden-sm hidden-xs">
    <div class="container">
        <form method="post" action="https://yts.ag/search-movies" accept-charset="UTF-8">
            <input name="_token" type="hidden" value="UZzXxauUHxorVLoOQBJB57aJI7kEaVllrx4E9HpP">

            <div id="main-search-fields">
                <p class="pull-left term">Search Term:</p>
                <input name="keyword" autocomplete="off" type="search">

                <div class="selects-container">
                    <p>Quality:</p>
                    <select name="quality">
                        <option value="all" selected="selected">All</option>
                        <option value="720p">720p</option>
                        <option value="1080p">1080p</option>
                        <option value="3D">3D</option>
                    </select>
                </div>

                <div class="selects-container">
                    <p>Genre:</p>
                    <select name="genre">
                        <option value="all" selected="selected">All</option>
                                                            <option value="action">Action</option>
                                                            <option value="adventure">Adventure</option>
                                                            <option value="animation">Animation</option>
                                                            <option value="biography">Biography</option>
                                                            <option value="comedy">Comedy</option>
                                                            <option value="crime">Crime</option>
                                                            <option value="documentary">Documentary</option>
                                                            <option value="drama">Drama</option>
                                                            <option value="family">Family</option>
                                                            <option value="fantasy">Fantasy</option>
                                                            <option value="film-noir">Film-Noir</option>
                                                            <option value="game-show">Game-Show</option>
                                                            <option value="history">History</option>
                                                            <option value="horror">Horror</option>
                                                            <option value="music">Music</option>
                                                            <option value="musical">Musical</option>
                                                            <option value="mystery">Mystery</option>
                                                            <option value="news">News</option>
                                                            <option value="reality-tv">Reality-TV</option>
                                                            <option value="romance">Romance</option>
                                                            <option value="sci-fi">Sci-Fi</option>
                                                            <option value="sport">Sport</option>
                                                            <option value="talk-show">Talk-Show</option>
                                                            <option value="thriller">Thriller</option>
                                                            <option value="war">War</option>
                                                            <option value="western">Western</option>
                                                </select>
                </div>

                <div class="selects-container">
                    <p>Rating:</p>
                    <select name="rating">
                        <option value="0" selected="selected">All</option>
                        <option value="9">9+</option>
                        <option value="8">8+</option>
                        <option value="7">7+</option>
                        <option value="6">6+</option>
                        <option value="5">5+</option>
                        <option value="4">4+</option>
                        <option value="3">3+</option>
                        <option value="2">2+</option>
                        <option value="1">1+</option>
                    </select>
                </div>

                <div class="selects-container selects-container-last">
                    <p>Order By:</p>
                    <select name="order_by">
                        <option value="latest" selected="selected">Latest</option>
                        <option value="oldest">Oldest</option>
                        <option value="seeds">Seeds</option>
                        <option value="peers">Peers</option>
                        <option value="year">Year</option>
                        <option value="rating">Rating</option>
                        <option value="likes">Likes</option>
                        <option value="alphabetical">Alphabetical</option>
                        <option value="downloads">Downloads</option>
                    </select>
                </div>
            </div>

            <div id="main-search-btn">
                <input class="button-green-download-big" type="submit" value="Search">
            </div>
        </form>
    </div>
</div>

<div class="browse-content">
    <div class="container">
        <h2>4,279 Movies Found</h2>

        <div class="hidden-sm hidden-xs">
            <ul class="tsc_pagination tsc_paginationA tsc_paginationA06">
                <li class="hidden"><a href="">&laquo;</a></li><li><a href="javascript:void(0)" class="current">1</a></li><li><a href="/browse-movies/0/all/all/0/latest?page=2">2</a></li><li><a href="/browse-movies/0/all/all/0/latest?page=3">3</a></li><li><a href="/browse-movies/0/all/all/0/latest?page=4">4</a></li><li><a href="/browse-movies/0/all/all/0/latest?page=5">5</a></li><li><a href="/browse-movies/0/all/all/0/latest?page=6">6</a></li><li><a href="/browse-movies/0/all/all/0/latest?page=7">7</a></li><li><a href="/browse-movies/0/all/all/0/latest?page=8">8</a></li><li class="unavailable">...</li><li><a href="/browse-movies/0/all/all/0/latest?page=213">213</a></li><li><a href="/browse-movies/0/all/all/0/latest?page=214">214</a></li><li><a href="/browse-movies/0/all/all/0/latest?page=2">Next &raquo;</a></li><li><a href="/browse-movies/0/all/all/0/latest?page=214">Last &raquo;</a></li>
            </ul>
        </div>

        <div class="hidden-md hidden-lg">
            <ul class="tsc_pagination tsc_paginationA tsc_paginationA06">

                <li class="pagination-bordered">1 of 214</li>

                                    <li><a href="/browse-movies?page=1">Next &raquo;</a></li>
                            </ul>
        </div>

        <section>
            <div class="row">
                                    <div class="browse-movie-wrap col-xs-10 col-sm-4 col-md-5 col-lg-4">
                        <a href="https://yts.ag/movie/inside-out-2015" class="browse-movie-link">
                            <figure>
                                <img class="img-responsive" src="https://yts.ag/assets/images/movies/inside_out_2015/medium-cover.jpg" alt="Inside Out (2015) download">
                                <figcaption class="hidden-xs hidden-sm">
                                    <span class="icon-star"></span>
                                    <h4 class="rating">8.40 / 10</h4>
                                                                            <h4>Adventure</h4>
                                                                            <h4>Animation</h4>
                                                                            <h4>Comedy</h4>
                                                                            <h4>Drama</h4>
                                                                            <h4>Family</h4>
                                                                            <h4>Fantasy</h4>
                                                                        <span class="button-green-download-big">View Details</span>
                                </figcaption>
                            </figure>
                        </a>

                        <div class="browse-movie-bottom">
                            <a href="https://yts.ag/movie/inside-out-2015" class="browse-movie-title">Inside Out</a>
                            <div class="browse-movie-year">2015</div>
                            <div class="browse-movie-tags">
                                                                    <a href="https://yts.ag/torrent/download/C54EA210FC98A6C7E7F29597E2B89921A412FAF5.torrent">3D</a>
                                                                    <a href="https://yts.ag/torrent/download/4B3DCE31C713B02726F67E2EF49DE9FF965EC3B7.torrent">720p</a>
                                                                    <a href="https://yts.ag/torrent/download/556BE0BD40C4880E29BA567663C65BD8BAE9FBEB.torrent">1080p</a>
                                                            </div>
                        </div>
                    </div>
                                    <div class="browse-movie-wrap col-xs-10 col-sm-4 col-md-5 col-lg-4">
                        <a href="https://yts.ag/movie/the-reivers-1969" class="browse-movie-link">
                            <figure>
                                <img class="img-responsive" src="https://yts.ag/assets/images/movies/the_reivers_1969/medium-cover.jpg" alt="The Reivers (1969) download">
                                <figcaption class="hidden-xs hidden-sm">
                                    <span class="icon-star"></span>
                                    <h4 class="rating">6.90 / 10</h4>
                                                                            <h4>Comedy</h4>
                                                                            <h4>Drama</h4>
                                                                        <span class="button-green-download-big">View Details</span>
                                </figcaption>
                            </figure>
                        </a>

                        <div class="browse-movie-bottom">
                            <a href="https://yts.ag/movie/the-reivers-1969" class="browse-movie-title">The Reivers</a>
                            <div class="browse-movie-year">1969</div>
                            <div class="browse-movie-tags">
                                                                    <a href="https://yts.ag/torrent/download/11C5B90E08F90955EC1240C7F881DCD39ACEC7C7.torrent">1080p</a>
                                                            </div>
                        </div>
                    </div>
                                    <div class="browse-movie-wrap col-xs-10 col-sm-4 col-md-5 col-lg-4">
                        <a href="https://yts.ag/movie/the-wizard-of-gore-1970" class="browse-movie-link">
                            <figure>
                                <img class="img-responsive" src="https://yts.ag/assets/images/movies/the_wizard_of_gore_1970/medium-cover.jpg" alt="The Wizard of Gore (1970) download">
                                <figcaption class="hidden-xs hidden-sm">
                                    <span class="icon-star"></span>
                                    <h4 class="rating">5.50 / 10</h4>
                                                                            <h4>Horror</h4>
                                                                        <span class="button-green-download-big">View Details</span>
                                </figcaption>
                            </figure>
                        </a>

                        <div class="browse-movie-bottom">
                            <a href="https://yts.ag/movie/the-wizard-of-gore-1970" class="browse-movie-title">The Wizard of Gore</a>
                            <div class="browse-movie-year">1970</div>
                            <div class="browse-movie-tags">
                                                                    <a href="https://yts.ag/torrent/download/F3192124BFDF0169EAC415950A50F1CDD3B515F7.torrent">720p</a>
                                                                    <a href="https://yts.ag/torrent/download/179224C50340A9DEF377FCED5580290BF5B2AF19.torrent">1080p</a>
                                                            </div>
                        </div>
                    </div>
                                    <div class="browse-movie-wrap col-xs-10 col-sm-4 col-md-5 col-lg-4">
                        <a href="https://yts.ag/movie/dracula-the-impaler-2013" class="browse-movie-link">
                            <figure>
                                <img class="img-responsive" src="https://yts.ag/assets/images/movies/dracula_the_impaler_2013/medium-cover.jpg" alt="Dracula: The Impaler (2013) download">
                                <figcaption class="hidden-xs hidden-sm">
                                    <span class="icon-star"></span>
                                    <h4 class="rating">3.90 / 10</h4>
                                                                            <h4>Action</h4>
                                                                            <h4>Horror</h4>
                                                                            <h4>Thriller</h4>
                                                                        <span class="button-green-download-big">View Details</span>
                                </figcaption>
                            </figure>
                        </a>

                        <div class="browse-movie-bottom">
                            <a href="https://yts.ag/movie/dracula-the-impaler-2013" class="browse-movie-title">Dracula: The Impaler</a>
                            <div class="browse-movie-year">2013</div>
                            <div class="browse-movie-tags">
                                                                    <a href="https://yts.ag/torrent/download/88323B2DC709A2B3049BDACC38C9B66C0AD9B1AF.torrent">720p</a>
                                                                    <a href="https://yts.ag/torrent/download/54829D0830560BE08299227A3597FAA1B8355AE1.torrent">1080p</a>
                                                            </div>
                        </div>
                    </div>
                                    <div class="browse-movie-wrap col-xs-10 col-sm-4 col-md-5 col-lg-4">
                        <a href="https://yts.ag/movie/a-nightingale-falling-2014" class="browse-movie-link">
                            <figure>
                                <img class="img-responsive" src="https://yts.ag/assets/images/movies/a_nightingale_falling_2014/medium-cover.jpg" alt="A Nightingale Falling (2014) download">
                                <figcaption class="hidden-xs hidden-sm">
                                    <span class="icon-star"></span>
                                    <h4 class="rating">5.80 / 10</h4>
                                                                            <h4>Drama</h4>
                                                                            <h4>History</h4>
                                                                            <h4>War</h4>
                                                                        <span class="button-green-download-big">View Details</span>
                                </figcaption>
                            </figure>
                        </a>

                        <div class="browse-movie-bottom">
                            <a href="https://yts.ag/movie/a-nightingale-falling-2014" class="browse-movie-title">A Nightingale Falling</a>
                            <div class="browse-movie-year">2014</div>
                            <div class="browse-movie-tags">
                                                                    <a href="https://yts.ag/torrent/download/30E88CD34ABC2666C0DDC6E43B88704F630D07AE.torrent">1080p</a>
                                                            </div>
                        </div>
                    </div>
                                    <div class="browse-movie-wrap col-xs-10 col-sm-4 col-md-5 col-lg-4">
                        <a href="https://yts.ag/movie/the-smoke-2014" class="browse-movie-link">
                            <figure>
                                <img class="img-responsive" src="https://yts.ag/assets/images/movies/the_smoke_2014/medium-cover.jpg" alt="The Smoke (2014) download">
                                <figcaption class="hidden-xs hidden-sm">
                                    <span class="icon-star"></span>
                                    <h4 class="rating">4.20 / 10</h4>
                                                                            <h4>Crime</h4>
                                                                            <h4>Romance</h4>
                                                                            <h4>Thriller</h4>
                                                                        <span class="button-green-download-big">View Details</span>
                                </figcaption>
                            </figure>
                        </a>

                        <div class="browse-movie-bottom">
                            <a href="https://yts.ag/movie/the-smoke-2014" class="browse-movie-title">The Smoke</a>
                            <div class="browse-movie-year">2014</div>
                            <div class="browse-movie-tags">
                                                                    <a href="https://yts.ag/torrent/download/EED7DC762E8AEE4AD79A89D557A83C3ED72ED463.torrent">720p</a>
                                                                    <a href="https://yts.ag/torrent/download/9490567BB9E16DE3D9852D079083CB2516C0085F.torrent">1080p</a>
                                                            </div>
                        </div>
                    </div>
                                    <div class="browse-movie-wrap col-xs-10 col-sm-4 col-md-5 col-lg-4">
                        <a href="https://yts.ag/movie/t-force-1994" class="browse-movie-link">
                            <figure>
                                <img class="img-responsive" src="https://yts.ag/assets/images/movies/t_force_1994/medium-cover.jpg" alt="T-Force (1994) download">
                                <figcaption class="hidden-xs hidden-sm">
                                    <span class="icon-star"></span>
                                    <h4 class="rating">4.30 / 10</h4>
                                                                            <h4>Action</h4>
                                                                            <h4>Sci-Fi</h4>
                                                                        <span class="button-green-download-big">View Details</span>
                                </figcaption>
                            </figure>
                        </a>

                        <div class="browse-movie-bottom">
                            <a href="https://yts.ag/movie/t-force-1994" class="browse-movie-title">T-Force</a>
                            <div class="browse-movie-year">1994</div>
                            <div class="browse-movie-tags">
                                                                    <a href="https://yts.ag/torrent/download/805A2A714F5D93FA7610226F70C094953329A84E.torrent">720p</a>
                                                                    <a href="https://yts.ag/torrent/download/2B438F871DC443A92BEC8BE4762D7EF9483C551B.torrent">1080p</a>
                                                            </div>
                        </div>
                    </div>
                                    <div class="browse-movie-wrap col-xs-10 col-sm-4 col-md-5 col-lg-4">
                        <a href="https://yts.ag/movie/bikini-model-academy-2015" class="browse-movie-link">
                            <figure>
                                <img class="img-responsive" src="https://yts.ag/assets/images/movies/bikini_model_academy_2015/medium-cover.jpg" alt="Bikini Model Academy (2015) download">
                                <figcaption class="hidden-xs hidden-sm">
                                    <span class="icon-star"></span>
                                    <h4 class="rating">2.00 / 10</h4>
                                                                            <h4>Comedy</h4>
                                                                        <span class="button-green-download-big">View Details</span>
                                </figcaption>
                            </figure>
                        </a>

                        <div class="browse-movie-bottom">
                            <a href="https://yts.ag/movie/bikini-model-academy-2015" class="browse-movie-title">Bikini Model Academy</a>
                            <div class="browse-movie-year">2015</div>
                            <div class="browse-movie-tags">
                                                                    <a href="https://yts.ag/torrent/download/80F67E2D236A1A2854876F6A409C92D2D54C3849.torrent">720p</a>
                                                                    <a href="https://yts.ag/torrent/download/BA2DD0FB35E9055372873D420E5C951CD41D6A8F.torrent">1080p</a>
                                                            </div>
                        </div>
                    </div>
                                    <div class="browse-movie-wrap col-xs-10 col-sm-4 col-md-5 col-lg-4">
                        <a href="https://yts.ag/movie/knock-knock-2015" class="browse-movie-link">
                            <figure>
                                <img class="img-responsive" src="https://yts.ag/assets/images/movies/knock_knock_2015/medium-cover.jpg" alt="Knock Knock (2015) download">
                                <figcaption class="hidden-xs hidden-sm">
                                    <span class="icon-star"></span>
                                    <h4 class="rating">5.00 / 10</h4>
                                                                            <h4>Horror</h4>
                                                                            <h4>Mystery</h4>
                                                                            <h4>Thriller</h4>
                                                                        <span class="button-green-download-big">View Details</span>
                                </figcaption>
                            </figure>
                        </a>

                        <div class="browse-movie-bottom">
                            <a href="https://yts.ag/movie/knock-knock-2015" class="browse-movie-title">Knock Knock</a>
                            <div class="browse-movie-year">2015</div>
                            <div class="browse-movie-tags">
                                                                    <a href="https://yts.ag/torrent/download/942CCE48B49CCB80950834B60099870AFBB6DFFF.torrent">720p</a>
                                                                    <a href="https://yts.ag/torrent/download/9C1942F9789D7B704C3AB8B1A076101303466AA8.torrent">1080p</a>
                                                            </div>
                        </div>
                    </div>
                                    <div class="browse-movie-wrap col-xs-10 col-sm-4 col-md-5 col-lg-4">
                        <a href="https://yts.ag/movie/badge-of-honor-2015" class="browse-movie-link">
                            <figure>
                                <img class="img-responsive" src="https://yts.ag/assets/images/movies/badge_of_honor_2015/medium-cover.jpg" alt="Badge of Honor (2015) download">
                                <figcaption class="hidden-xs hidden-sm">
                                    <span class="icon-star"></span>
                                    <h4 class="rating">4.40 / 10</h4>
                                                                            <h4>Crime</h4>
                                                                            <h4>Drama</h4>
                                                                            <h4>Thriller</h4>
                                                                        <span class="button-green-download-big">View Details</span>
                                </figcaption>
                            </figure>
                        </a>

                        <div class="browse-movie-bottom">
                            <a href="https://yts.ag/movie/badge-of-honor-2015" class="browse-movie-title">Badge of Honor</a>
                            <div class="browse-movie-year">2015</div>
                            <div class="browse-movie-tags">
                                                                    <a href="https://yts.ag/torrent/download/18C389C09A24FA25B129685A3E75A570079E52DA.torrent">720p</a>
                                                            </div>
                        </div>
                    </div>
                                    <div class="browse-movie-wrap col-xs-10 col-sm-4 col-md-5 col-lg-4">
                        <a href="https://yts.ag/movie/chloe-and-theo-2015" class="browse-movie-link">
                            <figure>
                                <img class="img-responsive" src="https://yts.ag/assets/images/movies/chloe_and_theo_2015/medium-cover.jpg" alt="Chloe & Theo (2015) download">
                                <figcaption class="hidden-xs hidden-sm">
                                    <span class="icon-star"></span>
                                    <h4 class="rating">5.70 / 10</h4>
                                                                            <h4>Comedy</h4>
                                                                            <h4>Drama</h4>
                                                                        <span class="button-green-download-big">View Details</span>
                                </figcaption>
                            </figure>
                        </a>

                        <div class="browse-movie-bottom">
                            <a href="https://yts.ag/movie/chloe-and-theo-2015" class="browse-movie-title">Chloe & Theo</a>
                            <div class="browse-movie-year">2015</div>
                            <div class="browse-movie-tags">
                                                                    <a href="https://yts.ag/torrent/download/06A33E0B7C9029704811D8E31D07A72EEB5100CD.torrent">720p</a>
                                                                    <a href="https://yts.ag/torrent/download/B1E4CAC0083F0E70F8E7143096DE339DFA2746ED.torrent">1080p</a>
                                                            </div>
                        </div>
                    </div>
                                    <div class="browse-movie-wrap col-xs-10 col-sm-4 col-md-5 col-lg-4">
                        <a href="https://yts.ag/movie/the-harder-they-come-1972" class="browse-movie-link">
                            <figure>
                                <img class="img-responsive" src="https://yts.ag/assets/images/movies/the_harder_they_come_1972/medium-cover.jpg" alt="The Harder They Come (1972) download">
                                <figcaption class="hidden-xs hidden-sm">
                                    <span class="icon-star"></span>
                                    <h4 class="rating">7.10 / 10</h4>
                                                                            <h4>Crime</h4>
                                                                            <h4>Drama</h4>
                                                                            <h4>Music</h4>
                                                                        <span class="button-green-download-big">View Details</span>
                                </figcaption>
                            </figure>
                        </a>

                        <div class="browse-movie-bottom">
                            <a href="https://yts.ag/movie/the-harder-they-come-1972" class="browse-movie-title">The Harder They Come</a>
                            <div class="browse-movie-year">1972</div>
                            <div class="browse-movie-tags">
                                                                    <a href="https://yts.ag/torrent/download/0435F158C6303AE98CCC1CB1D254507BA1F544A0.torrent">720p</a>
                                                                    <a href="https://yts.ag/torrent/download/206A8517D9DCDD327ADA05EF4079A2C6B156238B.torrent">1080p</a>
                                                            </div>
                        </div>
                    </div>
                                    <div class="browse-movie-wrap col-xs-10 col-sm-4 col-md-5 col-lg-4">
                        <a href="https://yts.ag/movie/infini-2015" class="browse-movie-link">
                            <figure>
                                <img class="img-responsive" src="https://yts.ag/assets/images/movies/infini_2015/medium-cover.jpg" alt="Infini (2015) download">
                                <figcaption class="hidden-xs hidden-sm">
                                    <span class="icon-star"></span>
                                    <h4 class="rating">5.40 / 10</h4>
                                                                            <h4>Horror</h4>
                                                                            <h4>Sci-Fi</h4>
                                                                            <h4>Thriller</h4>
                                                                        <span class="button-green-download-big">View Details</span>
                                </figcaption>
                            </figure>
                        </a>

                        <div class="browse-movie-bottom">
                            <a href="https://yts.ag/movie/infini-2015" class="browse-movie-title">Infini</a>
                            <div class="browse-movie-year">2015</div>
                            <div class="browse-movie-tags">
                                                                    <a href="https://yts.ag/torrent/download/BDCCE89E699C96378747DCBC7DC7B4DA8FC55E98.torrent">720p</a>
                                                            </div>
                        </div>
                    </div>
                                    <div class="browse-movie-wrap col-xs-10 col-sm-4 col-md-5 col-lg-4">
                        <a href="https://yts.ag/movie/sparrows-cant-sing-1963" class="browse-movie-link">
                            <figure>
                                <img class="img-responsive" src="https://yts.ag/assets/images/movies/sparrows_cant_sing_1963/medium-cover.jpg" alt="Sparrows Can't Sing (1963) download">
                                <figcaption class="hidden-xs hidden-sm">
                                    <span class="icon-star"></span>
                                    <h4 class="rating">6.60 / 10</h4>
                                                                            <h4>Comedy</h4>
                                                                            <h4>Drama</h4>
                                                                        <span class="button-green-download-big">View Details</span>
                                </figcaption>
                            </figure>
                        </a>

                        <div class="browse-movie-bottom">
                            <a href="https://yts.ag/movie/sparrows-cant-sing-1963" class="browse-movie-title">Sparrows Can't Sing</a>
                            <div class="browse-movie-year">1963</div>
                            <div class="browse-movie-tags">
                                                                    <a href="https://yts.ag/torrent/download/9AD40BA0AC6CE7B107133F0144384B1277A699D2.torrent">720p</a>
                                                            </div>
                        </div>
                    </div>
                                    <div class="browse-movie-wrap col-xs-10 col-sm-4 col-md-5 col-lg-4">
                        <a href="https://yts.ag/movie/the-pit-and-the-pendulum-1991" class="browse-movie-link">
                            <figure>
                                <img class="img-responsive" src="https://yts.ag/assets/images/movies/the_pit_and_the_pendulum_1991/medium-cover.jpg" alt="The Pit and the Pendulum (1991) download">
                                <figcaption class="hidden-xs hidden-sm">
                                    <span class="icon-star"></span>
                                    <h4 class="rating">6.10 / 10</h4>
                                                                            <h4>Horror</h4>
                                                                        <span class="button-green-download-big">View Details</span>
                                </figcaption>
                            </figure>
                        </a>

                        <div class="browse-movie-bottom">
                            <a href="https://yts.ag/movie/the-pit-and-the-pendulum-1991" class="browse-movie-title">The Pit and the Pendulum</a>
                            <div class="browse-movie-year">1991</div>
                            <div class="browse-movie-tags">
                                                                    <a href="https://yts.ag/torrent/download/5BEB22F8D0CCFD9E38BE6E479EFC60F196919083.torrent">1080p</a>
                                                            </div>
                        </div>
                    </div>
                                    <div class="browse-movie-wrap col-xs-10 col-sm-4 col-md-5 col-lg-4">
                        <a href="https://yts.ag/movie/school-for-scoundrels-1960" class="browse-movie-link">
                            <figure>
                                <img class="img-responsive" src="https://yts.ag/assets/images/movies/school_for_scoundrels_1960/medium-cover.jpg" alt="School for Scoundrels (1960) download">
                                <figcaption class="hidden-xs hidden-sm">
                                    <span class="icon-star"></span>
                                    <h4 class="rating">7.60 / 10</h4>
                                                                            <h4>Comedy</h4>
                                                                        <span class="button-green-download-big">View Details</span>
                                </figcaption>
                            </figure>
                        </a>

                        <div class="browse-movie-bottom">
                            <a href="https://yts.ag/movie/school-for-scoundrels-1960" class="browse-movie-title">School for Scoundrels</a>
                            <div class="browse-movie-year">1960</div>
                            <div class="browse-movie-tags">
                                                                    <a href="https://yts.ag/torrent/download/9916669DACD6BCD9E3AC6E489D4602A9C31588FA.torrent">720p</a>
                                                                    <a href="https://yts.ag/torrent/download/C2D77DA207F6AF0EE52E63F5958E729E5827CAE2.torrent">1080p</a>
                                                            </div>
                        </div>
                    </div>
                                    <div class="browse-movie-wrap col-xs-10 col-sm-4 col-md-5 col-lg-4">
                        <a href="https://yts.ag/movie/the-mountain-1956" class="browse-movie-link">
                            <figure>
                                <img class="img-responsive" src="https://yts.ag/assets/images/movies/the_mountain_1956/medium-cover.jpg" alt="The Mountain (1956) download">
                                <figcaption class="hidden-xs hidden-sm">
                                    <span class="icon-star"></span>
                                    <h4 class="rating">6.80 / 10</h4>
                                                                            <h4>Adventure</h4>
                                                                            <h4>Drama</h4>
                                                                        <span class="button-green-download-big">View Details</span>
                                </figcaption>
                            </figure>
                        </a>

                        <div class="browse-movie-bottom">
                            <a href="https://yts.ag/movie/the-mountain-1956" class="browse-movie-title">The Mountain</a>
                            <div class="browse-movie-year">1956</div>
                            <div class="browse-movie-tags">
                                                                    <a href="https://yts.ag/torrent/download/59B8E5D6BC5C4EEB6C60B7BC16A8D48071C365D3.torrent">720p</a>
                                                                    <a href="https://yts.ag/torrent/download/008ECAA479E1845214285FA736B1416CC5C1EEBC.torrent">1080p</a>
                                                            </div>
                        </div>
                    </div>
                                    <div class="browse-movie-wrap col-xs-10 col-sm-4 col-md-5 col-lg-4">
                        <a href="https://yts.ag/movie/hidden-agenda-1990" class="browse-movie-link">
                            <figure>
                                <img class="img-responsive" src="https://yts.ag/assets/images/movies/hidden_agenda_1990/medium-cover.jpg" alt="Hidden Agenda (1990) download">
                                <figcaption class="hidden-xs hidden-sm">
                                    <span class="icon-star"></span>
                                    <h4 class="rating">7.00 / 10</h4>
                                                                            <h4>Drama</h4>
                                                                            <h4>Thriller</h4>
                                                                        <span class="button-green-download-big">View Details</span>
                                </figcaption>
                            </figure>
                        </a>

                        <div class="browse-movie-bottom">
                            <a href="https://yts.ag/movie/hidden-agenda-1990" class="browse-movie-title">Hidden Agenda</a>
                            <div class="browse-movie-year">1990</div>
                            <div class="browse-movie-tags">
                                                                    <a href="https://yts.ag/torrent/download/53E93DEFBB313CDBD69FBFF0AC7CD66367378401.torrent">720p</a>
                                                                    <a href="https://yts.ag/torrent/download/50789BF160BD2D0960657529E64C6286384F1C98.torrent">1080p</a>
                                                            </div>
                        </div>
                    </div>
                                    <div class="browse-movie-wrap col-xs-10 col-sm-4 col-md-5 col-lg-4">
                        <a href="https://yts.ag/movie/the-cokeville-miracle-2015" class="browse-movie-link">
                            <figure>
                                <img class="img-responsive" src="https://yts.ag/assets/images/movies/the_cokeville_miracle_2015/medium-cover.jpg" alt="The Cokeville Miracle (2015) download">
                                <figcaption class="hidden-xs hidden-sm">
                                    <span class="icon-star"></span>
                                    <h4 class="rating">4.70 / 10</h4>
                                                                            <h4>Drama</h4>
                                                                            <h4>Family</h4>
                                                                            <h4>History</h4>
                                                                            <h4>Mystery</h4>
                                                                            <h4>Thriller</h4>
                                                                        <span class="button-green-download-big">View Details</span>
                                </figcaption>
                            </figure>
                        </a>

                        <div class="browse-movie-bottom">
                            <a href="https://yts.ag/movie/the-cokeville-miracle-2015" class="browse-movie-title">The Cokeville Miracle</a>
                            <div class="browse-movie-year">2015</div>
                            <div class="browse-movie-tags">
                                                                    <a href="https://yts.ag/torrent/download/AC879EC7C30C6A2C96286AABAC6A7909B0131CD3.torrent">1080p</a>
                                                            </div>
                        </div>
                    </div>
                                    <div class="browse-movie-wrap col-xs-10 col-sm-4 col-md-5 col-lg-4">
                        <a href="https://yts.ag/movie/some-kind-of-beautiful-2014" class="browse-movie-link">
                            <figure>
                                <img class="img-responsive" src="https://yts.ag/assets/images/movies/some_kind_of_beautiful_2014/medium-cover.jpg" alt="Some Kind Of Beautiful (2014) download">
                                <figcaption class="hidden-xs hidden-sm">
                                    <span class="icon-star"></span>
                                    <h4 class="rating">5.70 / 10</h4>
                                                                            <h4>Comedy</h4>
                                                                            <h4>Romance</h4>
                                                                        <span class="button-green-download-big">View Details</span>
                                </figcaption>
                            </figure>
                        </a>

                        <div class="browse-movie-bottom">
                            <a href="https://yts.ag/movie/some-kind-of-beautiful-2014" class="browse-movie-title">Some Kind Of Beautiful</a>
                            <div class="browse-movie-year">2014</div>
                            <div class="browse-movie-tags">
                                                                    <a href="https://yts.ag/torrent/download/704BCC3FDB25C32FD99E515C203553A8016C1929.torrent">720p</a>
                                                            </div>
                        </div>
                    </div>
                            </div>
        </section>

        <div class="hidden-sm hidden-xs">
            <ul class="tsc_pagination tsc_paginationA tsc_paginationA06">
                <li class="hidden"><a href="">&laquo;</a></li><li><a href="javascript:void(0)" class="current">1</a></li><li><a href="/browse-movies/0/all/all/0/latest?page=2">2</a></li><li><a href="/browse-movies/0/all/all/0/latest?page=3">3</a></li><li><a href="/browse-movies/0/all/all/0/latest?page=4">4</a></li><li><a href="/browse-movies/0/all/all/0/latest?page=5">5</a></li><li><a href="/browse-movies/0/all/all/0/latest?page=6">6</a></li><li><a href="/browse-movies/0/all/all/0/latest?page=7">7</a></li><li><a href="/browse-movies/0/all/all/0/latest?page=8">8</a></li><li class="unavailable">...</li><li><a href="/browse-movies/0/all/all/0/latest?page=213">213</a></li><li><a href="/browse-movies/0/all/all/0/latest?page=214">214</a></li><li><a href="/browse-movies/0/all/all/0/latest?page=2">Next &raquo;</a></li><li><a href="/browse-movies/0/all/all/0/latest?page=214">Last &raquo;</a></li>
            </ul>
        </div>

        <div class="hidden-md hidden-lg">
            <ul class="tsc_pagination tsc_paginationA tsc_paginationA06">

                <li class="pagination-bordered">1 of 214</li>

                                    <li><a href="/browse-movies?page=1">Next &raquo;</a></li>
                            </ul>
        </div>
    </div>
</div>

        <div class="container hidden-md hidden-lg">
            <div class="row">
                <div class="mobile-footer">
                    <div class="col-sm-20">
                        <a href="https://yts.ag/"> <span class="glyphicon glyphicon-home"></span> <p>Home</p> </a>
                        <a href="https://yts.ag/browse-movies"> <span class="glyphicon glyphicon-list-alt"></span> <p>Browse</p> </a>
                        <a href="https://yts.ag/login"> <span class="glyphicon glyphicon-log-in"></span> <p>Login</p> </a>
                    </div>

                    <div class="col-sm-20">
                        <a href="https://yts.ag/register"> <span class="glyphicon glyphicon-user"></span> <p>Register</p> </a>
                        <a href="https://yts.ag/requests"> <span class="glyphicon glyphicon-asterisk"></span> <p>Requests</p> </a>
                        <a href="https://yts.ag/suggestions"> <span class="glyphicon glyphicon-pushpin"></span> <p>Suggestions</p> </a>
                    </div>
                </div>
            </div>
        </div>



        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-xs-20">
                        <ul class="text-center">
                            <li>YTS &copy; 2011 - 2015</li>
                            <li>-</li>
                            <li><a href="https://yts.ag/blog">Blog</a></li>
                            <li>-</li>
                            <li><a href="https://yts.ag/dmca">DMCA</a></li>
                            <li>-</li>
                            <li><a href="https://yts.ag/api">API</a></li>
                            <li>-</li>
                            <li><a href="https://yts.ag/rss-guide">RSS</a></li>
                            <li>-</li>
                            <li><a href="https://yts.ag/contact">Contact</a></li>
                            <li>-</li>
                            <li><a href="https://yts.ag/browse-movies">Browse Movies</a></li>
                            <li>-</li>
                            <li><a href="https://yts.ag/login">Login</a></li>

                        </ul>
                    </div>
                </div>

                <div class="row">
                    <div class="col-xs-20">
                        <ul class="text-center">
                            <li><a href="http://www.yifysubtitles.com/" target="_blank" rel="nofollow">YIFYSubtitles</a></li>
                            <li>-</li>
                            <li><a href="https://www.facebook.com/YIFYTORRENTS" target="_blank" rel="nofollow"><span class="icon-facebook"></span></a></li>

                        </ul>
                    </div>
                </div>
            </div>
        </footer>
    </div>

    <script type="text/javascript" src="/assets/minified/b0f127a10831e175bbf44e730789dd85.js"></script>
</body>
</html>
'''

# read from URL
import bs4
soup = bs4.BeautifulSoup(data)
links = soup.select("div.browse-movie-bottom")

# Storage information
for div in links:
    baseTitle = div.a.text  #title
    aList = div.select("div a")
    for a in aList:
        title = baseTitle + ' ' + a.text
        urlSource = a["href"]
        print title, urlSource[urlSource.rfind("/")+1:-8]

    # title = a.get("title", a.text)
    # urlSource = a["href"]