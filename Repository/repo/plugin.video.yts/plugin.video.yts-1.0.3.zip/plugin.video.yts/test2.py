# coding: utf-8
__author__ = 'Ruben'
import requests
import bs4
keyword = ""
quality = "720p"
genre = "all"
rating = "0"
order_by = "latest"
page = "1"

browser = requests.Session()
urlSearch = "https://yts.ag"
browser.headers[
    'User-agent'] = 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/44.0.2403.157 Safari/537.36'
browser.headers['Accept-Language']='en'

response = browser.get(urlSearch)
soup = bs4.BeautifulSoup(response.text)
itemToken = soup.select("div#mobile-search-input input")
token = itemToken[0]["value"]  # hidden token
print token
# Read
# payload = {
#     "keyword": keyword,
#     "_token": token,
#     "quality": quality,
#     "genre": genre,
#     "rating": rating,
#     "order_by": order_by,
# }
#
# print(payload)
# response = browser.post(urlSearch + "/search-movies", data=payload)
# print(response.text)

#read the result

urlSearch = urlSearch + "/browse-movies/0/%s/%s/%s/%s?page=%s" % (quality, genre, rating, order_by, page)
print urlSearch
#urlSearch = "https://yts.ag/browse-movies/0/720p/all/0/latest"
print urlSearch
response = browser.get(urlSearch)
print(response.text)


