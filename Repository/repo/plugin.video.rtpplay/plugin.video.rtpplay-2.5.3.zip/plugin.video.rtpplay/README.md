plugin.video.RTPPlay-XBMC
=========================

RTPPlay Video addon for XBMC/Kodi 
