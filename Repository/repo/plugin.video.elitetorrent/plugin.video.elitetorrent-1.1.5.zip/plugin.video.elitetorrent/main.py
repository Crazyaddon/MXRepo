# coding: utf-8
# Main Addon
__author__ = 'mancuniancol'

from xbmcswift2 import Plugin
from tools2 import *


##INITIALISATION
storage = Storage(settings.storageName, type="dict")
plugin = Plugin()


###############################
###  MENU    ##################
###############################
@plugin.route('/')
def index():
    textViewer(settings.string(32000), once=True)
    items = [
        {'label': "Busqueda Manual",
         'path': plugin.url_for('search'),
         'thumbnail': dirImages("busqueda-manual.png"),
         'properties': {'fanart_image': settings.fanart}
         }]
    listTypes = ['Estrenos',
                 'Peliculas',
                 'Peliculas HDRip',
                 'Peliculas MicroHD',
                 'Series',
                 'Series VOSE',
                 'Docus y TV']
    listUrl = ['/categoria/1/estrenos/modo:listado/pag:',
               '/categoria/2/peliculas/modo:listado/pag:',
               '/categoria/13/peliculas-hdrip/modo:listado/pag:',
               '/categoria/17/peliculas-microhd/pag:',
               '/categoria/4/series/modo:listado/pag:',
               '/categoria/16/series-vose/modo:listado/pag:',
               '/categoria/6/docus-y-tv/pag:'
               ]
    listIcons = [dirImages("estrenos.png"),
                 dirImages("peliculas.png"),
                 dirImages("peliculas-hdrip.png"),
                 dirImages("peliculas-microhd.png"),
                 dirImages("series.png"),
                 dirImages("series-vose.png"),
                 dirImages("documentales.png"),
                 ]
    for type, url, icon in zip(listTypes, listUrl, listIcons):
        if type in storage.database.keys():
            importInfo = (settings.string(32001),
                          'XBMC.Container.Update(%s)' % plugin.url_for('unsubscribe', key=type))
        else:
            importInfo = (settings.string(32002),
                          'XBMC.Container.Update(%s)' % plugin.url_for('subscribe', key=type, url=url))
        items.append({'label': type,
                      'path': plugin.url_for('readItems', url=url),
                      'thumbnail': icon,
                      'properties': {'fanart_image': settings.fanart},
                      'context_menu': [importInfo, (plugin.get_string(32009),
                                                    'XBMC.RunPlugin(%s)' % plugin.url_for('importAll', url=url))]
                      })
    items.append({'label': "Ayuda",
                  'path': plugin.url_for('help'),
                  'thumbnail': dirImages("ayuda.png"),
                  'properties': {'fanart_image': settings.fanart}
                  })
    return items


@plugin.route('/help/')
def help():
    textViewer(plugin.get_string(32000), once=False)


@plugin.route('/search/')
def search():
    query = settings.dialog.input("Cual película buscar?")
    url = "/busqueda/%s/pag:" % query
    return readItems(url)


@plugin.route('/play/<url>')
def play(url):
    magnet = url
    # Set-up the plugin
    uri_string = quote_plus(getPlayableLink(uncodeName(magnet)))
    if settings.value["plugin"] == 'Pulsar':
        link = 'plugin://plugin.video.pulsar/play?uri=%s' % uri_string
    elif settings.value["plugin"] == 'KmediaTorrent':
        link = 'plugin://plugin.video.kmediatorrent/play/%s' % uri_string
    elif settings.value["plugin"] == "Torrenter":
        link = 'plugin://plugin.video.torrenter/?action=playSTRM&url=' + uri_string + \
               '&not_download_only=True'
    elif settings.value["plugin"] == "YATP":
        link = 'plugin://plugin.video.yatp/?action=play&torrent=' + uri_string
    else:
        link = 'plugin://plugin.video.xbmctorrent/play/%s' % uri_string
    # play media
    settings.debug("PlayMedia(%s)" % link)
    xbmc.executebuiltin("PlayMedia(%s)" % link)


@plugin.route('/importOne/<title>')
def importOne(title=""):
    information = plugin.get_storage('information')
    info = information[title]
    integration(titles=[info.title], magnets=[info.fileName], id=[info.id], typeVideo=[info.typeVideo], silence=True)


@plugin.route('/unsubscribe/<key>')
def unsubscribe(key=""):
    storage.remove(key)
    storage.save()


@plugin.route('/subscribe/<key>/<url>')
def subscribe(key="", url=""):
    storage.add(key, url)
    storage.save()
    importAll(key, url)


@plugin.route('/importAll/<url>')
def importAll(url=""):
    items = readItems(url)  # only to create information
    information = plugin.get_storage('information')
    titles = []
    magnets = []
    typeVideo = []
    id = []
    # read information from Storage
    for key in information:
        titles.append(information[key].title)
        magnets.append(information[key].fileName)
        typeVideo.append(information[key].typeVideo)
        id.append(information[key].id)
    integration(titles=titles, magnets=magnets, id=id, typeVideo=typeVideo, silence=True)


@plugin.route('/readItems/<url>', name="readItems")
@plugin.route('/nextPage/<url>/<page>', name="nextPage")
def readItems(url="", page="1"):
    # read from URL
    settings.log(settings.value["urlAddress"] + url + page)
    response = browser.get(settings.value["urlAddress"] + url + page)
    soup = bs4.BeautifulSoup(response.text)
    links = soup.select("a.nombre")

    #Storage information
    information = plugin.get_storage('information')
    information.clear()
    information.sync()

    # Items Menu Creation
    items = []
    typeVideo = ""
    for a in links:
        title = a.get("title", "")
        urlSource = settings.value["urlAddress"] + a["href"]
        info = UnTaggle(title, urlSource)  # it gets all the information from the title and url
        information[title] = info  # save for importAll
        typeVideo = info.typeVideo
        try:
            items.append({'label': info.label,
                          'path': plugin.url_for('play', url=urlSource),
                          'thumbnail': info.cover,
                          'properties': {'fanart_image': info.fanart},
                          'info': info.info,
                          'stream_info': info.infoStream,
                          'is_playable': True,
                          'context_menu': [
                              (plugin.get_string(32009),
                               'XBMC.RunPlugin(%s)' % plugin.url_for('importOne', title=title))
                          ]
                          })
        except:
            pass
    information.sync()
    # SetContent
    if typeVideo != "MOVIE":
        typeVideo = "episodes"
    else:
        typeVideo = "movies"
    # main
    if __name__ == '__main__':
        plugin.set_content(typeVideo)
    # next page
    items.append({'label': "Página Siguiente..",
                  'path': plugin.url_for('nextPage', url=url, page=int(page) + 1),
                  'thumbnail': settings.icon,
                  'properties': {'fanart_image': settings.fanart}
                  })
    return plugin.finish(items=items, view_mode=settings.value['viewMode'])


if __name__ == '__main__':
    plugin.run()
