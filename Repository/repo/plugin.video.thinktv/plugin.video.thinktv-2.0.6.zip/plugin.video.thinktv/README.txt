plugin.video.thinktv
================

Kodi Video V2 Addon for PBS ThinkTV
For Kodi Isengard and above releases

Version 2.0.6 added Next Page for shows
Version 2.0.5 fixed Codancy issue with infoList
Version 2.0.4 added local PBS programs
Version 2.0.3 add/del favorites & watchlist
Version 2.0.2 add login, next page,  PBS favorites and Watchlist
Version 2.0.1 initial release

