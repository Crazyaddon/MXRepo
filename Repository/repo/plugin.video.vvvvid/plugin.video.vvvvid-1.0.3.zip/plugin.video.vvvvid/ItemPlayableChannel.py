

class ItemPlayableChannel():
    title = ''
    thumb = ''
    show_id = 0
    id=0
    ondemand_type = 0
    show_type = 0
    seasons = []


    
    
    
    