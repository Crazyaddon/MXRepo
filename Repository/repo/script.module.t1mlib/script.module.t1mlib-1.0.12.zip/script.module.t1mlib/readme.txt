script.module.t1mlib
================

Library of support routines for t1m addons

V1.0.12 added post to getRequest
V1.0.11 add doFunction
V1.0.10 subtitle dxfp - > srt cleanup
V1.0.9 fix issue with unicode in url
V1.0.8 use setArt instead of init parms for ListItem
V1.0.7 cleanup for release
V1.0.6 fix for subtitles
V1.0.5 added getAddonCats
V1.0.4 fix request headers init
V1.0.3 cleanup
V1.0.2 fix for unicode
V1.0.1 Initial version
