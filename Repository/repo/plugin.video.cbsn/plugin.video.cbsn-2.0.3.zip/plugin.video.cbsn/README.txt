plugin.video.cbsn
================

Kodi Video V2 Addon for CBS News Live
For Kodi Isengard and above releases

Version 2.0.3 website change (live url)
Version 2.0.2 cleanup for release
Version 2.0.1 initial release

