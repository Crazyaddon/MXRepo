putio-xbmc-v2
=============

Put.io xbmc addon with api v2
xbmc.put.io-v2/ folder is the xbmc addon

Tried and works with xbmc v12 frodo.


