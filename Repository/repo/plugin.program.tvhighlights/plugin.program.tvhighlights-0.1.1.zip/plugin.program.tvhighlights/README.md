Beschreibung:
=============

Das Plugin plugin.program.tvhighlights holt von tvdigital.de die TV-Highlights des Tages und stellt diese dann als 
RecentlyAdded Widget beim Menüpunkt TV bereit (nach Skintegration).
Es kann im Settingsmenü eingestellt werden welche Kategorie verwendet werden soll für die Anzeige.
Zur Auswahl stehen hier:
  * spielfilme
  * serien
  * sport
  * kinder
  * doku und info
  * unterhaltung

Das Plugin wird bei jedem Kodi Start ausgefüht und aktualisiert die Daten. Daraufhin geht es in eine Loop 
und aktualisiert sich alle 4h.





Skintegration:
==============

Um die TVHighlights des Tages in Confluence zu integrieren ist es erforderlich den Skin zu editieren. Die Anleitung hierzu liegt ist integration/README.txt.

