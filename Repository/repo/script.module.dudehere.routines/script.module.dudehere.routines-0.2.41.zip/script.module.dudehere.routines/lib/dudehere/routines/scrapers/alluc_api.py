import sys
import os
import re
import urllib
from dudehere.routines import *
from dudehere.routines.scrapers import CommonScraper, ScraperResult
class alluc_apiScraper(CommonScraper):
	def __init__(self):
		self._settings = {}
		self.service='alluc_api'
		self.name = 'alluc.com'
		self.referrer = 'https://www.alluc.com'
		self.base_url = 'https://www.alluc.com'
		self.username = ADDON.get_setting(self.service + '_username')
		self.password = ADDON.get_setting(self.service + '_password')
		self.language = ADDON.get_setting(self.service + '_language')
		self.max_results = 75
		self.require_auth = True
		self.timeout = 2
		self.domains = None
	
	def check_authentication(self, username, password):
		valid = False
		self.max_results = 1
		self.username = username
		self.password = password
		self.language = ''
		url = self.prepair_query('movie', 'big buck bunny', '')
		results = self.request(url, return_json=True)
		valid = results['status']=='success'
		return valid
	
	def search_tvshow(self, args):
		self.domains = args['domains']
		results = []
		uri = self.prepair_query('tvshow', args['showname'], args['season'], args['episode'])
		s=args['season']
		ss=str(args['season']).zfill(2)
		e=str(args['episode']).zfill(2)				
		patern = "(S%sE%s)|(%s%s)|(%s.%s)|(%s.%s)" % (ss,e,s,e,ss,e,s,e)
		re_test = re.compile(patern, re.IGNORECASE)
		data = self.request(uri, return_json=True)
		results = self.process_results(data, re_test)
		return results
	
	def search_movie(self, args):
		self.domains = args['domains']
		results = []
		uri = self.prepair_query('movie', args['title'], args['year'])
		data = self.request(uri, return_json=True)
		results = self.process_results(data)
		return results
	
	def quick_search(self, query):
		uri = self.prepair_query('quick', query)
		data = self.request(uri, return_json=True)
		results = self.process_results(data)
		return results
	
	def process_results(self, data, re_test=None):
		results = []
		for result in data['result']:
			title = self.normalize(result['title'])
			if re_test:
				if re_test.search(title) is None: continue
			sourcetitle = self.normalize(result['sourcetitle'])
			hoster = result['hosterurls']
			extension = result['extension']
			size = result['sizeinternal']
			extension = result['extension']
			host_name = result['hostername']
			hosts = result['hosterurls']
			for host in hosts:
				filter = False
				if self.domains is not None:
					filter = True
				if filter == False or (host_name in self.domains and filter == True):
					url = "%s://%s" % (self.service, host['url'])
					quality = self.test_quality(title+sourcetitle+self.normalize(url))
					result = ScraperResult(self.service, host_name, url, title)
					result.quality = quality
					result.size = int(size)
					result.extension = extension
					results.append(result)
		return results
		
	def prepair_query(self, media, *args, **kwards):
		self.max_results = int(ADDON.get_setting('max_results')) if ADDON.get_setting('max_results') != '' else 75
		uri = "/api/search/stream/?%s"
		params = {"from": 0, "count": self.max_results, "getmeta":0}
		params['user'] = self.username
		params['password'] = self.password
		if media == 'tvshow':
			params['query'] = "%s S%sE%s" % args
		elif media == 'quick':
			params['query'] = args[0]
		else:
			params['query'] = "%s %s" % args
		if self.language: params['query'] = params['query'] + ' lang:' + self.language
		return uri % urllib.urlencode(params)