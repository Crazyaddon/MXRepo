import sys
import os
import re
import urllib, urllib2
import json
import unicodedata
import xbmcgui
import urlresolver
import hashlib
from urlparse import urljoin
from dudehere.routines import *
from dudehere.routines.threadpool import ThreadPool
from addon.common.net import Net, HttpResponse
from BeautifulSoup import BeautifulSoup
from dudehere.routines.vfs import VFSClass
vfs = VFSClass()
DECAY = 2
SCRAPER_DIR = os.path.dirname(os.path.abspath(__file__))
COOKIE_PATH = vfs.join(DATA_PATH,'cookies')
if not vfs.exists(COOKIE_PATH): vfs.mkdir(COOKIE_PATH, recursive=True)
sys.path.append(SCRAPER_DIR)
from dudehere.routines.database import SQLiteDatabase as DatabaseAPI	
class MyDatabaseAPI(DatabaseAPI):
	def _initialize(self):
		tables = [
			'''
			CREATE TABLE IF NOT EXISTS "search_cache" (
			"cache_id" INTEGER PRIMARY KEY AUTOINCREMENT, 
			"hash" TEXT NOT NULL,
			"service" TEXT NOT NULL,
			"host" TEXT NOT NULL,
			"display" TEXT NOT NULL,
			"quality" INTEGER DEFAULT 3,
			"url" TEXT NOT NULL, 
			"ts" TIMESTAMP DEFAULT CURRENT_TIMESTAMP
			)
			''',
			'''
			CREATE TABLE IF NOT EXISTS "scraper_states" (
			"id"	INTEGER PRIMARY KEY AUTOINCREMENT,
			"name"	TEXT UNIQUE,
			"enabled"	INTEGER DEFAULT 1
			)
			''',
			'''
			CREATE TABLE IF NOT EXISTS "scraper_stats" (
			"id" INTEGER PRIMARY KEY AUTOINCREMENT,
			"service" TEXT,
			"host" TEXT,
			"attempts" INTEGER DEFAULT 0,
			"resolved" INTEGER DEFAULT 0,
			"success" INTEGER DEFAULT 0,
			UNIQUE ("service", "host") ON CONFLICT REPLACE
			)
			'''
		]
		for SQL in tables:
			self.execute(SQL)
		self.commit()
		ADDON.set_setting('database_sqlite_init.cache', 'true')
DB_TYPE = 'sqlite'
DB_FILE = vfs.join(DATA_PATH, "cache.db")

class NetLib(Net):
	timeout=1
	def get(self, url, headers=None, timeout=1):
		self.timeout = timeout
		html = self.http_GET(url, headers=headers)
		return html
	
	def post(self, url, params, headers=None, timeout=1):
		self.timeout = timeout
		html = self.http_POST(url, params, headers=headers)
		return html
		
	def _fetch(self, url, form_data={}, headers={}, compression=True):
		encoding = ''
		req = urllib2.Request(url)
		if form_data:
			form_data = urllib.urlencode(form_data)
			req = urllib2.Request(url, form_data)
		req.add_header('User-Agent', self._user_agent)
		for k, v in headers.items():
			req.add_header(k, v)
		if compression:
			req.add_header('Accept-Encoding', 'gzip')
		try:
			response = urllib2.urlopen(req, timeout=self.timeout)
		except urllib2.HTTPError as e:
			ADDON.log("HTTP Error: %s" % e.code)
			return ''
		return HttpResponse(response).content


class ScraperResult():
	bitrate_color = ADDON.get_setting('custom_color_bitrate') if ADDON.get_setting('custom_color_bitrate') != '' else 'purple'
	hostname_color = ADDON.get_setting('custom_color_hostname') if ADDON.get_setting('custom_color_hostname') != '' else 'red'
	size_color = ADDON.get_setting('custom_color_filesize') if ADDON.get_setting('custom_color_filesize') != '' else 'blue'
	extension_color = ADDON.get_setting('custom_color_extension') if ADDON.get_setting('custom_color_extension') != '' else 'green'
	quality_color = ADDON.get_setting('custom_color_quality') if ADDON.get_setting('custom_color_quality') != '' else 'yellow'
	service_color = ADDON.get_setting('custom_color_service') if ADDON.get_setting('custom_color_service') != '' else 'white'

	
	def __init__(self, service, hostname, url, text=None):
		self.hostname = hostname
		self.service = service
		self.text = text
		self.url = url
		self.bitrate = None
		self.size = None
		self.extension = None
		self.quality = None
		self.score = 0
	
	def colorize(self, attrib, value):
		color = getattr(self, attrib+'_color')
		if attrib == 'bitrate':
			return "[COLOR %s]%s kb/s[/COLOR]" % (color, value)
		elif attrib == 'quality':
			quality = QUALITY.r_map[value]
			return "[COLOR %s]%s[/COLOR]" % (color, quality)
		elif attrib == 'size':
			size = self.format_size(value)
			return "[COLOR %s]%s[/COLOR]" % (color, size)
		else:
			return "[COLOR %s]%s[/COLOR]" % (color, value)
	
	def format_size(self, size):
		size = int(size) / (1000 * 1000)
		if size > 2000:
			size = size / 1000
			unit = 'GB'
		else :
			unit = 'MB'
		size = "%s %s" % (size, unit)
		return size
		
	def ck(self, attrib):
		if getattr(self, attrib):
			self.attributes.append(self.colorize(attrib, getattr(self, attrib)))
		
	def format(self):
		self.attributes = []
		self.attributes.append(self.colorize('hostname', self.hostname))
		self.attributes.append(self.colorize('service', self.service))
		for foo in ['size', 'bitrate', 'extension', 'quality']:
			self.ck(foo)
		
		format = "[%s]: %s"	
		if self.text is None: self.text = self.hostname
		return format % (' | '.join(self.attributes), self.text.decode('ascii','ignore'))

class CommonScraper():
	USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_5) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.85 Safari/537.36'
	ACCEPT = 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8'
	accept = ACCEPT
	user_agent = USER_AGENT
	HOST_COLOR = 'red'
	SIZE_COLOR = 'blue'
	EXTENSION_COLOR = 'green'
	QUALITY_COLOR = 'yellow'
	BITRATE_COLOR = 'purple'
	timeout = 1
	broken = False
	require_auth = False
	is_cachable = True
	def __init__(self, load = None, disable = None, cache_results=False):
		self.threadpool_size = 5
		self.cache_results = cache_results
		self._load_list = load
		self._disable_list = disable
		self.enabled_scrapers = 0
		self.active_scrapers = []
		self.supported_scrapers = []
		self._active_scrapers = []
		self._load_scrapers()
		self._enable_scrapers()
		self.search_results = []

	def reinitialize_cache(self):
		vfs.rm(DB_FILE)
		DB=MyDatabaseAPI(DB_FILE, init_flag='database_sqlite_init.cache')
		DB._initialize()
	
	def normalize(self, string):
		return unicodedata.normalize('NFKD', unicode(string)).encode('utf-8','ignore')
	
	def get_setting(self, k):
		return self._settings[k]
	
	def set_setting(self, k, v):
		self._settings[k] = v
	
	def get_property(self, k):
		p = xbmcgui.Window(10000).getProperty('GenericPlaybackService.' + k)
		if p == 'false': return False
		if p == 'true': return True
		return p
	
	def set_property(self, k, v):
		xbmcgui.Window(10000).setProperty('GenericPlaybackService.' + k, v)
	
	def clear_property(self, k):
		xbmcgui.Window(10000).clearProperty('GenericPlaybackService.' + k)
	
	def read_scraper_states(self):
		DB=MyDatabaseAPI(DB_FILE, init_flag='database_sqlite_init.cache')
		return DB.query_assoc("SELECT name, enabled FROM scraper_states")
		DB.disconnect()
	
	def toggle_scraper_state(self, name):
		DB=MyDatabaseAPI(DB_FILE, init_flag='database_sqlite_init.cache')
		DB.execute("UPDATE scraper_states SET enabled = (enabled * -1 + 1) WHERE name=?",  [name])
		DB.commit()
		DB.disconnect()
		
	def set_scraper_state(self, name, state):
		DB=MyDatabaseAPI(DB_FILE, init_flag='database_sqlite_init.cache')
		state = 1 if state else 0
		DB.execute("UPDATE scraper_states SET enabled = ? WHERE name=?",  [state, name])
		DB.commit()
		DB.disconnect()
		
	def _load_scrapers(self):
		DB=MyDatabaseAPI(DB_FILE, init_flag='database_sqlite_init.cache')
		names = []
		count = 0
		for filename in sorted(os.listdir(SCRAPER_DIR)):
			if not re.search('(__)|(common\.py)|(example\.py)|(all\.py)', filename) and re.search('py$', filename):
				name = filename[0:len(filename)-3]
				self.supported_scrapers.append(name)
				names.append([name])
				if self._load_list is False: continue 	#should I even load anything?
				skip = False
				
				if self._load_list == 'all':
					pass 					#load all except explicitly disabled
				elif isinstance(self._load_list, list):
					skip = True				#load all in the supplied load list except explicitly disabled
					if name in self._load_list: skip = False
				else:
					skip = True				#load all enabled from db except explicitly disabled
					if DB.query("SELECT 1 FROM scraper_states WHERE enabled AND name=?", [name]): skip = False
						
				if self._disable_list is not None:
					if name in self._disable_list:
						skip = True			#now disable any scrapers in the disable list
				if skip is False:	
					classname = name+'Scraper'
					scraper = __import__(name, globals(), locals(), [classname], -1)
					klass = getattr(scraper, classname)
					scraper = klass()
					self.put_scraper(scraper.service, scraper)
				count +=1
		if count > DB.query("SELECT count(1) FROM scraper_states")[0]:
			for name in names: DB.execute("INSERT INTO scraper_states(name) VALUES (?)", name)
			DB.commit()
		DB.disconnect()
				
	def get_scraper_by_name(self, name):
		try:
			index = self.active_scrapers.index(name)
			return self.get_scraper_by_index(index)
		except:
			return None
		
	def get_scraper_by_index(self, index):
		try:
			return self._active_scrapers[index]
		except:
			return None
	
	def _enable_scrapers(self):
		for index in range(0, len(self.active_scrapers)):
			self.enabled_scrapers += 1
		
	def put_scraper(self, name, scraper):
		if not scraper.broken:
			self.active_scrapers.append(name)
			self._active_scrapers.append(scraper)
		
	def process_results(self, results):
		if self.cache_results:
			values = []
			for r in results: 
				values.append([self.hashid, r.service, r.hostname, r.format(), r.quality, r.url])
			DB=MyDatabaseAPI(DB_FILE)
			DB.execute_many("INSERT INTO search_cache(hash, service, host, display, quality, url) VALUES(?,?,?,?,?,?)", values)
			DB.commit()
			DB.disconnect()
		self.search_results += results
		
	def search_tvshow(self, showname, season, episode, year=None, imdb_id=None, tvdb_id=None):
		DB=MyDatabaseAPI(DB_FILE, init_flag='database_sqlite_init.cache')
		if self.cache_results:	
			self.hashid = hashlib.md5(showname+str(season)+str(episode)).hexdigest()
			DB.execute("DELETE FROM search_cache WHERE hash=? AND strftime('%s','now') -  strftime('%s',ts) > (3600 * ?)", [self.hashid, DECAY])
			DB.commit()
		self.result_stats = DB.query("SELECT service, host, attempts, success, CAST(CAST(success AS float) / CAST(attempts AS float) * 100 AS INTEGER) AS percent FROM scraper_stats", force_double_array=True)
		self._get_active_resolvers()
		args = {"showname": showname, "season": season, "episode": episode, "year": year, "domains": self.domains, "imdb_id": imdb_id, "tmdb_id": tvdb_id}
		workers = ThreadPool(self.threadpool_size)
		for index in range(0, self.enabled_scrapers):
			service = self.get_scraper_by_index(index).service
			if self.cache_results and  self.get_scraper_by_index(index).is_cachable:
				SQL = '''
					SELECT
					"%s" AS hashid,
					"%s" AS service,
					host,
					display as title,
					url,
					quality,
					0 AS score,''' % (self.hashid, service)
				SQL += '''strftime("%s",'now') -  strftime("%s",ts) < (3600 * ?) AS fresh
				FROM search_cache 
				WHERE
				hash=? AND service=?
				'''
				cached = DB.query_assoc(SQL, [DECAY, self.hashid, service])
			else:
				cached = False
			if cached:
				self.search_results += cached
			else:
				if 'search_tvshow' in dir(self.get_scraper_by_index(index)):
					add_task = True
					if self.get_scraper_by_index(index).require_auth and (ADDON.get_setting(self.get_scraper_by_index(index).service + '_username') == '' or ADDON.get_setting(self.get_scraper_by_index(index).service + '_password') == ''): add_task = False
					if add_task: workers.queueTask(self.get_scraper_by_index(index).search_tvshow, args=args, taskCallback=self.process_results)
		workers.joinAll()
		resolved_url = None
		DB.disconnect()
		raw_url =  self.select_stream()
		if raw_url:
			resolved_url = self.resolve_url(raw_url)
		return resolved_url	
	
	def search_movie(self, title, year, imdb_id=None, tmdb_id=None):
		DB=MyDatabaseAPI(DB_FILE, init_flag='database_sqlite_init.cache')
		if self.cache_results:
			self.hashid = hashlib.md5(title+str(year)).hexdigest()
			DB.execute("DELETE FROM search_cache WHERE hash=? AND strftime('%s','now') -  strftime('%s',ts) > (3600 * ?)", [self.hashid, DECAY])
			DB.commit()
		self.result_stats = DB.query("SELECT service, host, attempts, success, ROUND((success/attempts) * 100) AS score FROM scraper_stats", force_double_array=True)
		self._get_active_resolvers()
		args = {"title": title, "year": year, "domains": self.domains, "imdb_id": imdb_id, "tmdb_id": tmdb_id}
		workers = ThreadPool(self.threadpool_size)
		for index in range(0, self.enabled_scrapers):
			if self.cache_results:
				service = self.get_scraper_by_index(index).service
				SQL = '''
					SELECT
					"%s" AS hashid,
					"%s" AS service,
					host,
					display as title,
					url,
					quality,
					0 AS score,''' % (self.hashid, service)
				SQL += '''strftime("%s",'now') -  strftime("%s",ts) < (3600 * ?) AS fresh
				FROM search_cache 
				WHERE
				hash=? AND service=?
				'''
				cached = DB.query_assoc(SQL, [DECAY, self.hashid, service])
			else:
				cached = False	
			if cached:
				self.search_results += cached
			else:
				if 'search_movie' in dir(self.get_scraper_by_index(index)):
					add_task = True
					if self.get_scraper_by_index(index).require_auth and (ADDON.get_setting(self.get_scraper_by_index(index).service + '_username') == '' or ADDON.get_setting(self.get_scraper_by_index(index).service + '_password') == ''): add_task = False
					if add_task: workers.queueTask(self.get_scraper_by_index(index).search_movie, args=args, taskCallback=self.process_results)
		workers.joinAll()
		resolved_url = None
		DB.disconnect()
		raw_url =  self.select_stream()
		if raw_url:
			resolved_url = self.resolve_url(raw_url)
		return resolved_url	
	
	def _get_active_resolvers(self):		
		self.domains = []
		try:
			for resolver in urlresolver.UrlResolver.implementors():
				for self.domain in resolver.domains:
					if re.match('^(.+?)\.(.+?)$', domain): self.domains.append(domain)
		except:
			pass
		if len(self.domains) ==0:
			self.domains = ['promptfile.com', 'crunchyroll.com', 'xvidstage.com', 'yourupload.com', 'dailymotion.com', 'cloudy.ec', 'cloudy.eu', 'cloudy.sx', 'cloudy.ch', 'cloudy.com', 'thevideo.me', 'videobb.com', 'stagevu.com', 'mp4stream.com', 'youwatch.org', 'rapidvideo.com', 'play44.net', 'castamp.com', 'daclips.in', 'daclips.com', 'videozed.net', 'videomega.tv', 'movieshd.co', 'bayfiles.com', 'vidzi.tv', 'vidxden.com', 'vidxden.to', 'divxden.com', 'vidbux.com', 'vidbux.to', 'purevid.com', 'thefile.me', 'shared.sx', 'vimeo.com', 'vidplay.net', 'vidspot.net', 'movshare.net', 'speedvideo.net', 'uploadc.com', 'streamcloud.eu', 'sockshare.com', 'vk.com', 'videohut.to', 'letwatch.us', 'royalvids.eu', 'veoh.com', 'donevideo.com', 'mp4star.com', 'vidto.me', 'vivo.sx', 'videotanker.co', 'hugefiles.net', 'youtube.com', 'youtu.be', 'primeshare.tv', 'sharevid.org', 'sharerepo.com', 'video44.net', 'billionuploads.com', 'realvid.net', 'filenuke.com', 'bestreams.net', 'exashare.com', 'limevideo.net', 'videovalley.net', 'divxstage.eu', 'divxstage.net', 'divxstage.to', 'cloudtime.to', 'vidzur.com', 'gorillavid.in', 'gorillavid.com', 'trollvid.net', 'ecostream.tv', 'muchshare.net', 'streamin.to', 'video.tt', '180upload.com', 'auengine.com', 'novamov.com', 'vodlocker.com', 'watchfreeinhd.com', 'uploadcrazy.net', 'tubeplus.me', 'mp4upload.com', 'cyberlocker.ch', 'googlevideo.com', 'picasaweb.google.com', 'jumbofiles.com', 'vidstream.in', 'veehd.com', 'movdivx.com', 'mightyupload.com', 'vidup.org', 'tune.pk', 'facebook.com', 'mrfile.me', 'nowvideo.eu', 'nowvideo.ch', 'nowvideo.sx', 'flashx.tv', 'videoboxone.com', 'vidcrazy.net', 'movreel.com', 'hostingbulk.com', 'played.to', 'putlocker.com', 'filedrive.com', 'firedrive.com', 'mooshare.biz', 'zalaa.com', 'playwire.com', 'vidbull.com', 'sharesix.com', 'movpod.net', 'movpod.in', 'justmp4.com', 'cloudyvideos.com', 'mega-vids.com', 'nosvideo.com', 'movzap.com', 'zuzvideo.com', 'allmyvideos.net', 'videofun.me', 'videoweed.es', 'videoraj.ec', 'videoraj.eu', 'videoraj.sx', 'videoraj.ch', 'videoraj.com']
		
	def resolve_url(self, raw_url):
		test = re.search("^(.+?)(://)(.+?)$", raw_url)
		scraper = test.group(1)
		raw_url = test.group(3)
		if 'get_resolved_url' in dir(self.get_scraper_by_name(scraper)):
			resolved_url = self.get_scraper_by_name(scraper).get_resolved_url(raw_url)
			if resolved_url is not None:
				SQL = '''
					UPDATE scraper_stats SET resolved = resolved + 1 WHERE service=? AND host=?
				'''
				DB=MyDatabaseAPI(DB_FILE, init_flag='database_sqlite_init.cache')
				DB.execute(SQL, [self.__atempt_service, self.__atempt_hostname])
				DB.commit()
				DB.disconnect()
			return resolved_url
		else:
			source = urlresolver.HostedMediaFile(url=raw_url)
			resolved_url = source.resolve() if source else None
			if resolved_url is not None:
				SQL = '''
					UPDATE scraper_stats SET resolved = resolved + 1 WHERE service=? AND host=?
				'''
				DB=MyDatabaseAPI(DB_FILE, init_flag='database_sqlite_init.cache')
				DB.execute(SQL, [self.__atempt_service, self.__atempt_hostname])
				DB.commit()
				DB.disconnect()
			return resolved_url

	
	def select_stream(self, sort=True):
		streams = []
		options = []
		def get_score(hostname, service):
			for test in self.result_stats:
				if test[0] == service and test[1] == hostname:
					return test[4]
			return 0
				
		def sort_streams(record):
			try:
				record.score = get_score(record.hostname, record.service)
				return (record.quality, record.score, record.hostname)
			except:
				record['score'] = get_score(record['host'], record['service'])
				return (record['quality'], record['score'], record['host'])
		if sort:
			self.search_results.sort(reverse=True, key=lambda k: sort_streams(k))
		for result in self.search_results:
			try:
				display = result.format()
				url = result.url
				hostname = result.hostname
				service = result.service
				score = result.score

			except:
				display = result['title']
				url = result['url']
				hostname = result['host']
				service = result['service']
				score = result['score']

			finally:
				pass
			if sort:
				display = "[%s]%s" % (score, display)
			streams.append(display)
			options.append(url)
				
		dialog = xbmcgui.Dialog()
		select = dialog.select("Select a stream", streams)
		if select < 0:
			return False
		if sort:
			try:
				self.__atempt_hostname = self.search_results[select].hostname
				self.__atempt_service = self.search_results[select].service
			except:
				self.__atempt_hostname = self.search_results[select]['host']
				self.__atempt_service = self.search_results[select]['service']
		
			SQL = '''
				INSERT INTO scraper_stats (service, host, attempts, resolved, success) 
				SELECT ?, ?, 
				CASE(count(tmp.attempts)) WHEN 0 THEN 1 ELSE tmp.attempts + 1 END AS attempts, 
				CASE(count(tmp.resolved)) WHEN 0 THEN 0 ELSE tmp.resolved END AS resolved,
				CASE(count(tmp.success)) WHEN 0 THEN 0 ELSE tmp.success END AS success
				FROM scraper_stats as tmp WHERE tmp.service=? and tmp.host=?
			'''
			self.set_property('hostname', self.__atempt_hostname)
			self.set_property('service', self.__atempt_service)
			DB=MyDatabaseAPI(DB_FILE, init_flag='database_sqlite_init.cache')
			DB.execute(SQL, [self.__atempt_service, self.__atempt_hostname, self.__atempt_service, self.__atempt_hostname])
			DB.commit()
			DB.disconnect()
		return options[select]
	
	def update_success(self, hostname, service):
		SQL = '''
			UPDATE scraper_stats SET success = success + 1 WHERE service=? AND host=?
		'''
		DB=MyDatabaseAPI(DB_FILE, init_flag='database_sqlite_init.cache')
		DB.execute(SQL, [service, hostname])
		DB.commit()
		DB.disconnect()
		
	def test_quality(self, string):
		if re.search('1080p', string): return QUALITY.HD1080
		if re.search('720p', string): return QUALITY.HD720
		if re.search('480p', string): return QUALITY.SD480
		if re.search('(320p)|(240p)', string): return QUALITY.LOW
		return QUALITY.UNKNOWN
	
	def set_color(self, text, color):
		return "[COLOR %s]%s[/COLOR]" % (color, text)
	
	def format_size(self, size):
		size = int(size) / (1024 * 1024)
		if size > 2000:
			size = size / 1024
			unit = 'GB'
		else :
			unit = 'MB'
		size = "%s %s" % (size, unit)
		return size
	
	def request(self, uri, params=None, query=None, headers=None, timeout=None, return_soup=False, return_json=False):
		COOKIE_JAR = vfs.join(COOKIE_PATH,self.service + '.lwp')
		net = NetLib()
		net.set_cookies(COOKIE_JAR)
		if headers:
			if 'Referer' not in headers.keys(): 
				headers['Referer'] = self.referrer
			if 'Accept' not in headers.keys():	
				headers['Accept'] = self.accept
			if 'User-Agent' not in headers.keys():
				headers['User-Agent'] = self.user_agent
		else:
			headers = {
			'Referer': self.referrer,
			'Accept': self.accept,
			'User-Agent': self.user_agent
			}	
		if query:
			uri += "?" + urllib.urlencode(query)
		url = urljoin(self.base_url, uri)
		if timeout is None:
			timeout = self.timeout
		if params:
			html = net.post(url, params, headers=headers, timeout=timeout)
		else:
			html = net.get(url, headers=headers, timeout=timeout)
		net.save_cookies(COOKIE_JAR)
		if return_soup:
			return BeautifulSoup(html)
		elif return_json:
			return json.loads(html)
		else: 
			return html
				
	def get_redirect(self, uri):
		from dudehere.routines import httplib2
		h = httplib2.Http()
		h.follow_redirects = True
		(response, body) = h.request(self.base_url + uri)
		return response['content-location']
			