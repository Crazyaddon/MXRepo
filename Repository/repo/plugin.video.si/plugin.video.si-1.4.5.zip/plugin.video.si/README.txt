plugin.video.si
================


XBMC Addon for Sports Illustrated

version 1.4.5 cleanup of brightcove and website changes

version 1.1.0 initial release
version 1.1.1 minor changes to addon.xml description
version 1.2.1 added 720p support for most videos where available - defaults to SD, use addon config to set HD
version 1.3.1 added missing script.module.pyamf in addon.xml
version 1.4.0 fixed 720/540 rtmp streaming replacing http: .m3u8
version 1.4.1 fixed website changes
version 1.4.2 more website changes for items without data
version 1.4.3 more website changes
