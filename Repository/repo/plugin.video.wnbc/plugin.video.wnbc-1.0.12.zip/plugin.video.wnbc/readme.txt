Version 1.0.12 fix for tonight show
Version 1.0.11 website change
Version 1.0.10 website change
Version 1.0.9 website change
Version 1.0.8 added metadata and selectable views
Version 1.0.7 website change
Version 1.0.6 use proxy for classics
Version 1.0.5 reduce use of proxy
Version 1.0.4 Kodi.org release
Version 1.0.3 fixed "classic" episodes
Version 1.0.2 added subtitles
Version 1.0.1 Initial release
