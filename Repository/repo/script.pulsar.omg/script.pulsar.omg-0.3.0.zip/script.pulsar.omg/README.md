script.pulsar.omg
=================

OMGTorrent (French) Pulsar provider for XBMC

Note
_________________

Provide french content. 


History : 
_________________
Version 0.2.0 : 
- Update for Pulsar 0.2
- Use French title from TMDB

Version 0.0.1
- Initial version for Pulsar 0.1