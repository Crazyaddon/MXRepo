This plugin allows you to watch live TV channels or listen to radio stations
in Viet Nam or from overseas providers straight from the XBMC interface,
thus eliminating the needs for using browsers and flashplayer, etc.

DISCLAIMER: All live streams are pulled from online providers and in no way
represent my views or opinions. I also hold no control over the quality of
the streams nor that of your internet connection :)

DONATIONS: Given the personal time and effort put in to this little project,
I have decided to accept donations. If you enjoy using the plugin, you can
make donations via PayPal to b_at_zecoj_dot_com
