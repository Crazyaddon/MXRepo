# coding: utf-8
# Main Addon
__author__ = 'mancuniancol'

from xbmcswift2 import Plugin
from tools import *


##INITIALISATION
storage = Storage(settings.storageName, type="dict")
plugin = Plugin()


###############################
###  MENU    ##################
###############################
@plugin.route('/')
def index():
    textViewer(settings.string(32000), once=True)
    items = [
        {'label': "add List...",
         'path': plugin.url_for('search'),
         'thumbnail': dirImages("busqueda-manual.png"),
         'properties': {'fanart_image': settings.fanart}
         }]
    listTypes = [settings.string(32105),
                 settings.string(32106),
                 settings.string(32107),
                 settings.string(32108)]
    listUrl = ['http://trakt.tv/movies/popular',
               'http://trakt.tv/movies/trending',
               'http://trakt.tv/shows/popular',
               'http://trakt.tv/shows/trending'
               ]
    listIcons = [dirImages("estrenos.png"),
                 dirImages("peliculas.png"),
                 dirImages("peliculas-hdrip.png"),
                 dirImages("peliculas-microhd.png")
                 ]
    for type, url, icon in zip(listTypes, listUrl, listIcons):
        if type in storage.database.keys():
            importInfo = (settings.string(32001),
                          'XBMC.Container.Update(%s)' % plugin.url_for('unsubscribe', key=type))
        else:
            importInfo = (settings.string(32002),
                          'XBMC.Container.Update(%s)' % plugin.url_for('subscribe', key=type, url=url))
        items.append({'label': type,
                      'path': plugin.url_for('readItems', url=url),
                      'thumbnail': icon,
                      'properties': {'fanart_image': settings.fanart},
                      'context_menu': [importInfo, (plugin.get_string(32009),
                                                    'XBMC.RunPlugin(%s)' % plugin.url_for('importAll', key=type,
                                                                                          url=url))]
                      })
    return items


@plugin.route('/search/')
def search():
    query = settings.dialog.input("Cual película buscar?")
    url = "/busqueda/%s/pag:" % query
    return readItems(url)


@plugin.route('/play/<url>')
def play(url):
    # play media
    link = url.replace("tt", "")
    settings.debug("PlayMedia(%s)" % link)
    xbmc.executebuiltin("PlayMedia(%s)" % link)


@plugin.route('/importOne/<title>/<magnet>/<id>')
def importOne(title="", magnet="", id=""):
    info = formatTitle(title)
    if 'MOVIE' in info['type']:
        integration(titles=[title], magnets=[magnet], id=[id], typeList='MOVIE', folder=settings.movieFolder,
                    silence=True)
    if 'SHOW' in info['type']:
        integration(titles=[title], magnets=[magnet], id=[id], typeList='SHOW', folder=settings.showFolder,
                    silence=True)
    if 'ANIME' in info['type']:
        integration(titles=[title], magnets=[magnet], id=[id], typeList='ANIME', folder=settings.animeFolder,
                    silence=True)


@plugin.route('/unsubscribe/<key>')
def unsubscribe(key=""):
    storage.remove(key)
    storage.save()


@plugin.route('/subscribe/<key>/<url>')
def subscribe(key="", url=""):
    storage.add(key, url)
    storage.save()
    importAll(key, url)


@plugin.route('/importAll/<key>/<url>')
def importAll(key="", url=""):
    items = readItems(url)
    titles = []
    magnets = []
    id = []
    for item in items:
        if item.has_key('info'):
            titles.append(item['info']['title'])
            id.append(item['info']['imdb_id'])
            magnets.append(getMagnet(item['path']))
    settings.debug("***************************************")
    settings.debug(titles)
    settings.debug(magnets)
    settings.debug(id)
    settings.debug("***************************************")
    if key in ['Estrenos', 'Peliculas', 'Peliculas HDRip']:
        integration(titles=titles, magnets=magnets, id=id, typeList='MOVIE',
                    folder=settings.movieFolder, silence=True)
    if key in ['Series', 'Series VOSE']:
        integration(titles=titles, magnets=magnets, typeList='SHOW',
                    folder=settings.showFolder, silence=True)
        # if len(titlesAnime) > 0:
        #     integration(titles=titlesAnime, magnets=magnetsAnime, typeList='ANIME',
        #                 folder=settings.animeFolder, silence=True)


@plugin.route('/readItems/<url>', name="readItems")
@plugin.route('/nextPage/<url>/<page>', name="nextPage")
def readItems(url="", page="1"):
    # read from URL
    settings.log(url)
    response = browser.get(url)
    soup = bs4.BeautifulSoup(response.text)
    links = soup.select("div.row.fanarts div.grid-item > a")

    # Items Menu Creation
    if __name__ == '__main__':
        plugin.set_content("movies")
    items = []
    for a in links:
        title = a.get("title", "")
        settings.debug(title)
        infoTitle = formatTitle(a["href"])
        settings.debug(infoTitle)
        infoLabels = getInfoLabels(infoTitle)  # collect the TheMovieDB and TheTVDB info from the title
        printer(infoLabels)
        settings.debug(infoLabels)
        urlSource = 'plugin://plugin.video.pulsar/movie/%s/%s' % (infoLabels.get("imdb_id", ""),
                                                                  settings.value["action"])
        if settings.value["infoLabels"] == "true" and len(infoLabels) > 0:  # there is information from TheMovieDB
            title = (normalize(infoLabels.get("title", ""), onlyDecode=True) if type == "Movie" else infoTitle[
                "title"]) + infoTitle.get("textQuality", "") + " " + infoTitle["language"]
            items.append({'label': title,
                          'path': plugin.url_for('play', url=urlSource),
                          'thumbnail': infoLabels.get("cover_url", ""),
                          'properties': {'fanart_image': infoLabels.get("backdrop_url", "")},
                          'info': infoLabels,
                          'stream_info': {'width': infoTitle["width"],
                                          'height': infoTitle["height"]
                                          },
                          'is_playable': True,
                          'context_menu': [
                              (plugin.get_string(32009),
                               'XBMC.RunPlugin(%s)' % plugin.url_for('importOne', title=title, magnet=urlSource,
                                                                     id=infoLabels["imdb_id"]))
                          ]
                          })
        else:  # Not information found
            title = infoTitle["title"] + ' - ' + infoTitle.get("quality", "")
            try:
                items.append({'label': title,
                              'path': plugin.url_for('play', url=urlSource),
                              'thumbnail': settings.icon,
                              'properties': {'fanart_image': settings.fanart},
                              'context_menu': [
                                  (plugin.get_string(32009),
                                   'XBMC.RunPlugin(%s)' % plugin.url_for('importOne', title=title, url=urlSource,
                                                                         id=infoLabels["imdb_id"]))
                              ]
                              })
            except:
                pass
    # next page
    items.append({'label': "Página Siguiente..",
                  'path': plugin.url_for('nextPage', url=url, page=int(page) + 1),
                  'thumbnail': settings.icon,
                  'properties': {'fanart_image': settings.fanart}
                  })
    return items


if __name__ == '__main__':
    plugin.run()
