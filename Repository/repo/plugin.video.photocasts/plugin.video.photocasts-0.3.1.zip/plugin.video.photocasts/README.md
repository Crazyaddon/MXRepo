Photography podcasts
====================
version 0.1


### Summary

Watch photography podcasts from the internet.


### Podcasts

* Camera Position, http://www.cameraposition.com/
* The Candid Frame, http://www.thecandidframe.com/
* Digital Photo Experience, http://dpexperience.com/
* Martin Bailey Photography,http://www.martinbaileyphotography.com/podcasts.php
* Meet the Gimp, http://blog.meetthegimp.org/
* Photo Walkthrough, http://www.photowalkthrough.com/
* Thoughts on Photography, http://www.thoughtsonphotography.com/
* Tips From The Top Floor, http://www.tipsfromthetopfloor.com/


### Contact

Petr Kovar <pejuko@gmail.com>
