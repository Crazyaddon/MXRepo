#!/usr/bin/python
# -*- coding: latin-1 -*-

import xbmc,xbmcaddon, xbmcplugin
import xbmcgui
import sys
import urllib, urllib2
import time
import re

from os import path, system
import socket
from urllib2 import Request, URLError, urlopen

thisPlugin = int(sys.argv[1])
addonId = "plugin.video.cinemay"
adn = xbmcaddon.Addon('plugin.video.cinemay')
Host = "http://www.cinemay.com/"
pass#print "Host =", Host
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
if not path.exists(dataPath):
       cmd = "mkdir -p " + dataPath
       system(cmd)

def getUrl(url):
        pass#print "Here in getUrl url =", url
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link
	
def getUrl2(url, referer):
        pass#print "Here in getUrl url =", url
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        req.add_header('Referer', referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link	
	
	
def showContent():
        names = []
        urls = []
        modes = []
        names.append("Serie")
        names.append("Films")
        urls.append("http://www.cinemay.com/serie/")
        urls.append("http://www.cinemay.com/films/")
        modes.append("12")
        modes.append("11")
        i1 = 0           
        while i1 < 2:
                for name in names:
                        pic = " "
                        url = urls[i1]
                        mode = modes[i1]
                        i1 = i1+1
                        ##pass#print "Here in Showcontent url1 =", url1
                        addDirectoryItem(name, {"name":name, "url":url, "mode":mode}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)
                
def showContent2(name1, urlmain):
	content = getUrl(urlmain)
	pass#print "In showContent2 content B =", content
	regexvideo = '</li><li><a href="(.*?)".*?>(.*?)<'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "In getVideos2 match =", match
        for url, name in match:
                 pic = " "
                 name = name1 + "-" + name
                 pass#print "Here in getVideos21 url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":1}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)                

def showContent3(name1, urlmain):
	content = getUrl(urlmain)
	pass#print "In showContent3 content B =", content
	regexvideo = 'li class="cat-item.*?a href="(.*?)" >(.*?)<'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "In getVideos2 match =", match
        for url, name in match:
                 pic = " "
                 name = name1 + "-" + name
                 pass#print "Here in getVideos21 url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":1}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)  
#http://www.cinemay.com/films/page/3/               
def getPage(name, url):
                pages = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]
                for page in pages:
                        url1 = url + "page/" + str(page) + "/"
                        name1 = name + " - Page " + str(page)
                        pic = " "
                        addDirectoryItem(name1, {"name":name1, "url":url1, "mode":2}, pic)       
                xbmcplugin.endOfDirectory(thisPlugin)

def getVideos(name, url):
                f = open("/tmp/xbmc_search.txt", "r")
                icount = 0
                for line in f.readlines(): 
                    sline = line
                    icount = icount+1
                    if icount > 0:
                           break

                name = sline.replace(" ", "+")
                url1 = Hostmain + "/index.php?search_keywords=" + name
                pages = [1, 2, 3]
                for page in pages:
                        url = url1 + "&page=" + str(page)
                        pass#print "Here in getVideos2 url =", url
                        name = "Page " + str(page)
                        pic = " "
                        addDirectoryItem(name, {"name":name, "url":url, "mode":31}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)

        
def getVideos2(name, urlmain):
	content = getUrl(urlmain)
	pass#print "content B =", content
	if "Serie" in name: mode = 5
	else: mode = 3

        content = getUrl(urlmain)
	pass#print "content B2 =", content
	regexvideo = 'div class="post" id=".*?<a href="(.*?)".*?title="(.*?)".*?img class="imgpic" src="(.*?)"'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "In getVideos2 match =", match
        for url, name, pic in match:
                 pass#print "Here in getVideos21 url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":mode}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)

#http://www.cinemay.com/voir/55410/                
def getVideos3(name1, urlmain):
	content = getUrl(urlmain)
	pass#print "In getVideos3 content B =", content

        regexvideo = '<tr><td><a href="(.*?)">(.*?)<'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "In getVideos match =", match
        for url, name in match:
                  if ("exashare" not in name.lower()) and ("youwatch" not in name.lower()): continue
                  pic = " "
                  url = "http://www.cinemay.com" + url
	          addDirectoryItem(name, {"name":name, "url":url, "mode":4}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)   

      
def getVideos4(name, urlmain):
#    if "exashare" in urlmain:
	content = getUrl(urlmain)
	pass#print "In getVideos4 content C =", content
        regexvideo = 'iframe src="(.*?)"'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "In getVideos match =", match
        url = match[0]
        if "exashare" in url:
               pass#print "In getVideos4 exashare url =", url
               content2 = getUrl(url)
               pass#print "In getVideos4 content2 =", content2
               pass#print "In getVideos4 youwatch content2 =", content2
               regexvideo = 'src="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content2)
	       url = match[0]
	       content3 = getUrl2(url, url)
               pass#print "In getVideos4 youwatch content3 =", content3
               regexvideo = 'file: "(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content3)
	       vidurl = match[0]
               playfile = xbmc.Player()
               playfile.play(vidurl)    
#http://fs31.youwatch.org:8777/uxvp3mk7oooax3ptx2nyfxv6wtlzpkwo6xlaiqje254dtnihxe6r6gv6ka/video.mp4?start=0
        elif "youwatch" in url:  
               pass#print "In getVideos4 youwatch url =", url
               content2 = getUrl(url)
               pass#print "In getVideos4 youwatch content2 =", content2
               regexvideo = 'src="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content2)
	       url = match[0]
	       content3 = getUrl2(url, url)
               pass#print "In getVideos4 youwatch content3 =", content3
	       regexvideo = 'provider(.*?)setup'
	       match = re.compile(regexvideo,re.DOTALL).findall(content3)
	       items = match[0].split("|")
	       pass#print "items =", items
	       vidurl = "http://" + items[5] + ".youwatch.org:" + items[4] + "/" + items[3] + "/video.mp4?start=0"
               pass#print "vidurl =", vidurl 
               playfile = xbmc.Player()
               playfile.play(vidurl)
	       
        
                     
def getVideos5(name1, urlmain):
	content = getUrl(urlmain)
	pass#print "In getVideos5 content B =", content
	
	regexvideo = 'class="bordred".*?a href="(.*?)" class="link_series_epi">(.*?)<'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "In getVideos5 match =", match
        for url, name in match:
                 pic = " "
                 pass#print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":4}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)        
                     

std_headers = {
	'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
	'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'en-us,en;q=0.5',
}  

def addDirectoryItem(name, parameters={},pic=""):
    li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
    url = sys.argv[0] + '?' + urllib.urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)


def parameters_string_to_dict(parameters):
    ''' Convert parameters encoded in a URL to a dict. '''
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict

params = parameters_string_to_dict(sys.argv[2])
name =  str(params.get("name", ""))
url =  str(params.get("url", ""))
url = urllib.unquote(url)
mode =  str(params.get("mode", ""))

if not sys.argv[2]:
	ok = showContent()
else:
        if mode == str(11):
	        ok = showContent2(name, url)	
        if mode == str(12):
	        ok = showContent3(name, url)	

        elif mode == str(1):
	        ok = getPage(name, url)	
        elif mode == str(2):
		ok = getVideos2(name, url)
	elif mode == str(3):
		ok = getVideos3(name, url)
	elif mode == str(4):
		ok = getVideos4(name, url)	        	
                	        	
        elif mode == str(5):
		ok = getVideos5(name, url)





























