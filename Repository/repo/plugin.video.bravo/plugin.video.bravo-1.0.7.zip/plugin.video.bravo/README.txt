plugin.video.bravo
================

Kodi Addon for Bravo TV website

Version 1.0.7 website change
Version 1.0.6 Website change
Version 1.0.5 Website change
Version 1.0.4 Website change
Version 1.0.3 Added user select views
Version 1.0.2 Added subtitles, metadata, content views
Version 1.0.1 initial release

