plugin.video.travel
================

XBMC Addon for Travel Network Video website

Version 1.0.4 website change
Version 1.0.3 Added subtitles, metadata, views
Version 1.0.2 website change
Version 1.0.1 initial release

