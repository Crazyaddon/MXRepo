![](https://raw.githubusercontent.com/bromix/repository.bromix.storage/master/plugin.video.dzango.tv/icon.png)
# **Links:**

* [DZANGO](http://www.dzango.de)

[![](https://www.paypalobjects.com/en_GB/i/btn/btn_donate_LG.gif)](https://goo.gl/U5oVOj) [![](https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif)](https://goo.gl/15V9TN) [![](https://www.paypalobjects.com/de_DE/i/btn/btn_donate_LG.gif)](https://goo.gl/oEjE9E) [![](https://pledgie.com/campaigns/29261.png?skin_name=chrome)](https://goo.gl/K4RZrZ) 

# **Changelog:**

## **2.2.1**

* name update
* changed server for content

## **2.2.0**

* dependency for YouTube 5.0.0
* support for DZANGO.TV

## **2.1.0**

* improved support for Gotham, Helix and Isengard


