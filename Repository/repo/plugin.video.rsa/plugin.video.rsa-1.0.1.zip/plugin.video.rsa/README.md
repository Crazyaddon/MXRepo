RSA Video Addon for XBMC
=======================

[![Build Status](https://travis-ci.org/lextoumbourou/plugin.video.rsa.png?branch=master)](https://travis-ci.org/lextoumbourou/plugin.video.rsa)

Watch videos from RSA (Royal Society for the encouragement of Arts, Manufactures and Commerce) on XBMC

## Setup/Installation

Install through System > Add-ons > Install from zip file > then open the zip file you downloaded 

## XBMC Version

Frodo

## Tests

```
> python -m unittest discover
```

## License

MIT
