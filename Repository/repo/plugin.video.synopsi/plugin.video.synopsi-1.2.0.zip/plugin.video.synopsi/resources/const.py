
# connection
BASE_URL="https://api.synopsi.tv/"
REL_API_URL="1.1/"
KEY="59c53964b1013defcff0155f6e4d54a4"
SECRET="487615d20b22cdce510fd3476ed84d924e2b0c45ce7c49dc621764e05fae0904"

# addon
# incrementing this will cause restarting plugin after update
SERVICE_IFACE_VERSION=2
