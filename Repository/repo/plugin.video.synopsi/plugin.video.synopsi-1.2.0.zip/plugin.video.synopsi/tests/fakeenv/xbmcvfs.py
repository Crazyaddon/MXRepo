import os

mkdir = os.mkdir

exists = os.path.exists

File = open
