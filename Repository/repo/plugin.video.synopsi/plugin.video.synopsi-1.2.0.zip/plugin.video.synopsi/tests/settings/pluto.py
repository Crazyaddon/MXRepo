from base import connection

connection['base_url'] = 'http://pluto.local:8000/'
