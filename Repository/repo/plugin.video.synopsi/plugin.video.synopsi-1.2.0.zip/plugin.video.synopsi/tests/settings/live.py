from base import connection

connection['base_url'] = 'https://api.synopsi.tv/'