from base import connection

connection['base_url'] = 'http://crux.local:8000/'
