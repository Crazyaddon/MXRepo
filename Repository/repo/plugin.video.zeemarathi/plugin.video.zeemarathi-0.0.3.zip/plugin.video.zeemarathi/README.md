# plugin.video.zeemarathi
Kodi video addon for http://www.zeemarathi.com
