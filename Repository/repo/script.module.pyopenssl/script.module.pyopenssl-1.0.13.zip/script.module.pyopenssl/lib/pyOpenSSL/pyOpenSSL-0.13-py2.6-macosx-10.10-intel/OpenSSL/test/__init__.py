# Copyright (C) Jean-Paul Calderone
# See LICENSE for details.

"""
Package containing unit tests for L{OpenSSL}.
"""
