xbmc-plugin-sportschau
===============================

[Kodi](http://kodi.tv/) plugin for watching videos and livestreams from [sportschau.de](http://www.sportschau.de/).

License
=======

The code is under GPLv3. See [LICENSE](https://github.com/fisch42/xbmc-plugin-sportschau/blob/master/LICENSE.txt) for more details.

I used the following extra software:
  * [Beautiful Soup](http://www.crummy.com/software/BeautifulSoup/) 4 Addon by Leonard Richardson
  * xbmcswift2 by Jonathan Beluch under GPLv3, see [xbmcswift2](https://github.com/jbeluch/xbmcswift2)

The [running pictogram](https://openclipart.org/detail/77317/running-pictogram) by [shokunin](https://openclipart.org/user-detail/shokunin) is under public domain.
