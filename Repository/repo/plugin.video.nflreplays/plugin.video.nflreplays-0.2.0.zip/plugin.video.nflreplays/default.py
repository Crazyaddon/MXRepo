from __future__ import unicode_literals
import urllib2
import sys
import urllib
import urlparse
import xbmcgui
import xbmcplugin
import xbmcaddon, xbmcvfs
import urlresolver
import os
from resources.modules.nfl import *
from addon.common.addon import Addon


addon = Addon('plugin.video.nflreplays', sys.argv)

base_url = sys.argv[0]
addon_handle = int(sys.argv[1])
args = urlparse.parse_qs(sys.argv[2][1:])

settings = xbmcaddon.Addon( id = 'plugin.video.nflreplays' )
addonfolder=settings.getAddonInfo( 'path' )
artfolder=addonfolder + '/resources/media/'

games_thumb = artfolder + 'Games.jpg'
teams_thumb = artfolder + 'Teams.jpg'
next_thumb = artfolder + 'Next.jpg' 
thumb= addonfolder + '/icon.png'
fanartt = addonfolder + '/fanart.jpg'

xbmcplugin.setContent(addon_handle, 'movies')

def Notify(typeq, box_title, message, times='', line2='', line3=''):
     if box_title == '':
          box_title='NFL Replays'
     if typeq == 'small':
          if times == '':
               times='5000'
          smallicon= thumb
          addon.show_small_popup(title=box_title, msg=message, delay=int(times), image=smallicon)
     elif typeq == 'big':
          addon.show_ok_dialog(message, title=box_title)
     else:
          addon.show_ok_dialog(message, title=box_title)
def build_url(query):
    return base_url + '?' + urllib.urlencode(query)

mode = args.get('mode', None)




if mode is None:
    url = build_url({'mode': 'games', 'url': 'http://nflhd.com'})
    li = xbmcgui.ListItem('Games', iconImage=games_thumb)
    li.setArt({ 'fanart':'%s'%fanartt})

    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)

    url = build_url({'mode': 'teams', 'foldername': 'Teams'})
    li = xbmcgui.ListItem('Teams', iconImage=teams_thumb)
    li.setArt({ 'fanart':'%s'%fanartt})
    xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)

   
    xbmcplugin.endOfDirectory(addon_handle)




elif mode[0]=='games':
    page=args['url'][0]
    games,next=get_games(page)
    for game in games:
        url,img,title=game[1],game[2],game[0]

        url = build_url({'mode': 'open_game', 'url': url, 'img':img})
        li = xbmcgui.ListItem(title, iconImage=img)
        li.setArt({ 'fanart':'%s'%fanartt})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)

    if next!='0':
        url = build_url({'mode': 'games', 'url': next})
        li = xbmcgui.ListItem('Next Page >>', iconImage=next_thumb)
        li.setArt({ 'fanart':'%s'%fanartt})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0]=='teams':
    teams=get_teams()
    for team in teams:
        url,img,title=team[1],team[2],team[0]


        url = build_url({'mode': 'games', 'url': url})
        li = xbmcgui.ListItem(title, iconImage=img)
        li.setArt({ 'fanart':'%s'%fanartt})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)

   
    xbmcplugin.endOfDirectory(addon_handle)

elif mode[0]=='open_game':
    url=args['url'][0]
    imgg=args['img'][0]
    link=url
    options=get_game_options(url)
    cnt,cntt=0,0
    for opt in options:
        cnt+=1
        cntt+=1
        title,img,urls=opt[0],opt[1],opt[2]
        if title=='Youtube' or title=='Hd' or title=='Mail':
            cntt-=1
        if title!='Youtube' and title!='Hd' and title!='Mail':
            url = build_url({'mode': 'open_option', 'option': cnt-1,'url':link, 'img':imgg})
            li = xbmcgui.ListItem('%s. '%cntt+title, iconImage=imgg)
            xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                    listitem=li,isFolder=True)

   
    xbmcplugin.endOfDirectory(addon_handle)
elif mode[0]=='open_option':
    ind=args['option'][0]
    url=args['url'][0]
    option=int(args['option'][0])
    urls=get_urls(url,option)
    link=url
    img=args['img'][0]
    title=get_title(link)
    for i in range(len(urls)):
        url = build_url({'mode': 'play','url': urls[i].encode('utf-8'),'help':link, 'img':img})

        li = xbmcgui.ListItem('Part %s - %s'%(i+1,title), iconImage=img)
        li.setArt({ 'fanart':'%s'%fanartt})
        xbmcplugin.addDirectoryItem(handle=addon_handle, url=url,
                                listitem=li,isFolder=True)
    xbmcplugin.endOfDirectory(addon_handle)




elif mode[0]=='play':
    url=str(args['url'][0])
    link=args['help'][0]
    img=args['img'][0]
    title=get_title(link)
    if 'nflhd' in url:
            url=get_link_hd(url)
    url = url.replace('temporarylink.net','moevideo.net')
    try:
        import urlresolver
        media_url=urlresolver.resolve(url)
        li = xbmcgui.ListItem('%s'%title)
        li.setInfo('video', { 'title': '%s'%title} )
        li.setThumbnailImage(img)
        xbmc.Player().play(item=media_url, listitem=li)
    except:
        try:
            import YDStreamExtractor
            YDStreamExtractor.disableDASHVideo(True) 
            vid = YDStreamExtractor.getVideoInfo(url,quality=1) 
            resolved = vid.streamURL() 
            li = xbmcgui.ListItem('%s'%title)
            li.setInfo('video', { 'title': '%s'%title} )
            li.setThumbnailImage(img)
            xbmc.Player().play(item=resolved, listitem=li)
        except:
            Notify('small', 'No stream','No stream available','')
