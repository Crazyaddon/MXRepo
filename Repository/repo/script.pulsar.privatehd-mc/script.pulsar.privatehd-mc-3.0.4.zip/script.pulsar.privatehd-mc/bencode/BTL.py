class BTFailure(Exception):
    pass
