import urllib,urllib2,re,xbmcplugin,xbmcgui,urlresolver,xbmc,xbmcaddon,os
from addon.common.addon import Addon
from addon.common.net import Net
import silent


#www.watchonlineseries.eu - by The_Silencer 2013 v0.8


addon_id = 'plugin.video.watchonlineseries'
local = xbmcaddon.Addon(id=addon_id)
watchonlinepath = local.getAddonInfo('path')
addon = Addon(addon_id, sys.argv)
datapath = addon.get_profile()
art = watchonlinepath+'/art'
net = Net()


#Return Favorites List *temp need to fix in silent*
def GETMYFAVS():
        MYFAVS = silent.getFavorites()
        print MYFAVS
        try:
                for name,url,types in MYFAVS:
                        addFAVDir(name,url,types)
        except:
                pass
                
#Main menu
def CATEGORIES():
        addDir('Featured TV Series','http://www.watchonlineseries.eu/',1,os.path.join(art,'Menu_Icon_Featured.png'),None)
        addDir('New Episodes','http://www.watchonlineseries.eu/new-shows',2,os.path.join(art,'Menu_Icon_NewEpisodes.png'),None)
        addDir('Top Watched Series','http://www.watchonlineseries.eu/',3,os.path.join(art,'Menu_Icon_TopWatched.png'),None)
        addDir('A-Z','http://www.watchonlineseries.eu/',4,os.path.join(art,'Menu_Icon_A-Z.png'),None)
        addDir('Search','http://www.watchonlineseries.eu/index.php',5,os.path.join(art,'Menu_Icon_Search.png'),None)
        addDir('My Favorites','http://www.watchonlineseries.eu/',6,os.path.join(art,'Menu_Icon_Favorites.png'),None)

#Featured TV Series list
def FEATURED(url):
        EnableMeta = local.getSetting('Enable-Meta')
        match=re.compile('<h2>\n<a href="(.+?)" title="(.+?)">.+?</a>\n</h2>').findall(net.http_GET(url).content)
        for url,name in match:
                        if EnableMeta == 'true':
                                addDir(name,url,7,'','tvshow')
                        if EnableMeta == 'false':
                                addDir(name,url,7,'',None)

#New Epidoes list
def NEW(url):
        EnableMeta = local.getSetting('Enable-Meta')
        match=re.compile('<h2>\n<a href="(.+?)" title=".+?">(.+?) - (.+?), (.+?) - (.+?)</a>\n</h2>').findall(net.http_GET(url).content)
        for url,title,season,episode,eptitle in match:
                title = silent.CLEAN(title)
                eptitle = silent.CLEAN(eptitle)
                if EnableMeta == 'true':
                        addDir('%s - %s - %s - %s' %(title,season,episode,eptitle),url+'@'+title+'@'+season+'@'+episode,9,'','new')
                if EnableMeta == 'false':
                        addDir('%s - %s - %s - %s' %(title,season,episode,eptitle),url,9,'',None)

#Top Watched Series list
def TOP(url):
        EnableMeta = local.getSetting('Enable-Meta')
        match=re.compile('\n.+?. <a title=".+?" href="(.+?)">(.+?)</a>').findall(net.http_GET(url).content)
        for url,name in match:
                        if EnableMeta == 'true':
                                addDir(name,'http://www.watchonlineseries.eu'+url,7,'','tvshow')
                        if EnableMeta == 'false':
                                addDir(name,'http://www.watchonlineseries.eu'+url,7,'',None)
                        
#A-Z list
def AZ(url):
        match=re.compile('<li class="menu-item"><a href="(.+?)">(.+?)</a></li>').findall(net.http_GET(url).content)
        for url,name in match:
                ok = ['0to9', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'V', 'W', 'XtoZ']
                icon = os.path.join(art,name+'.png')
                if name in ok:
                        addDir(name,url+'/abc',11,icon,None)

#Routine to search for Movies
def SEARCH(url):
        EnableMeta = local.getSetting('Enable-Meta')
        keyb = xbmc.Keyboard('', 'Search TV Shows from www.watchonlineseries.eu')
        keyb.doModal()
        if (keyb.isConfirmed()):
                search = keyb.getText()
                encode=urllib.quote(search)
                encode = encode.replace('%20', '+')
                print encode
                data = net.http_POST(url,{'menu' : 'search', 'query' : encode}).content
                match=re.compile('</div>.+?<h2>.+?<a href="http://www.watchonlineseries.eu/show/(.+?)/season/(.+?)/episode/(.+?)" title=".+?">(.+?)</a>.+?</h2>',re.DOTALL).findall(data)  
                for title,season,episode,name in match:
                        #title = #the-walking-dead
                        #season = #season/4
                        #episode = #episode/5
                        url = 'http://www.watchonlineseries.eu/show/'+title+'/season/'+season+'/episode/'+episode
                        title = title.replace('-',' ')
                        season = 'Season '+season
                        episode = 'Episode '+episode
                        episode = episode.replace('" rel="bookmark','')
                        print title
                        print season
                        print episode
                        print url
                        nono = '<img src='
                        if nono not in name:
                                if EnableMeta == 'true':
                                       addDir(name,url+'@'+title+'@'+season+'@'+episode,9,'','new')
                                if EnableMeta == 'false':
                                       addDir(name,url,9,'',None)

#List TV Series
def INDEX(url):
        EnableMeta = local.getSetting('Enable-Meta')
        match=re.compile('<h2>\n<a href="(.+?)" title=".+?">(.+?)</a>\n</h2>').findall(net.http_GET(url).content)
        nextpage=re.search('<li><a href="(.+?)">&raquo;</a></li>',(net.http_GET(url).content))
        for url,name in match:
                        if EnableMeta == 'true':
                                addDir(name,url,7,'','tvshow')
                        if EnableMeta == 'false':
                                addDir(name,url,7,'',None)
        if nextpage:
                url = nextpage.group(1)
                if EnableMeta == 'true':
                        addDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]',url+'/abc',11,'','tvshow')
                if EnableMeta == 'false':
                        addDir('[B][COLOR yellow]Next Page >>>[/COLOR][/B]',url+'/abc',11,'',None)

#List the seasons
def SEASONS(name,url):
        match=re.compile('<a class="page-numbers current" href="(.+?)">(.+?)</a>').findall(net.http_GET(url).content)
        for url,season in match:
                addDir(season,url+'@'+name,8,'','season')

#List the episodes
def EPISODES(name,url):
        title = url.split('@')[1]
        url = url.split('@')[0]
        season = name
        #season = season+'.'
        match=re.compile('<h2>\n<a href="(.+?)" title=".+?">(.+?)</a>\n</h2>').findall(net.http_GET(url).content)
        for url,episode in match:
                episode = episode.replace(season,'')
                episode = episode.replace('.','')
                if 'Episode' in episode:
                        addDir(episode,url+'@'+title+'@'+season,9,'','episode')
                
#List the Hoster links
def VIDEOLINKS(url):
        url = url.split('@')[0]
        match=re.compile('<span class="embed-type">\nLink\n \n-\n<strong>(.+?)</strong>.+?<span class="embed-out-link">\n<a href="(.+?)"',re.DOTALL).findall(net.http_GET(url).content)
        for name,url in match:
                specialhost = ['iShared','bestreams.net']#'allmyvideos.net'
                if name not in specialhost:
                        addDir(name,url,10,'',None)
                else:
                        addDir(name,url,12,'',None)

#Resolve host not in metahandlers (iShared, ALLmyvideos, bestreams )
def SPECIALHOST(url,name):
        #Get iShared final link
        if 'iShared' in name:
                match=re.compile('path:"(.+?)"').findall(net.http_GET(url).content)
                for url in match:
                        addLink(name,url,'')

        #Get Allmyvideos final link
        if 'allmyvideos.net' in name:
                url = url+'.html'
                url = url.replace('http://allmyvideos.net/','http://allmyvideos.net/embed-')
                print url
                match=re.compile('\n               "file" : "(.+?)",.+?"label" : "(.+?)"',re.DOTALL).findall(net.http_GET(url).content)
                for url,quality in match:
                        addLink('%s : %s'%(name,quality),url,'')
                        
        #Get bestreams final link
        if 'bestreams' in name:
                url = url+'.html'
                url = url.replace('http://bestreams.net/','http://bestreams.net/embed-')
                print url
                match=re.compile('file: "(.+?)"').findall(net.http_GET(url).content)
                for url in match:
                        addLink(name,url,'')


#Pass url to urlresolver
def STREAM(url):
        req = urllib2.Request(url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        try:
                streamlink = urlresolver.resolve(urllib2.urlopen(req).url)
                print streamlink
                addLink(name,streamlink,'')
        except:
               Notify('small','Sorry Link Removed:', 'Please try another one.',9000)

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addLink(name,url,iconimage):
        ok=True
        liz=xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage='')
        liz.setInfo( type="Video", infoLabels={ "Title": name } )
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=url,listitem=liz,isFolder=False)
        return ok

def addDir(name,url,mode,iconimage,types):
        EnableFanArt = local.getSetting('Enable-Fanart')
        ok=True
        type = types
        if type != None:
                infoLabels = silent.GRABMETA(name,url,types)
        else: infoLabels = {'title':name}
        try: img = infoLabels['cover_url']
        except: img= iconimage
        if EnableFanArt == 'true':
                try:    fimg = infoLabels['backdrop_url']
                except: fimg = addon.get_fanart()
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=img)
        liz.setInfo( type="Video", infoLabels= infoLabels)
        liz.setProperty( "Fanart_Image", fimg )
        contextMenuItems = []
        if mode == 7:
                contextMenuItems = []
                contextMenuItems.append(('Add to Favorites', 'XBMC.RunPlugin(%s?mode=13&name=%s&url=%s&types=%s)' % (sys.argv[0], name, urllib.quote_plus(url), types)))
                liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok

def addFAVDir(name,url,types):
        EnableFanArt = local.getSetting('Enable-Fanart')
        mode = 7
        iconimage = ''
        ok=True
        type = types
        fimg = addon.get_fanart()
        if type != None:
                infoLabels = silent.GRABMETA(name,url,types)
        else: infoLabels = {'title':name}
        try: img = infoLabels['cover_url']
        except: img = iconimage
        if EnableFanArt == 'true':
                try:    fimg = infoLabels['backdrop_url']
                except: fimg = addon.get_fanart()
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=img)
        liz.setInfo( type="Video", infoLabels= infoLabels)
        liz.setProperty( "Fanart_Image", fimg )
        ###Add to Library Context Menu
        contextMenuItems = []
        contextMenuItems.append(('Remove from Favorites', 'XBMC.RunPlugin(%s?mode=14&name=%s&url=%s&types=%s)' % (sys.argv[0], name, urllib.quote_plus(url), types)))
        liz.addContextMenuItems(contextMenuItems, replaceItems=True)
        ##############################
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
    
params=get_params()
url=None
name=None
mode=None
types=None

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        types=urllib.unquote_plus(params["types"])
except:
        pass

print "Mode: "+str(mode)
print "URL: "+str(url)
print "Name: "+str(name)


if mode==None or url==None or len(url)<1:
        print ""
        CATEGORIES()
        
elif mode==1:
        print ""+url
        FEATURED(url)

elif mode==2:
        print ""+url
        NEW(url)

elif mode==3:
        print ""+url
        TOP(url)

elif mode==4:
        print ""+url
        AZ(url)

elif mode==5:
        print ""+url
        SEARCH(url)

elif mode==6:
        GETMYFAVS()

elif mode==7:
        print ""+url
        SEASONS(name,url)

elif mode==8:
        print ""+url
        EPISODES(name,url)

elif mode==9:
        print ""+url
        VIDEOLINKS(url)

elif mode==10:
        print ""+url
        STREAM(url)

elif mode==11:
        print ""+url
        INDEX(url)

elif mode==12:
        print ""+url
        SPECIALHOST(url,name)

elif mode==13:
        print ""+url
        silent.addFavorite(name,url,types)

elif mode==14:
        print ""+url
        silent.removeFavorite(name,url,types)

xbmcplugin.endOfDirectory(int(sys.argv[1]))
        
