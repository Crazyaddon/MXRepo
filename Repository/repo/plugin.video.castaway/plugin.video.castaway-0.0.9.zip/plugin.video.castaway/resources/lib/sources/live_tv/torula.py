from __future__ import unicode_literals
from resources.lib.modules import client
import re,json,urllib2,sys,os

from addon.common.addon import Addon
addon = Addon('plugin.video.castaway', sys.argv)

AddonPath = addon.get_path()
IconPath = AddonPath + "/resources/media/"
def icon_path(filename):
    return os.path.join(IconPath, filename)


class info():
    def __init__(self):
    	self.mode = 'torula'
        self.name = 'torula.com'
        self.icon = 'torula.png'
        self.paginated = False
        self.categorized = True
        self.multilink = False
class main():
	def __init__(self,url = 'http://castalba.tv/channels'):
		self.base = 'http://castalba.tv/channels'
		self.url = url

	def categories(self):
		cats = [('Sport Channels','http://schedule.torula.com/channels-sports.json'),('Sport Channels Live','http://schedule.torula.com/channels-live-sports.json'),('News Channels','http://schedule.torula.com/channels-news.json'),
			('News Channels Live','http://schedule.torula.com/channels-live-news.json'), ('Music Channels','http://schedule.torula.com/channels-music.json'), ('Kids Channels','http://schedule.torula.com/channels-kids.json')]
		out=[]
		for cat in cats:
			ch = cat[0]
			url = cat[1]
			out.append((url,ch,info().icon))
		return out

	def channels(self,url):

		self.url = url
		
		try:
			jsoni = json.loads(client.request(url))
			events = self.__prepare_channels(jsoni)
		except:
			events = []
		return events

	def __prepare_channels(self,channels):
		new=[]
		for channel in channels:
			title = channel['title']
			url = channel['url']
			item = (url,title,icon_path(info().icon))
			new.append(item)
		return new

	

