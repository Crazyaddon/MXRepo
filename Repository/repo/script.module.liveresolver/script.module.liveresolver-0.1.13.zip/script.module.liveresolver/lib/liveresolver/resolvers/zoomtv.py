# -*- coding: utf-8 -*-


import re,urlparse,urllib
from liveresolver.modules import client,decryptionUtils


def resolve(url):
    try:
        referer = urlparse.parse_qs(urlparse.urlparse(url).query)['referer'][0]
        headers = { 'referer': referer,
                                 'Accept' : 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                                 'Connection' : 'keep-alive',
                                 'Host' : 'www.zoomtv.me',
                                 'Origin' : urlparse.urlparse(referer).netloc
                                 }
        fid = urlparse.parse_qs(urlparse.urlparse(url).query)['v'][0]
        cx = urlparse.parse_qs(urlparse.urlparse(url).query)['cx'][0]
        pid = urlparse.parse_qs(urlparse.urlparse(url).query)['pid'][0]
        url = 'http://www.zoomtv.me/embed.php?v=%s&vw=660&vh=450'%fid
        post_data = {'cx' : cx,
        			'lg' : '1' ,
        			'pid' : pid }
        result = client.request(url, post=urllib.urlencode(post_data),headers = headers, mobile=True)
        result = decryptionUtils.doDemystify(result)
        url = result
        var = re.compile('var\s.+?\s*=\s*\'(.+?)\'').findall(result)
        for v in var:
            if 'm3u8' in v:
                m3u8 = v
            if 'file' in v:
                file = v
        url = m3u8 + file
        url += '|%s' % urllib.urlencode({'User-Agent': client.agent(), 'Referer': referer})
        return url
    except:
        return