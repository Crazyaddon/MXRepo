# -*- coding: utf-8 -*-


import re,urllib
from liveresolver.modules import client

def resolve(url):
    try:
        try:
            id  = urlparse.parse_qs(urlparse.urlparse(url).query)['id'][0] 
        except:
            id = re.compile('live/(.+?)(?:/|$)').findall(url)[0]
        url = 'http://aliez.me/live/%s/'%id
        result = client.request(url, referer=url)
        url = re.findall('src=(?:\'|\")(.+?\.m3u8)(?:\'|\")',result)[0]
        
        return url
    except:
       return

