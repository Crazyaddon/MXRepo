# -*- coding: utf-8 -*-



import re,urllib,urlparse
from liveresolver.modules import client
from liveresolver.modules import jsunpack


def resolve(url):
    page=url
    try: referer = urlparse.parse_qs(urlparse.urlparse(url).query)['referer'][0]
    except: referer = page
    from selenium import webdriver

    profile = webdriver.FirefoxProfile()
    profile.set_preference('network.dns.disableIPv6', True)
    driver = webdriver.Firefox(profile)

    driver.get(referer)
    driver.switch_to_frame(driver.find_element_by_xpath("//iframe[contains(@src,'sawlive')]"))
    url = driver.execute_script("return so.getVariables().streamer")+' playpath='+driver.execute_script("return so.getVariables().file")
    driver.quit()
    return url + 'flashver=WIN/2018,0,0,232 timeout=15 swfUrl=http://static3.sawlive.tv/player.swf live=true pageUrl='+page

