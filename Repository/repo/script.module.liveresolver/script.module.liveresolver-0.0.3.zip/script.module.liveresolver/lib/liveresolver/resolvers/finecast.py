# -*- coding: utf-8 -*-


import re,urlparse
from liveresolver.modules import client

def resolve(url):
    try:
        try:
            referer = urlparse.parse_qs(urlparse.urlparse(url).query)['referer'][0]
        except:
            referer=url
        id = urlparse.parse_qs(urlparse.urlparse(url).query)['u'][0]
        url = 'http://www.finecast.tv/embed4.php?u=%s&vw=640&vh=450'%id
        result = client.request(url, referer=referer)
        t = re.compile("var t\s*=\s*'(.+?)';").findall(result)[0]
        m = re.compile("var m\s*=\s*'(.+?)';").findall(result)[0]
        streamer = re.compile('file\s*:\s*\'(.+?)\'').findall(result)[0]
        url = streamer + "%s playpath=%s swfUrl=http://www.finecast.tv/player6/jwplayer.flash.swf flashver=WIN\\2019,0,0,185 live=1 timeout=14 swfVfy=1 pageUrl=http://www.finecast.tv/"%(t,m)
        return url
    except:
       return

