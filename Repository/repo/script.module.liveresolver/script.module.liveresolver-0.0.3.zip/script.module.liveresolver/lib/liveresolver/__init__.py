# -*- coding: utf-8 -*-
import re
from modules import client,webutils
import urlparse,urllib
from BeautifulSoup import BeautifulSoup as bs



def resolve(url):
    try:
        print(url)
        resolved=resolve_it(url)
        if resolved==None:
            url=find_link(url)
            resolved=url
            url=resolve_it(url)
            if url!=None:
                resolved=url
        return resolved
    except:
       return url



resolver_dict={ 'sawlive.tv': 'sawlive',
            'streamking.co': 'streamking',
            'castalba.tv' : 'castalba',
            'p2pcast.tv' : 'p2pcast',
            'finecast.tv' : 'finecast',
            'filmon.com' : 'filmon',
            'miplayer.net' : 'miplayer',
            'lshstream.com' : 'lshunter',
            'castamp.com' : 'castamp',
            'yocast.tv': 'yocast',
            'streamlive.to' : 'streamlive',
            '04stream.com' : 'o4stream',
            'ustream.tv' : 'ustream' ,
            'playwire.com' : 'playwire',
            'leton.tv' : 'leton',
            'yotv.co' : 'yotv',
            'hdcast.me' : 'hdcast',
            'zerocast.tv' : 'zerocast',
            'castup.tv' : 'castup',
            'mybeststream.xyz' :'mybeststream',
            'sunhd.info' : 'sunhd',
            'youtube.com' : 'youtube',
            'livestream.com' : 'livestream',
            'new.livestream.com' : 'livestream',
            'privatestream.tv' : 'privatestream',
            'airq.tv' : 'airq',
            'aliez.me' : 'aliez',
            'p3g.tv' : 'p3g',
            'liveflashplayer.net' : 'liveflashplayer',
            'laola1.tv' : 'laola1',
            'ehftv.com' : 'ehftv',
            'zoocdn.zoomtv.me' : 'zoomtv'
              }

def find_link(url):
    try: referer = urlparse.parse_qs(urlparse.urlparse(url).query)['referer'][0]
    except: referer = url
    html=client.request(url,referer=referer)
    ref=url
    fs=list(globals().copy())
    for f in fs:
        if 'finder' in f:
            resolved = eval (f+"(html,ref)")
            if resolved:
                print('Resolved with %s: %s'%(f,resolved))
                return resolved
                break
    return


def resolve_it(url):
    if '.m3u8' in url or 'rtmp:' in url or '.flv' in url or '.mp4' in url:
        return url
    elif 'sop://' in url or 'acestream://' in url:
        from lib.resolvers import sop_ace
        return sop_ace.resolve(url,'Channel')

    netloc = urlparse.urlparse(url).netloc
    netloc = prepare(netloc)
    print(netloc)
    if netloc in resolver_dict.keys():
        resolver = resolver_dict[netloc]
        exec "from resolvers import %s"%resolver
        resolved = eval(resolver+".resolve(url)")
        return resolved

    else:
       return 

def prepare(netloc):
    netloc = netloc.replace('www.','').replace('config.','')
    netloc = re.sub(r'www\d+.','',netloc)
    return netloc


#embeded iframes
def finder1(html,url):
    ref=url
    try:
        urls = re.findall('<iframe.+?src="(.+?)"',html)
        for url in urls:
            
            if 'http' not in url:
                uri = 'http://' + urlparse.urlparse(ref).netloc + '/' + url
            else:
                uri = url
            resolved = find_link(uri) 
            if resolved:
                break
        return resolved
    except:
        return

#lsh stream
def finder2(html,url):
    try:
        reg = re.compile('[^\"\'](http://www.lshstream.com[^\"\']*)')
        url = re.findall(reg,html)[0]
        return url
    except:
        try:
            reg = re.compile('<script type="text/javascript"> fid="(.+?)"; v_width=.+?;\s*v_height=.+?;</script><script type="text/javascript" src="http://cdn.lshstream.com/embed.js">')
            fid = re.findall(reg,html)[0]
            url = 'http://www.lshstream.com/embed.php?u=%s&vw=720&vh=420&live.realstreamunited.com=%s'%(fid,url)
            return url
        except:
            return

#castalba
def finder3(html,url):
    try:
        reg=re.compile('<script type="text/javascript"> id="(.+?)"; ew=".+?"; eh=".+?";</script><script type="text/javascript" src="http://www.castalba.tv/js/embed.js"></script>')
        id=re.findall(reg,html)[0]
        url = 'http://castalba.tv/embed.php?cid=%s&wh=600&ht=380'%id
        return url
    except:
      return

#jw_config
def finder4(html,url):
    try:
        try:
            link = re.compile('file\s*:\s*"(.+?)"').findall(html)[0]
        except:
            link = re.compile("file\s*:\s*'(.+?)'").findall(html)[0]
        if '.png' in link:
            return
        return link
    except:
        return 


#vlc_config
def finder5(html,url):
    try:
        soup=bs(html)
        try:
            link=soup.find('embed',{'id':'vlc'})
            link=link['target']

        except:
            link=soup.find('embed',{'name':'vlc'})
            link=link['target']  
        return link          
    except:
        return 

#sawlive
def finder6(html,url):
    try:
        uri = re.compile("[\"']([^\"\']*sawlive.tv\/embed\/[^\"'\/]+)\"").findall(html)[0] 
        page = re.compile('//.+?/(?:embed|v)/([0-9a-zA-Z-_]+)').findall(uri)[0]
        host  = urlparse.urlparse(uri).netloc
        uri = 'http://sawlive.tv/embed/%s?referer=%s&host=%s' % (page,url,host)
        return uri
    except:
        try:
            uri = re.compile("src=(?:\'|\")(http:\/\/(?:www\.)?sawlive.tv\/embed\/.+?)(?:\'|\")").findall(html)[0] 
            page = re.compile('//.+?/(?:embed|v)/([0-9a-zA-Z-_]+)').findall(uri)[0]
            host  = urlparse.urlparse(uri).netloc
            uri = 'http://sawlive.tv/embed/%s?referer=%s&host=%s' % (page,url,host)
            return uri
        except: 
            return

#yocast
def finder7(html,url):
    try:
        reg=re.compile('<script>fid="(.+?)";\s*v_width=.+?;\s*v_height=.+?;</script><script type="text/javascript" src="http://www.yocast.tv/embed.js"></script>')
        id = re.findall(reg,html)[0]
        url='http://www.yocast.tv/embed.php?live=%s&vw=600&vh=450'%id
        return url
    except:
        return



#miplayer
def finder8(html,url):
    try:
        reg = re.compile("(http://(?:www\.)?miplayer.net/embed[^'\"]+)")
        url = re.findall(reg,html)[0]
        return url
    except:
        return

#castamp
def finder9(html,url):
    try:
        reg = re.compile("(http://(?:www.)?castamp.com/embed.php\?c=[^\"&]+)")
        url = re.findall(reg,html)[0]
        return url
    except:
        return

#04 stream
def finder10(html,url):
    try:
        reg = re.compile('04stream.com/\w+\.js\?stream=([^ "\'&]+)')
        url = re.findall(reg,html)[0]
        url = 'http://www.04stream.com/weed.js?stream=%s&width=600&height=460&str=is&link=1&cat=3'%url
        return url
    except:
        return

#leton
def finder11(html,url):
    try:
        html = urllib.unquote(html)
        reg = re.compile('leton.tv/player.php\?streampage=([^&]+)&')
        url = re.findall(reg,html)[0]
        url = 'http://leton.tv/player.php?streampage=%s&width=600&height=450'%url
        return url
    except:
        return

#yotv.co
def finder12(html,url):
    try:
        ref=url
        reg = re.compile("<script type='text/javascript'>\s*fid=(?:\'|\")(.+?)(?:\'|\");\s*v_width=.+?;\s*v_height=.+?;</script><script type='text/javascript' src='http://www.yotv.co/player.js'></script>")
        url = re.findall(reg,html)[0]
        url = 'http://www.yotv.co/embed.php?live=%s&vw=620&vh=490&referer=%s'%(url,ref)
        return url
    except:
        return

#hdcast
def finder13(html,url):
    try:
        url = re.compile('src="(http://(?:www\.)?hdcast.me/embed[^\'"]+)').findall(html)[0]
        return url 
    except:
        pass

#zerocast
def finder14(html,url):
    try:
        ref=url
        url = re.compile('zerocast\.(?:tv|in)/(?:channel|embed)?\.php\?a=(\d+)').findall(html)[0]
        url = 'http://zerocast.tv/channel.php?a=%s&width=640&height=480&autostart=true'%url
        return url 
    except:
        pass

#castup
def finder15(html,url):
    try:
        reg = '<script type="text/javascript">\s*fid=(?:\'|\")(.+?)(?:\'|\");\s*v_width=.+?;\s*v_height=.+?;</script><script type="text/javascript" src="http://www.castup.tv/js/embed_1.js">'
        url = re.findall(reg,html)[0]
        url = 'http://www.castup.tv/embed_1.php?channel=%s&vw=640&vh=440'%url
        return url
    except:
        return

#mybeststream(not implemented)
def finder16(html,url):
    try:
        ref=url
        id = re.findall('id=(?:\'|\")(\d+)(?:\'|\");width=.*?pt987.googlecode.com',html)[0]
        url = 'http://mybeststream.xyz/gen_s.php?id=%s&width=650&height=400&referer=%s'%(id,ref)
        return url
    except:
        pass
#sunhd(not implemented)
def finder17(html,url):
    try:
        ref=url
        url = re.findall('src="(http://www.sunhd.info/channel.php\?file=.+?)"',html)[0]
        return url+'&referer=%s'%ref
    except:
        pass

#youtube
def finder18(html,url):
    try:
        url = re.findall('src="?(https?://(?:www.|)youtube(?:-nocookie)?.com.+?)\?',html)[0]
        return url.replace('amp;','').replace('-nocookie','')
    except:
        return

#livestream
def finder19(html,url):
    try:
        url = re.findall('(http://(?:new\.)?livestream.com[^"]+)',html)[0]
        if 'player' in url:
            return url
    except:
        return

#privatestream
def finder20(html,url):
    try:
        try:
            id = re.findall('privatestream.tv/player\?streamname=([^&]+)&', html)[0]
        except:
            id = re.findall('privatestream.tv/((?!player)[^\.&\?\=]+)',html)[0]

        print(id)
        if id != 'js/jquery-1':
            url = 'http://privatestream.tv/player?streamname=%s&width=640&height=490'%id
            return url
        else:
            return
    except:
        return

#airq.tv
def finder21(html,url):
    try:
        id = re.findall('(?:SRC|src)="http://airq.tv/(\w+)',html)[0]
        url = 'http://airq.tv/%s/'%id
        return url
    except:
        return

#aliez
def finder22(html,url):
    try:
        try:
            id = re.findall('emb.aliez[\w\.]+?/player/live.php\?id=([^&"]+)',html)[0]
            return 'http://emb.aliez.me/player/live.php?id=%s&w=728&h=480'%id
        except:
            try:
                id = re.findall('(?:94.242.255.35|195.154.44.194|aliez\.\w+)/player/(?:live|embed).php\?id=(\d+)',html)[0]
            except:
                id = re.findall('http://aliez.(?:me|tv)/live/(.+?)(?:/|"|\')',html)[0]
            return 'http://emb.aliez.me/player/live.php?id=%s&w=728&h=480'%id
        return
    except:
        return

#p3g
def finder23(html,url):
    try:
        id = re.findall("channel='(.+?)',\s*g='.+?';</script><script type='text/javascript' src='http://p3g.tv/resources/scripts/p3g.js'",html)[0]
        url = 'http://www.p3g.tv/embedplayer/%s/2/600/420'%id
        return url
    except:
        return


#dinozap (not implemented)
def finder24(html,url):
    try:
        url = re.findall('(http://(?:www\.)?dinozap.info/redirect/channel.php\?id=[^"\']+)',html)[0]
        return url
    except:
        return

#liveflashplayer
def finder25(html,url):
    try:
        id = re.findall("channel='(.+?)', g='.+?';</script><script type='text/javascript' src='http://www.liveflashplayer.net/resources/scripts/liveFlashEmbed.js'>",html)[0]
        url = 'http://www.liveflashplayer.net/membedplayer/%s/1/620/430'%id
        return url
    except:
        return

#laola1
def finder26(html,url):
    try:
        url = re.findall('(http://www.laola1.tv[^"]+)', html)[0]
        return url
    except:
        pass

#ehftv
def finder27(html,url):
    try:
        url = re.findall('src=(?:\'|\")(http:\/\/(?:www\.)?ehftv.com(?:/|//)player\.php[^\'\"]+)',html)[0]
        return url
    except:
        return

#zoomtv
def finder28(html,url):
    try:
        ref=url
        fid = re.findall('fid="(.+?)".+?</script><script type="text/javascript" src="http://zome.zoomtv.me/js/empedv4.js',html)[0]

        url = 'http://www.zoocdn.zoomtv.me/embed.php?v=' + fid + '&vw=660&vh=450&referer=%s'%ref
        return url
    except:
        return