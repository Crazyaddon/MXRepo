script.pulsar.kiasmulti
=======================

Provaider kickass multilanguage update for Pulsar 0.3
