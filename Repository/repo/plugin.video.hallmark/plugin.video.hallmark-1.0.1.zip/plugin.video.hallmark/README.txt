plugin.video.hallmark
================

Kodi Addon for Hallmark Channel website

Version 1.0.1 initial release

