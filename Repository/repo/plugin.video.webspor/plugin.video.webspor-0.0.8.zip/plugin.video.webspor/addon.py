﻿import threading

import boogietools as bt

bt.initdirs("plugin.video.webspor")

from webspor import webspor as ws
from webspor import scrapers as sc
from webspor import ui

handle,page,args=bt.link_from()
ui=ui.crateui()
th=threading.Thread(target=ws.list_items,args=(sc.scrape_channels(),ui))
th.start()
ui.doModal()