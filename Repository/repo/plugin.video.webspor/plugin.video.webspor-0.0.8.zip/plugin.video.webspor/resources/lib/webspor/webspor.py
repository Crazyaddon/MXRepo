import datetime
import time

from third import humanize

import xbmcgui

import boogietools as bt
import defs

def updatetitle(li):
	if not bt.getliprop(li,"status") == "" and not bt.getliprop(li,"last_check") is None:
		since="since %s [/COLOR]"%humanize.naturaltime(datetime.datetime.now()-datetime.datetime.fromtimestamp(bt.getliprop(li,"last_check")))
		if time.time()-float(bt.getliprop(li,"last_check"))>defs.mtimeout*60*60:
			status=""
			since=""
		else:
			status=bt.getliprop(li,"status")
	else:
		since=""
		status=""
	ctitle="%s %d %s %s %s"%(defs.notifications["channel"], bt.getliprop(li,"number"), bt.getliprop(li,"name"),status, since)
	li.setLabel(ctitle)

def list_items(channels,ui):
	time.sleep(1)
	k=0
	for cnum,channel in channels.iteritems():
		k+=1
		li=xbmcgui.ListItem(iconImage="DefaultFolder.png", thumbnailImage="DefaultFolder.png")
		bt.setliprops(li,channel)
		updatetitle(li)
		bt.setliprop(li,"icon0","")
		bt.setliprop(li,"icon1","")
		ui.addListItem(li)
		ui.progress.setPercent(100*k/len(channels.keys()))

def update_channels(channels,ui):
	list_items(channels,ui)
	ui.check_items()

