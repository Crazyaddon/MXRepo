import boogietools as bt
import livelib

import re
import urlparse
import time
import datetime

import defs
from webspor import updatetitle
from ui import loadchans

ll=livelib.livelib()

def scrape_channel_page(li,tout=None):
	# scrapes the given channel and return a playable url
	# arguments: channel:dict ; {"link":"/channel1","name":"Channel1","status":"state","number":int(1)}
	# returns stream:str
	link=bt.getliprop(li,"link")
	purl="%s/HD/TV/%s"%(defs.domain,link)
	page=bt.get_page(purl,defs.encoding)
	aliez=re.findall('src="(.*?aliez\..*?/player/live\.php.*?)"',page)
	mips=re.findall("channel='(.*?)', .='(.*?)';</script><script type='text/javascript' src='(.*?)'></script>",page)
	playerhd=re.findall("http://(.*?)/.*php\?file=([0-9]*?)&",page)
	weplayer=re.findall("<script type='text/javascript'>\s?id='(.*?)'; width='([0-9]*?)'; height='([0-9]*?)';.*?src='http://weplayer.pw/player.js'>",page)
	jw=re.findall('content.jwplatform.com/players/(.*?)\.html"',page)
	worldspor=re.findall('fid="(.*?)"',page)
	micast=re.findall('src="(.*?/iframe.php\?ch=.*?)"',page)
	sostart=re.findall("id='(.*?)';.*?</script><script type='text/javascript' src='http://sostart.org/player.js'></script>",page)
	ll.timeout=tout
	if len(aliez)>0:
		#id=urlparse.parse_qs(urlparse.urlparse(aliez[0]).query)["id"][0]
		type,stream=ll.scrape_url("aliez",aliez[0],defs.domain)
	elif len(jw)>0:
		type,stream=ll.scrape_url("jw",jw[0],defs.domain)
	elif len(worldspor)>0:
		type,stream=ll.scrape_url("worldspor",worldspor[0],defs.domain)
	elif len(micast):
		type,stream=ll.scrape_url("micast",micast[0],purl)
	elif len(mips)>0:
		channel=mips[0][0]
		e=mips[0][1]
		script=mips[0][2]
		type,stream=ll.scrape_url("mips",channel,e,script,defs.domain)
	elif len(weplayer)>0:
		id,w,h=weplayer[0]
		type,stream=ll.scrape_url("weplayer",id,defs.domain,w,h)
	elif len(playerhd)>0:
		domain,id=playerhd[0]
		type,stream=ll.scrape_url("playerhd",domain,id,purl)
	elif len(sostart)>0:
		type,stream=ll.scrape_url("sostart",sostart[0],purl)
	else:
		type="ERROR: WEBSPOR | Can't detect streaming service type"
		stream = ""

	if "ERROR:" in type:
		bt.notify(bt.getliprop(li,"name"),type)
		bt.setliprop(li,"status",defs.notifications["orange"]%type)
		bt.setliprop(li,"last_check",time.time())
		return None
	else:
		return stream


def scrape_streaming_channels():
	# scrapes the channel list which is listed on site as currently streaming. These info  are not very reliable some of the times. Used to retrive channel name and event timing
	# arguments: None
	# returns {n:channel,}:dict ; {1:{"link":"/channel1","name":"Lig TV...","status":"",},2:{...}..]
	online_chans={}
	page=bt.get_page(defs.domain+"/HD/TV/info/home",defs.encoding)
	events=re.findall('<div class="top-event">(.*?)</div>',page,re.DOTALL)
	for event in events:
		title=re.findall('<h2 class="pix-post-title">(.*?)<br>',event,re.DOTALL)
		title=re.sub('<[^<]+?>', '', title[0])
		title=re.sub(' I ',' ',title)
		title=re.sub('\s\s',' ',title)
		cnums=re.findall('<a target="orta" href=".*?channel([0-9]*?)">',event,re.DOTALL)
		etime=title.split()[0]
		opps=" ".join(title.split()[1:])
		if ":" in etime:
			hour,minute=etime.split(":")
			event_time=datetime.datetime.now()
			event_time=event_time.replace(hour=int(hour),minute=int(minute))
			event_time=bt.localtime_from_timezone(event_time,"Turkey")
			event_time=event_time.strftime("%H:%M")
		else:
			event_time=etime
		ctitle="%s | %s "%(event_time,opps)
		for cnum in cnums:
			online_chans[int(cnum)]={"link":"info/channel%s"%cnum,"name":ctitle,"status":"","number":int(cnum),"last_check":None}
	return online_chans

def scrape_list_channels():
	# scrapes listing channels from the site
	# arguments: None
	# returns {n:channel,}:dict ; {1:{"link":"/channel1","name":"Channel1","status":"",},2:{...}..]
	all_chans={}
	page=bt.get_page(defs.domain,defs.encoding)
	chans=re.findall('<li><a target="orta" href=".*?info/channel([0-9]*?)">',page)
	for cnum in chans:
		clink="info/channel%s"%cnum
		ctitle="%s %s"%(defs.notifications["channel"],cnum)
		all_chans[int(cnum)]={"link":clink,"name":"","status":"","number":int(cnum),"last_check":None}
	return all_chans

def update_channels(channels,updated_channels,props):
	for cnum,channel in updated_channels.iteritems():
		if cnum in channels.keys():
			for prop in props:
				channels[cnum][prop]=channel[prop]
	return channels

def scrape_channels():
	channels=scrape_list_channels()
	streaming_channels=scrape_streaming_channels()
	updated_channels=update_channels(channels,streaming_channels,["name"])
	return update_channels(updated_channels,loadchans(),["last_check","status"])