import xbmc
import xbmcaddon

addon=xbmcaddon.Addon ("plugin.video.webspor")
timeout=int(addon.getSetting("watch_timeout"))
mtimeout=int(addon.getSetting("memory_timeout"))
domain="http://www.webspor.site"
encoding="iso-8859-9"
notifications={"red":"[COLOR red]%s",
 		    "orange":"[COLOR orange]%s",
			 "green":"[COLOR green]%s",
		    "online":"Channel is Online",
		   "offline":"Channel is Offline",
			 "check":"WEBSPOR: Checking...",
			  "live":"Live!",
			  "dead":"Dead",
 		   "waiting":"Waiting for %s : %ds",
		   "approve":"Webspor is going to check %d channels one by one, this procedure can take up to %s. Please be patient. Do you want to continue?",
     	  "finished":"Webspor finished checking of %d channels in %s",
		   "channel":xbmc.getLocalizedString(19029)
			}

