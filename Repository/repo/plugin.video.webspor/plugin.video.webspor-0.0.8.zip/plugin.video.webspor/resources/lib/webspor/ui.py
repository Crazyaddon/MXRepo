import pickle
import copy

import boogieui as bui
import boogietools as bt

import scrapers
import defs

from webspor import updatetitle

import xbmc

class window(bui.sportsui):
	def __init__(self,*args,**kwargs):
		bui.sportsui.__init__(self,*args,**kwargs)

	def onAction(self, action):
		bui.sportsui.onAction(self,action)
		li=self.lst.getSelectedItem()
		if li is None:
			return None
		seps=["vs","/","-","v.s","v.s."]
		for icon in [0,1]:
			img=bt.getliprop(li,"icon%d"%icon)
			if isinstance(img,str) and img.startswith("http"):
				continue
			for sep in seps:
				name=bt.getliprop(li,"name")
				if ":" in name:
					name=name.split(":")[-1]
				ops=name.split(sep)
				if len(ops)==2:
					img=bt.web_search("images","%s logo filetype:png "%ops[icon])
					if len(img)>0:
						bt.setliprop(li,"icon%d"%icon,str(img[0]))

class rplayer(bui.splayer):
	def __init__(self,*args, **kwargs):
		bui.splayer.__init__(self,*args,**kwargs)

	def scraper(self,*args,**kwargs):
		return scrapers.scrape_channel_page(*args,**kwargs)
	
	def notification(self,percent,msg):
		self.ui.progress.setPercent(float(percent))
		self.ui.note.setLabel(msg)

	def postprocess(self,li):
		bui.splayer.postprocess(self,li)
		updatetitle(li)
		savechan(li)

	def create_item(self,li):
		ctitle="%s %d %s"%(defs.notifications["channel"], bt.getliprop(li,"number"), bt.getliprop(li,"name"))
		item=copy.copy(li)
		item.setLabel(ctitle)
		return item

def crateui():
	player=rplayer()
	ui=window("sports.xml",bt.addondir("script.module.boogietools"),'Default', '720p')
	ui.setPlayer(rplayer())
	return ui

def loadchans():
	chans=defs.addon.getSetting("chanstates")
	if chans=="N/A":
		return {}
	else:
		return pickle.loads(chans)

def savechan(li):
	channel=bt.getliprops(li,["link","name","status","number","last_check"])
	channels=loadchans()
	channels[channel["number"]]=channel
	defs.addon.setSetting("chanstates",pickle.dumps(channels))