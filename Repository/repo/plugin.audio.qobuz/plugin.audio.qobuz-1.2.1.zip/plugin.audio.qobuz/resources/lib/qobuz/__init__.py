'''
    qobuz
    ~~~~~

    :part_of: xbmc-qobuz
    :copyright: (c) 2012 by Joachim Basmaison, Cyril Leclerc
    :license: GPLv3, see LICENSE for more details.
'''
__all__ = ['addon', 'boot', 'path', 'rpc']

addon = None
#debug = None
path = None
boot = None
rpc = None
player = None
