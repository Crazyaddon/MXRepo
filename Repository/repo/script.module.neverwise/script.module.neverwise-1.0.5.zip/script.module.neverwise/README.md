script.module.neverwise
================

NeverWise Kodi toolkit (tested on Kodi 15.1 Isengard).
