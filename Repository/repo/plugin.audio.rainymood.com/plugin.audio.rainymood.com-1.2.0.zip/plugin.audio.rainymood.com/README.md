Rainymood.com lets you listen to the soothing sound of rain from within your media center.
Created by Christoph Dwertmann <cdwertmann@gmail.com>

Licensed under GPL (see LICENSE.txt for details)
