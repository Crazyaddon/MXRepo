# -*- coding: utf-8 -*-
'''
    Torrenter plugin for XBMC
    Copyright (C) 2012 Vadim Skorba
    vadim.skorba@gmail.com

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import Content, re

class EZTVAZ(Content.Content):
    baseurl = "http://eztv.ag"
    headers = [('User-Agent',
                'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124' + \
                ' YaBrowser/14.10.2062.12061 Safari/537.36'),
               ('Referer', 'https://eztv.ag/'), ('Accept-Encoding', 'gzip'), ('Cookie','showlist_thumbs=1')]
    '''
    Weight of source with this searcher provided.
    Will be multiplied on default weight.
    Default weight is seeds number
    '''

    def get_contentList(self, category):
        contentList = []
        url = self.baseurl+'/showlist/'

        response = self.makeRequest(url, headers=self.headers)

        if None != response and 0 < len(response):
            #print response
            contentList = self.alpha(response, category)
        #print str(contentList)
        return contentList

    def get_torrentList(self, link):
        contentList = []
        url = self.baseurl+link
        print url

        response = self.makeRequest(url, headers=self.headers)

        if None != response and 0 < len(response):
            #print response
            contentList = self.mode(response)
        #print str(contentList)
        return contentList

    def alpha(self, response, category):
        contentList = []
        #print str(result)
        regex = '<tr.+?</tr>'
        results = re.compile(regex, re.DOTALL).findall(response)
        regex_tr = r'''<tr name="hover">.+?<a href="(/shows/.+?)" class="thread_link"><img src="(.+?)" w.+?class="thread_link">(.+?)</a>'''

        for tr in results:
            result = re.compile(regex_tr, re.DOTALL).findall(tr)
            if result:
                link, img, title = result[0]
                if category==u'0' and title[0] not in ['0','1','2','3','4','5','6','7','8','9']:
                    #print '1'+str((subcategory, title[0].lower(), title))
                    continue
                if category!=u'0' and category.lower()!=title[0].lower():
                    #print '2'+str((subcategory, title[0].lower(), title))
                    continue

                #print str((link, img, title))
                #main
                info = {}
                original_title = None
                year = 0
                img = 'http:'+img.replace('thumb_50_42.png','main.png')
                #info

                info['label'] = info['title'] = title
                info['link'] = link
                info['plot'] = info['title']#+'\r\nAge: %s' % (date)

                contentList.append((original_title, title, int(year), img, info))
        return contentList

    def mode(self, response):
        contentList = []
        #print str(result)
        num = 51
        result = re.compile(
                r'''class="epinfo">(.+?)</a>.+?<a href="(magnet.+?)"''',
                re.DOTALL).findall(response)
        for title, link in result:
            #main
            info = {}
            num = num - 1
            original_title = None
            year = 0
            img = ''
            #info

            info['label'] = info['title'] = title
            info['link'] = link
            info['plot'] = info['title']

            contentList.append((
                original_title, title, int(year), img, info,
            ))
        return contentList
