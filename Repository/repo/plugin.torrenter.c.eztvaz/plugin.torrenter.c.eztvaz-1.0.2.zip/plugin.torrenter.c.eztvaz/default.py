# -*- coding: utf-8 -*-

import xbmcaddon, xbmcgui, xbmcplugin
import urllib, os, sys, string

__settings__ = xbmcaddon.Addon(id='plugin.torrenter.c.eztvaz')
__version__ = __settings__.getAddonInfo('version')
__plugin__ = __settings__.getAddonInfo('name') + " v." + __version__
ROOT = __settings__.getAddonInfo('path')
__version__ = "1.0.2"
__author__ = "DiMartino"
__language__ = __settings__.getLocalizedString
open_option = int(__settings__.getSetting('open_option'))

print 'SYS ARGV: ' + str(sys.argv)

def drawItem(title, action, link={}, image='', isFolder=True, contextMenu=None, replaceMenu=True, action2='', isTorrenter=False,
             info={}):
    listitem = xbmcgui.ListItem(title, iconImage=image, thumbnailImage=image)
    if not info: info = {"Title": title, "plot": title}
    link_url = ''
    for key in link.keys():
        if link.get(key):
            link_url = '%s&%s=%s' % (link_url, key, urllib.quote_plus(link.get(key)))
    if isTorrenter:
        plug='plugin://plugin.video.torrenter/'
    else:
        plug=sys.argv[0]
    url = '%s?action=%s' % (plug, action) + link_url
    if action2:
        url = url + '&url2=%s' % urllib.quote_plus(action2)
    if not contextMenu:
        contextMenu = [('Search Control Window',
                        'xbmc.RunScript(%s,)' % os.path.join(xbmcaddon.Addon(id='plugin.video.torrenter').getAddonInfo('path'), 'controlcenter.py'))]
        replaceMenu = False
    if contextMenu:
        listitem.addContextMenuItems(contextMenu, replaceItems=replaceMenu)
    if isFolder:
        listitem.setProperty("Folder", "true")
        listitem.setInfo(type='Video', infoLabels=info)
    else:
        listitem.setInfo(type='Video', infoLabels=info)
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, isFolder=isFolder)

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params) - 1] == '/'):
            params = params[0:len(params) - 2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]
    return param

def NZ(val):
    try:
        try:
            return urllib.unquote_plus(params[val])
        except:
            return params[val]
    except:
        return None

def openMain():
    drawItem('< %s >' % '0-9', 'openLetter', link={'letter':'0'}, isFolder=True)
    alphabet=list(string.ascii_lowercase)
    for l in alphabet:
        drawItem('< %s >' % str(l).upper(), 'openLetter', link={'letter':l}, isFolder=True)

def openLetter(letter):
    try:
        ez = getattr(__import__('EZTVAZ'), 'EZTVAZ')()
    except:
        exit()
    contentList=ez.get_contentList(letter)
    for originaltitle, title, year, img, info in contentList:
        try:#spanish non utf-8 fix
            title = title.encode('utf-8', 'ignore')
        except:
            continue
        link = {'url': info['link'], 'thumbnail': img}

        drawItem(title, 'openShow', link, image=img, info=info, replaceMenu=False)

def openShow(link, img=''):
    print str(img)
    try:
        ez = getattr(__import__('EZTVAZ'), 'EZTVAZ')()
    except:
        exit()
    contentList=ez.get_torrentList(link)
    for originaltitle, title, year, imgf, info in contentList:
        try:#spanish non utf-8 fix
            title = title.encode('utf-8', 'ignore')
        except:
            continue
        link = {'url': info['link']}

        contextMenu = [
            ('Download via T-client',
             'XBMC.RunPlugin(%s)' % ('%s?action=%s&url=%s') % (
             'plugin://plugin.video.torrenter/', 'downloadFilesList', urllib.quote_plus('%s::%s' % ('EZTV', info.get('link'))))),
            ('Download via Libtorrent',
             'XBMC.RunPlugin(%s)' % ('%s?action=%s&url=%s') % (
             'plugin://plugin.video.torrenter/', 'downloadLibtorrent', urllib.quote_plus('%s::%s' % ('EZTV', info.get('link'))))),
            ('Search Control Window', 'xbmc.RunScript(%s,)' %
             os.path.join(xbmcaddon.Addon(id='plugin.video.torrenter').getAddonInfo('path'), 'controlcenter.py'))
        ]

        if open_option==0:
            drawItem(title, 'playSTRM', link, image=img, info=info, contextMenu=contextMenu, replaceMenu=False, isTorrenter=True)
        elif open_option==1:
            drawItem(title, 'context', link, image=img, info=info, contextMenu=contextMenu, replaceMenu=False, isFolder=False)
        elif open_option==2:
            link = {'url': '%s::%s' % ('EZTV', info.get('link'))}
            drawItem(title, 'downloadFilesList', link, image=img, info=info, contextMenu=contextMenu, replaceMenu=False, isTorrenter=True)
        elif open_option==3:
            link = {'url': '%s::%s' % ('EZTV', info.get('link'))}
            drawItem(title, 'downloadLibtorrent', link, image=img, info=info, contextMenu=contextMenu, replaceMenu=False, isTorrenter=True)

def context():
    xbmc.executebuiltin("Action(ContextMenu)")
    return

params = get_params()

action  = NZ('action')
letter  = NZ('letter')
show    = NZ('show')
url     = NZ('url')
thumbnail=NZ('thumbnail')

if action == None:
    openMain()
elif action=='openLetter' and letter:
    openLetter(letter)
elif action=='openShow':
    openShow(url, thumbnail)
elif action=='context':
    context()


xbmcplugin.endOfDirectory(int(sys.argv[1]))