plugin.video.sonyliv
================

Kodi Addon for Sony LIV Video website

Version 1.0.15 website change
Version 1.0.14 website change
Version 1.0.13 website errors workaround
Version 1.0.12 website change
Version 1.0.11 website change
Version 1.0.10 website change
Version 1.0.9 website change
Version 1.0.8 cleanup for website change
Version 1.0.7 Added multiple BC playerKeys
Version 1.0.6 Added Movies
Version 1.0.5 Added metadata and selectable views
Version 1.0.2 Added Next Page
Version 1.0.1 initial release

