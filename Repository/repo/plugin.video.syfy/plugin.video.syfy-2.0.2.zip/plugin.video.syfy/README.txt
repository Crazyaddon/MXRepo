plugin.video.syfy
================

Kodi V2 Addon for Syfy
For Kodi Isengard and above releases

Version 2.0.2 release cleanup
Version 2.0.1 initial v2 release

