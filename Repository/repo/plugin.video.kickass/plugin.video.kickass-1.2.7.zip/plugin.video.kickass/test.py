# coding: utf-8
__author__ = 'Ruben'
data = '''

<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" dir="auto">

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta http-equiv="Content-Style-Type" content="text/css" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Come and download frozen absolutely for free. Fast downloads." />
    <meta name="robots" content="noindex" rel="usearch" />
    <title>Download frozen Torrents - Kickass Torrents</title>
    <link rel="stylesheet" type="text/css" href="//kastatic.com/all-261c451.css" charset="utf-8" />
    <link rel="shortcut icon" href="//kastatic.com/images/favicon.ico" />


    <link rel="apple-touch-icon" href="//kastatic.com/images/apple-touch-icon.png" />

    <!--[if IE 7]>
    <link href="//kastatic.com/css/ie7-261c451.css" rel="stylesheet" type="text/css"/>
    <![endif]-->

    <!--[if IE 8]>
    <link href="//kastatic.com/css/ie8.css" rel="stylesheet" type="text/css"/>
    <![endif]-->

    <!--[if lt IE 9]>
    <script src="//kastatic.com/js/html5.min-261c451.js" type="text/javascript"></script>
    <![endif]-->

    <!--[if gte IE 9]>
    <link href="//kastatic.com/css/ie9-261c451.css" rel="stylesheet" type="text/css"/>
    <![endif]-->
    <script type="text/javascript">
        + function (S, p, a, r, e, C, l, i, c, k) {
            S[r] = S[r] || [];
            S[e] || (S[e] = function () {
                S[r].push(Array.prototype.slice.call(arguments))
            });
            i = p.createElement(a);
            c = p.getElementsByTagName(a)[0];
            i.src = C;
            i.async = true;
            c.parentNode.insertBefore(i, c)
        }
        (window, document, 'script', '_scq', 'sc', '//a.kickass.to/sc-261c451.js');

        sc('setHost', 'a.kickass.to');
        sc('setAccount', '_b894d6cb1e370fb9ad89f8d6d99eeb33');
        var kat = {
            release_id: '261c451',
            detect_lang: 0,
            spare_click: 1,
            mobile: false
        };
    </script>
    <script src="//kastatic.com/js/all-261c451.js" type="text/javascript"></script>
    <link rel="alternate" type="application/rss+xml" title="Subscribe to RSS feed" href="http://kat.cr/usearch/frozen/?rss=1" />
    <meta name="verify-v1" content="YccN/iP28SifHNEFY6u92i0ou3tAegQAIk2OyOJLp1s=" />
    <meta name="y_key" content="f0b40c3f5fee758f" />
    <meta name="google-site-verification" content="C1rNEC4fJIvFoyyccMV2PbuqX3P-SFtlD2MNZ9D2uy0" />
    <link rel="search" type="application/opensearchdescription+xml" title="KickassTorrents Torrent Search" href="/opensearch.xml" />
    <meta property="fb:app_id" content="123694587642603" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <script type="text/javascript">
        var _scq = _scq || [];
    </script>
</head>

<body>
    <div id="wrapper">
        <div id="wrapperInner">
            <span data-sc-slot="_60318cd4e8d28f6fb76fe34e9bd9c498"></span>
            <span data-sc-slot="_39ecb76dd457e5ac33776fdf11500d56"></span>
            <div id="logindiv"></div>
            <header>
                <nav id="menu">
                    <a href="/" id="logo"></a>
                    <i id="showHideSearch" class="ka ka-zoom"></i>
                    <div id="torrentSearch">
                        <form action="/usearch/" method="get" id="searchform" accept-charset="utf-8" onsubmit="return doSearch(this.q.value);">
                            <input id="contentSearch" class="input-big" type="text" name="q" value="frozen" autocomplete="off" placeholder="Search query" />
                            <div id="searchTool"><a title="Advanced search" href="/advanced/?q=frozen" class="ajaxLink"><i class="ka ka-settings"></i></a>
                                <button title="search" type="submit" value="" onfocus="this.blur();" onclick="this.blur();"><i class="ka ka-search"></i></button>
                            </div>
                        </form>
                    </div>
                    <span data-sc-slot="_277923e5f9d753c5b0630c28e641790c"></span>
                    <ul id="navigation">

                        <li>
                            <a href="/browse/"> <i class="ka ka-torrent"></i><span class="menuItem">browse</span></a>
                            <ul class="dropdown dp-middle dropdown-msg upper">

                                <li class="topMsg"><a href="/new/"><i class="ka ka16 ka-torrent"></i>latest</a></li>
                                <li class="topMsg"><a href="/movies/"><i class="ka ka16 ka-movie lower"></i>Movies</a></li>
                                <li class="topMsg"><a href="/tv/"><i class="ka ka16 ka-movie lower"></i>TV</a></li>
                                <li class="topMsg"><a href="/music/"><i class="ka ka16 ka-music-note lower"></i>Music</a></li>
                                <li class="topMsg"><a href="/games/"><i class="ka ka16 ka-settings lower"></i>Games</a></li>
                                <li class="topMsg"><a href="/books/"><i class="ka ka16 ka-bookmark"></i>Books</a></li>
                                <li class="topMsg"><a href="/applications/"><i class="ka ka16 ka-settings lower"></i>Apps</a></li>
                                <li class="topMsg"><a href="/anime/"><i class="ka ka16 ka-movie lower"></i>Anime</a></li>
                                <li class="topMsg"><a href="/other/"><i class="ka ka16 ka-torrent"></i>Other</a></li>
                                <li class="topMsg"><a href="/xxx/"><i class="ka ka16 ka-delete"></i>XXX</a></li>
                            </ul>
                        </li>
                        </li>
                        <li>
                            <a data-nop href="/community/"> <i class="ka ka-community"></i><span class="menuItem">community</span></a>
                            <li><a data-nop href="/blog/"><i class="ka ka-rss lower"></i><span class="menuItem">Blog</span></a></li>
                            <li><a data-nop href="/faq/"><i class="ka ka-faq lower"></i><span class="menuItem">FAQ</span></a></li>
                        </li>

                        <li> <a data-nop href="/auth/login/" class="ajaxLink"><i class="ka ka-user"></i><span class="menuItem">Register / Sign In</span></a></li>
                    </ul>
                </nav>
            </header>

            <div class="pusher"></div>
            <div class="mainpart">


                <table width="100%" cellspacing="0" cellpadding="0" class="doublecelltable" id="mainSearchTable">
                    <tr>
                        <td width="100%">
                            <div class="spareBlock hzSpare">
                                <div class="legend">Advertising (<a href="/auth/login/register/" class="ajaxLink removeAdv" title="Login or register to remove advertising">remove</a>)</div>
                                <span data-sc-slot="_b77c3599a877a4e9d6097b83ec9f23bb" data-sc-params="{ 'searchQuery': 'frozen' }"></span>
                            </div>

                            <div class="tabs">
                                <ul class="tabNavigation">
                                    <li><a class="selectedTab" href="/search/frozen/"><span>Sponsored Links</span></a></li>
                                </ul>
                                <hr class="tabsSeparator" />
                            </div>
                            <span data-sc-slot="_c039297fb3d18cf107e21460970475f0"></span>
                            <br />
                            <br />

                            <h1><a itemprop="url" class="plain" href="/frozen-i2294629/">Frozen</a></h1>
                            <div class="torrentMediaInfo">
                                <a class="movieCover" href="/frozen-i2294629/"><img src="//yuq.me/movies/22/946/2294629.jpg" /></a>
                                <div class="dataList">
                                    <ul class="block overauto botmarg0">
                                        <li><strong>IMDb link:</strong> <a class="plain" href="http://www.imdb.com/title/tt2294629/">2294629</a></li>
                                        <li><strong>IMDb rating:</strong> 7.6 (372,962 votes) </li>
                                        <li><strong>RottenTomatoes:</strong> <span class="rottentomatoes positive" title="fresh!"></span>89% <span class="rottenaudience positive" title="audience like it!"></span>86% </li>
                                        <li><strong>Watch on <a data-nop target="_blank" href="https://www.solarmovie.ph">Solarmovie</a>:</strong> <a data-nop target="_blank" href="https://www.solarmovie.ph/watch-frozen-2013.html">Frozen</a></li>
                                        <li><strong>Genres:</strong> <a class="plain" href="/movies/genre/animation/"><span>Animation</span></a>, <a class="plain" href="/movies/genre/adventure/"><span>Adventure</span></a>, <a class="plain" href="/movies/genre/family/"><span>Family</span></a>, <a class="plain" href="/movies/genre/comedy/"><span>Comedy</span></a>, <a class="plain" href="/movies/genre/fantasy/"><span>Fantasy</span></a>, <a class="plain" href="/movies/genre/musical/"><span>Musical</span></a> </li>
                                    </ul>
                                    <ul>
                                        <li><a href="/bookmarks/add/movie/2294629/" class="ajaxLink kaButton smallButton normalText"><i class="ka ka-bookmark"></i> add <strong>Frozen</strong> to bookmarks</a></li>
                                        <li><strong>Release date:</strong> 27 November 2013</li>
                                        <li><strong>Writers:</strong> Jennifer Lee (screenplay), Hans Christian Andersen (inspired by the story &quot;The Snow Queen&quot; by), Chris Buck (story), Jennifer Lee (story), Shane Morris (story), Dean Wellins (additional story)</li>

                                    </ul>
                                    <div class="floatleft width100perc botmarg10px"><strong>Cast:</strong> <span><a href="/movies/actor/kristen-bell-a0068338/">Kristen Bell</a></span>, <span><a href="/movies/actor/idina-menzel-a0579953/">Idina Menzel</a></span>, <span><a href="/movies/actor/josh-gad-a1265802/">Josh Gad</a></span>, <span><a href="/movies/actor/jonathan-groff-a2676147/">Jonathan Groff</a></span> and others </div>
                                    <div class="floatleft width100perc botmarg10px">
                                        <strong>Summary:</strong>
                                        <div id="summary">
                                            <p class="accentbox botmarg10px">
                                                When a princess with the power to turn things into ice curses her home in infinite winter, her sister, Anna teams up with a mountain man, his playful reindeer, and a snowman to change the weather condition.
                                                <br />
                                            </p>
                                            <strong><small>Written by <span class="badgeInline"><span class="offline" title="offline"></span> <span class="aclColor_9"><a class="plain" href="/user/Thhaque/">Thhaque</a></span><span title="Reputation" class="repValue positive">397.95K</span></span></small></strong>




                                        </div>

                                    </div>
                                    <span data-sc-slot="_16b9d77edbc49edc5a7a757cde4dfe28" data-sc-params="{ 'movie_name': 'Frozen' }"></span>
                                    <div class="pages marg0 floatleft"> <strong class="botpad5px block">Available in versions:</strong> <a class="turnoverButton siteButton bigButton " href="/frozen-i2294629/#1080p">1080p</a><a class="turnoverButton siteButton bigButton " href="/frozen-i2294629/#720p">720p</a><a class="turnoverButton siteButton bigButton " href="/frozen-i2294629/#BDRip">BDRip</a><a class="turnoverButton siteButton bigButton " href="/frozen-i2294629/#HDRiP">HDRiP</a><a class="turnoverButton siteButton bigButton " href="/frozen-i2294629/#DVD">DVD</a><a class="turnoverButton siteButton bigButton " href="/frozen-i2294629/#DVDRip">DVDRip</a><a class="turnoverButton siteButton bigButton " href="/frozen-i2294629/#VCD">VCD</a><a class="turnoverButton siteButton bigButton " href="/frozen-i2294629/#Screener">Screener</a><a class="turnoverButton siteButton bigButton " href="/frozen-i2294629/#TeleSync">TeleSync</a><a class="turnoverButton siteButton bigButton " href="/frozen-i2294629/#Cam">Cam</a> </div>
                                </div>
                                <!-- div class="dataList" -->
                            </div>



                            <div class="tabs">
                                <ul class="tabNavigation">
                                    <li>
                                        <a class="darkButton selectedTab" href="/usearch/frozen/"><span>All</span></a>
                                    </li>
                                    <li>
                                        <a rel="nofollow" class="darkButton" href="/usearch/frozen category:movies/"><span>Movies <i class="menuValue">928</i></span></a>
                                    </li>
                                    <li>
                                        <a rel="nofollow" class="darkButton" href="/usearch/frozen category:tv/"><span>TV <i class="menuValue">193</i></span></a>
                                    </li>
                                    <li>
                                        <a rel="nofollow" class="darkButton" href="/usearch/frozen category:anime/"><span>Anime <i class="menuValue">162</i></span></a>
                                    </li>
                                    <li>
                                        <a rel="nofollow" class="darkButton" href="/usearch/frozen category:music/"><span>Music <i class="menuValue">205</i></span></a>
                                    </li>
                                    <li>
                                        <a rel="nofollow" class="darkButton" href="/usearch/frozen category:books/"><span>Books <i class="menuValue">83</i></span></a>
                                    </li>
                                    <li>
                                        <a rel="nofollow" class="darkButton" href="/usearch/frozen category:games/"><span>Games <i class="menuValue">179</i></span></a>
                                    </li>
                                    <li>
                                        <a rel="nofollow" class="darkButton" href="/usearch/frozen category:applications/"><span>Apps <i class="menuValue">55</i></span></a>
                                    </li>
                                    <li>
                                        <a rel="nofollow" class="darkButton" href="/usearch/frozen category:xxx/"><span>XXX <i class="menuValue">43</i></span></a>
                                    </li>
                                </ul>
                                <hr class="tabsSeparator" />
                            </div>

                            <div>
                                <h2>									frozen							<span>  results 1-25 from 1905</span>  <a data-nop class="ka ka16 ka-rss normalText rsssign ka-red" target="_blank" href="http://kat.cr/usearch/frozen/?rss=1" title="rss"></a></h2>


                                <table cellpadding="0" cellspacing="0" class="data" style="width: 100%">
                                    <tr class="firstr">
                                        <th class="width100perc nopad">torrent name</th>
                                        <th class="center"><a href="/usearch/frozen/?field=size&sorder=desc" rel="nofollow">size</a></th>
                                        <th class="center"><span class="files"><a href="/usearch/frozen/?field=files_count&sorder=desc" rel="nofollow">files</a></span></th>
                                        <th class="center"><span><a href="/usearch/frozen/?field=time_add&sorder=desc" rel="nofollow">age</a></span></th>
                                        <th class="center"><span class="seed"><a href="/usearch/frozen/?field=seeders&sorder=desc" rel="nofollow">seed</a></span></th>
                                        <th class="lasttd nobr center"><a href="/usearch/frozen/?field=leechers&sorder=desc" rel="nofollow">leech</a></th>
                                    </tr>
                                    <tr class="odd" id="torrent_frozen8817152">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="8817152,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-720p-brrip-x264-yify-t8817152.html#comment">834 <i class="ka ka-comment"></i></a> <a class="icon16" href="/frozen-2013-720p-brrip-x264-yify-t8817152.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20%282013%29%20720p%20BrRip%20x264%20-%20YIFY', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3A25B4CD46E389E96F80EE42E418CD89D3A65ECD66%26dn%3Dfrozen%2B2013%2B720p%2Bbrrip%2Bx264%2Byify%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:25B4CD46E389E96F80EE42E418CD89D3A65ECD66&dn=frozen+2013+720p+brrip+x264+yify&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/25B4CD46E389E96F80EE42E418CD89D3A65ECD66.torrent?title=[kat.cr]frozen.2013.720p.brrip.x264.yify" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/frozen-2013-720p-brrip-x264-yify-t8817152.html" class="torType filmType"></a>
                                                <a href="/frozen-2013-720p-brrip-x264-yify-t8817152.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType filmType">
                                                    <a href="/frozen-2013-720p-brrip-x264-yify-t8817152.html" class="cellMainLink"><strong class="red">Frozen</strong> (2013) 720p BrRip x264 - YIFY</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <i title="Elite Uploader" class="ka ka-star ka-vul2" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/YIFY/">YIFY</a> in <span id="cat_8817152"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">805.48 <span>MB</span></td>
                                        <td class="center">2</td>
                                        <td class="center" title="27 Feb 2014, 06:30">1&nbsp;year</td>
                                        <td class="green center">722</td>
                                        <td class="red lasttd center">57</td>
                                    </tr>
                                    <tr class="even" id="torrent_frozen11022236">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="11022236,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-fever-2015-bdrip-xvid-ac3-evo-t11022236.html#comment">120 <i class="ka ka-comment"></i></a> <a class="icon16" href="/frozen-fever-2015-bdrip-xvid-ac3-evo-t11022236.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20Fever%202015%20BDRip%20XviD%20AC3-EVO', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3AA2CBB29651C2BA34B38D1A2BDE1043A1E921591A%26dn%3Dfrozen%2Bfever%2B2015%2Bbdrip%2Bxvid%2Bac3%2Bevo%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:A2CBB29651C2BA34B38D1A2BDE1043A1E921591A&dn=frozen+fever+2015+bdrip+xvid+ac3+evo&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/A2CBB29651C2BA34B38D1A2BDE1043A1E921591A.torrent?title=[kat.cr]frozen.fever.2015.bdrip.xvid.ac3.evo" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/frozen-fever-2015-bdrip-xvid-ac3-evo-t11022236.html" class="torType filmType"></a>
                                                <a href="/frozen-fever-2015-bdrip-xvid-ac3-evo-t11022236.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType filmType">
                                                    <a href="/frozen-fever-2015-bdrip-xvid-ac3-evo-t11022236.html" class="cellMainLink"><strong class="red">Frozen</strong> Fever 2015 BDRip XviD AC3-EVO</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/Silmarillion/">Silmarillion</a> in <span id="cat_11022236"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">391.15 <span>MB</span></td>
                                        <td class="center">4</td>
                                        <td class="center" title="31 Jul 2015, 07:30">4&nbsp;months</td>
                                        <td class="green center">409</td>
                                        <td class="red lasttd center">88</td>
                                    </tr>
                                    <tr class="odd" id="torrent_frozen11022962">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="11022962,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-fever-2015-720p-bluray-x264-dts-evo-t11022962.html#comment">30 <i class="ka ka-comment"></i></a> <a class="icon16" href="/frozen-fever-2015-720p-bluray-x264-dts-evo-t11022962.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20Fever%202015%20720p%20Bluray%20X264%20DTS-EVO', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3A864D8EF095B4A8D7F9D90BD8846D6E51576D81BD%26dn%3Dfrozen%2Bfever%2B2015%2B720p%2Bbluray%2Bx264%2Bdts%2Bevo%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:864D8EF095B4A8D7F9D90BD8846D6E51576D81BD&dn=frozen+fever+2015+720p+bluray+x264+dts+evo&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/864D8EF095B4A8D7F9D90BD8846D6E51576D81BD.torrent?title=[kat.cr]frozen.fever.2015.720p.bluray.x264.dts.evo" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/frozen-fever-2015-720p-bluray-x264-dts-evo-t11022962.html" class="torType filmType"></a>
                                                <a href="/frozen-fever-2015-720p-bluray-x264-dts-evo-t11022962.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType filmType">
                                                    <a href="/frozen-fever-2015-720p-bluray-x264-dts-evo-t11022962.html" class="cellMainLink"><strong class="red">Frozen</strong> Fever 2015 720p Bluray X264 DTS-EVO</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/SS132203/">SS132203</a> in <span id="cat_11022962"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">792.66 <span>MB</span></td>
                                        <td class="center">3</td>
                                        <td class="center" title="31 Jul 2015, 10:57">4&nbsp;months</td>
                                        <td class="green center">184</td>
                                        <td class="red lasttd center">25</td>
                                    </tr>
                                    <tr class="even" id="torrent_frozen8821806">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="8821806,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-multi-1080p-bluray-x264-rough-t8821806.html#comment">1 <i class="ka ka-comment"></i></a> <a class="icon16" href="/frozen-2013-multi-1080p-bluray-x264-rough-t8821806.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%202013%20MULTi%201080p%20BluRay%20x264-ROUGH', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3AB53C3AA969C13DBC58FE9394EA3A553C08839238%26dn%3Dfrozen%2B2013%2Bmulti%2B1080p%2Bbluray%2Bx264%2Brough%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:B53C3AA969C13DBC58FE9394EA3A553C08839238&dn=frozen+2013+multi+1080p+bluray+x264+rough&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/B53C3AA969C13DBC58FE9394EA3A553C08839238.torrent?title=[kat.cr]frozen.2013.multi.1080p.bluray.x264.rough" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/frozen-2013-multi-1080p-bluray-x264-rough-t8821806.html" class="torType filmType"></a>
                                                <a href="/frozen-2013-multi-1080p-bluray-x264-rough-t8821806.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType filmType">
                                                    <a href="/frozen-2013-multi-1080p-bluray-x264-rough-t8821806.html" class="cellMainLink"><strong class="red">Frozen</strong> 2013 MULTi 1080p BluRay x264-ROUGH</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/Alex_Kid/">Alex_Kid</a> in <span id="cat_8821806"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">6.56 <span>GB</span></td>
                                        <td class="center">1</td>
                                        <td class="center" title="28 Feb 2014, 12:00">1&nbsp;year</td>
                                        <td class="green center">154</td>
                                        <td class="red lasttd center">20</td>
                                    </tr>
                                    <tr class="odd" id="torrent_frozen8819093">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="8819093,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-french-720p-bluray-x264-rough-t8819093.html#comment">16 <i class="ka ka-comment"></i></a> <a class="icon16" href="/frozen-2013-french-720p-bluray-x264-rough-t8819093.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%202013%20FRENCH%20720p%20BluRay%20x264-ROUGH', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3AFDBE9CABF1604205AF1556A2E4D3A336079EE0B1%26dn%3Dfrozen%2B2013%2Bfrench%2B720p%2Bbluray%2Bx264%2Brough%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:FDBE9CABF1604205AF1556A2E4D3A336079EE0B1&dn=frozen+2013+french+720p+bluray+x264+rough&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/FDBE9CABF1604205AF1556A2E4D3A336079EE0B1.torrent?title=[kat.cr]frozen.2013.french.720p.bluray.x264.rough" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/frozen-2013-french-720p-bluray-x264-rough-t8819093.html" class="torType filmType"></a>
                                                <a href="/frozen-2013-french-720p-bluray-x264-rough-t8819093.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType filmType">
                                                    <a href="/frozen-2013-french-720p-bluray-x264-rough-t8819093.html" class="cellMainLink"><strong class="red">Frozen</strong> 2013 FRENCH 720p BluRay x264-ROUGH</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/Alex_Kid/">Alex_Kid</a> in <span id="cat_8819093"><strong><a href="/movies/">Movies</a> > <a href="/dubbed-movies/">Dubbed Movies</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">3.28 <span>GB</span></td>
                                        <td class="center">2</td>
                                        <td class="center" title="27 Feb 2014, 18:00">1&nbsp;year</td>
                                        <td class="green center">157</td>
                                        <td class="red lasttd center">8</td>
                                    </tr>
                                    <tr class="even" id="torrent_frozen9319243">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="9319243,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-uma-aventura-congelante-2013-1080p-dublado-pt-br-t9319243.html#comment">9 <i class="ka ka-comment"></i></a> <a class="icon16" href="/frozen-uma-aventura-congelante-2013-1080p-dublado-pt-br-t9319243.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%3A%20Uma%20Aventura%20Congelante%20%282013%29%201080p%20Dublado%20pt-BR', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3A5B51FC9689D51E0B80402BA5285F2107909B4275%26dn%3Dfrozen%2Buma%2Baventura%2Bcongelante%2B2013%2B1080p%2Bdublado%2Bpt%2Bbr%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:5B51FC9689D51E0B80402BA5285F2107909B4275&dn=frozen+uma+aventura+congelante+2013+1080p+dublado+pt+br&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/5B51FC9689D51E0B80402BA5285F2107909B4275.torrent?title=[kat.cr]frozen.uma.aventura.congelante.2013.1080p.dublado.pt.br" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/frozen-uma-aventura-congelante-2013-1080p-dublado-pt-br-t9319243.html" class="torType filmType"></a>
                                                <a href="/frozen-uma-aventura-congelante-2013-1080p-dublado-pt-br-t9319243.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType filmType">
                                                    <a href="/frozen-uma-aventura-congelante-2013-1080p-dublado-pt-br-t9319243.html" class="cellMainLink"><strong class="red">Frozen</strong>: Uma Aventura Congelante (2013) 1080p Dublado pt-BR</a>

                                                    <span class="font11px lightgrey block">
                in <span id="cat_9319243"><strong><a href="/movies/">Movies</a> > <a href="/dubbed-movies/">Dubbed Movies</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">1.71 <span>GB</span></td>
                                        <td class="center">4</td>
                                        <td class="center" title="11 Jul 2014, 15:54">1&nbsp;year</td>
                                        <td class="green center">157</td>
                                        <td class="red lasttd center">6</td>
                                    </tr>
                                    <tr class="odd" id="torrent_frozen10248473">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a class="icon16" href="/frozen-2013-bdrip-xvid-eng-ita-ac3-subs-il-regno-di-ghiaccio-t10248473.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20%282013%29%20BDRip%20XviD%20ENG-ITA%20Ac3%20subs%20-%20Il%20Regno%20Di%20Ghiaccio', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3AE2167529F2A86ABD6F8F32C98B82450D88E38326%26dn%3Dfrozen%2B2013%2Bbdrip%2Bxvid%2Beng%2Bita%2Bac3%2Bsubs%2Bil%2Bregno%2Bdi%2Bghiaccio%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:E2167529F2A86ABD6F8F32C98B82450D88E38326&dn=frozen+2013+bdrip+xvid+eng+ita+ac3+subs+il+regno+di+ghiaccio&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/E2167529F2A86ABD6F8F32C98B82450D88E38326.torrent?title=[kat.cr]frozen.2013.bdrip.xvid.eng.ita.ac3.subs.il.regno.di.ghiaccio" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/frozen-2013-bdrip-xvid-eng-ita-ac3-subs-il-regno-di-ghiaccio-t10248473.html" class="torType filmType"></a>
                                                <a href="/frozen-2013-bdrip-xvid-eng-ita-ac3-subs-il-regno-di-ghiaccio-t10248473.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType filmType">
                                                    <a href="/frozen-2013-bdrip-xvid-eng-ita-ac3-subs-il-regno-di-ghiaccio-t10248473.html" class="cellMainLink"><strong class="red">Frozen</strong> (2013) BDRip XviD ENG-ITA Ac3 subs - Il Regno Di Ghiaccio</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/ShivaShanti/">ShivaShanti</a> in <span id="cat_10248473"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">1.75 <span>GB</span></td>
                                        <td class="center">3</td>
                                        <td class="center" title="20 Feb 2015, 12:14">9&nbsp;months</td>
                                        <td class="green center">145</td>
                                        <td class="red lasttd center">30</td>
                                    </tr>
                                    <tr class="even" id="torrent_frozen8893033">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="8893033,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-il-regno-di-ghiaccio-2013-italian-ac3-dual-1080p-brrip-x264-trtd-team-t8893033.html#comment">19 <i class="ka ka-comment"></i></a> <a class="icon16" href="/frozen-il-regno-di-ghiaccio-2013-italian-ac3-dual-1080p-brrip-x264-trtd-team-t8893033.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20Il%20Regno%20Di%20Ghiaccio%202013%20iTALiAN%20AC3%20DUAL%201080p%20BrRiP%20x264-TrTd_TeaM', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3AA794083F24D2E20C9E9C935B32CC880F1E2A064E%26dn%3Dfrozen%2Bil%2Bregno%2Bdi%2Bghiaccio%2B2013%2Bitalian%2Bac3%2Bdual%2B1080p%2Bbrrip%2Bx264%2Btrtd%2Bteam%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:A794083F24D2E20C9E9C935B32CC880F1E2A064E&dn=frozen+il+regno+di+ghiaccio+2013+italian+ac3+dual+1080p+brrip+x264+trtd+team&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/A794083F24D2E20C9E9C935B32CC880F1E2A064E.torrent?title=[kat.cr]frozen.il.regno.di.ghiaccio.2013.italian.ac3.dual.1080p.brrip.x264.trtd.team" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/frozen-il-regno-di-ghiaccio-2013-italian-ac3-dual-1080p-brrip-x264-trtd-team-t8893033.html" class="torType filmType"></a>
                                                <a href="/frozen-il-regno-di-ghiaccio-2013-italian-ac3-dual-1080p-brrip-x264-trtd-team-t8893033.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType filmType">
                                                    <a href="/frozen-il-regno-di-ghiaccio-2013-italian-ac3-dual-1080p-brrip-x264-trtd-team-t8893033.html" class="cellMainLink"><strong class="red">Frozen</strong> Il Regno Di Ghiaccio 2013 iTALiAN AC3 DUAL 1080p BrRiP x264-TrTd_TeaM</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/ignazio71/">ignazio71</a> in <span id="cat_8893033"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">2.48 <span>GB</span></td>
                                        <td class="center">5</td>
                                        <td class="center" title="18 Mar 2014, 17:32">1&nbsp;year</td>
                                        <td class="green center">121</td>
                                        <td class="red lasttd center">24</td>
                                    </tr>
                                    <tr class="odd" id="torrent_frozen11084298">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="11084298,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-fever-2015-bluray-720p-dts-x264-etrg-t11084298.html#comment">1 <i class="ka ka-comment"></i></a> <a class="icon16" href="/frozen-fever-2015-bluray-720p-dts-x264-etrg-t11084298.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20Fever%202015%20BluRay%20720p%20DTS%20x264-ETRG', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3A0B85DC86F425AB492D8B091227036B684F516A26%26dn%3Dfrozen%2Bfever%2B2015%2Bbluray%2B720p%2Bdts%2Bx264%2Betrg%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:0B85DC86F425AB492D8B091227036B684F516A26&dn=frozen+fever+2015+bluray+720p+dts+x264+etrg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/0B85DC86F425AB492D8B091227036B684F516A26.torrent?title=[kat.cr]frozen.fever.2015.bluray.720p.dts.x264.etrg" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/frozen-fever-2015-bluray-720p-dts-x264-etrg-t11084298.html" class="torType filmType"></a>
                                                <a href="/frozen-fever-2015-bluray-720p-dts-x264-etrg-t11084298.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType filmType">
                                                    <a href="/frozen-fever-2015-bluray-720p-dts-x264-etrg-t11084298.html" class="cellMainLink"><strong class="red">Frozen</strong> Fever 2015 BluRay 720p DTS x264-ETRG</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <i title="Elite Uploader" class="ka ka-star ka-vul2" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/MgB/">MgB</a> in <span id="cat_11084298"><strong><a href="/movies/">Movies</a> > <a href="/highres-movies/">Highres Movies</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">354.29 <span>MB</span></td>
                                        <td class="center">11</td>
                                        <td class="center" title="12 Aug 2015, 12:09">3&nbsp;months</td>
                                        <td class="green center">52</td>
                                        <td class="red lasttd center">120</td>
                                    </tr>
                                    <tr class="even" id="torrent_frozen11031930">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="11031930,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-fever-2015-1080p-bluray-x264-dts-en-5-1-nl-subs-evo-t11031930.html#comment">5 <i class="ka ka-comment"></i></a> <a class="icon16" href="/frozen-fever-2015-1080p-bluray-x264-dts-en-5-1-nl-subs-evo-t11031930.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20Fever%202015%201080p%20Bluray%20X264%20DTS%20en%205%201%20NL%20Subs-EVO', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3AEA114BD7462649DF42888D77FD2B8BA43FFC7B09%26dn%3Dfrozen%2Bfever%2B2015%2B1080p%2Bbluray%2Bx264%2Bdts%2Ben%2B5%2B1%2Bnl%2Bsubs%2Bevo%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:EA114BD7462649DF42888D77FD2B8BA43FFC7B09&dn=frozen+fever+2015+1080p+bluray+x264+dts+en+5+1+nl+subs+evo&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/EA114BD7462649DF42888D77FD2B8BA43FFC7B09.torrent?title=[kat.cr]frozen.fever.2015.1080p.bluray.x264.dts.en.5.1.nl.subs.evo" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/frozen-fever-2015-1080p-bluray-x264-dts-en-5-1-nl-subs-evo-t11031930.html" class="torType filmType"></a>
                                                <a href="/frozen-fever-2015-1080p-bluray-x264-dts-en-5-1-nl-subs-evo-t11031930.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType filmType">
                                                    <a href="/frozen-fever-2015-1080p-bluray-x264-dts-en-5-1-nl-subs-evo-t11031930.html" class="cellMainLink"><strong class="red">Frozen</strong> Fever 2015 1080p Bluray X264 DTS en 5 1 NL Subs-EVO</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/PitBuLL/">PitBuLL</a> in <span id="cat_11031930"><strong><a href="/movies/">Movies</a> > <a href="/highres-movies/">Highres Movies</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">1.17 <span>GB</span></td>
                                        <td class="center">1</td>
                                        <td class="center" title="02 Aug 2015, 09:04">4&nbsp;months</td>
                                        <td class="green center">84</td>
                                        <td class="red lasttd center">13</td>
                                    </tr>
                                    <tr class="odd" id="torrent_frozen8881471">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="8881471,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-3d-brrip-x264-yify-t8881471.html#comment">145 <i class="ka ka-comment"></i></a> <a class="icon16" href="/frozen-2013-3d-brrip-x264-yify-t8881471.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20%282013%29%203D%20BrRip%20x264%20-%20YIFY', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3A06C0D76D3B5AB230FCF2584FB381D529C6FABD2F%26dn%3Dfrozen%2B2013%2B3d%2Bbrrip%2Bx264%2Byify%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:06C0D76D3B5AB230FCF2584FB381D529C6FABD2F&dn=frozen+2013+3d+brrip+x264+yify&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/06C0D76D3B5AB230FCF2584FB381D529C6FABD2F.torrent?title=[kat.cr]frozen.2013.3d.brrip.x264.yify" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/frozen-2013-3d-brrip-x264-yify-t8881471.html" class="torType filmType"></a>
                                                <a href="/frozen-2013-3d-brrip-x264-yify-t8881471.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType filmType">
                                                    <a href="/frozen-2013-3d-brrip-x264-yify-t8881471.html" class="cellMainLink"><strong class="red">Frozen</strong> (2013) 3D BrRip x264 - YIFY</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <i title="Elite Uploader" class="ka ka-star ka-vul2" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/YIFY/">YIFY</a> in <span id="cat_8881471"><strong><a href="/movies/">Movies</a> > <a href="/3d-movies/">3D Movies</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">1.63 <span>GB</span></td>
                                        <td class="center">2</td>
                                        <td class="center" title="15 Mar 2014, 13:20">1&nbsp;year</td>
                                        <td class="green center">72</td>
                                        <td class="red lasttd center">7</td>
                                    </tr>
                                    <tr class="even" id="torrent_frozen11026819">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="11026819,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-fever-2015-720p-bluray-x264-aac-etrg-t11026819.html#comment">17 <i class="ka ka-comment"></i></a> <a class="icon16" href="/frozen-fever-2015-720p-bluray-x264-aac-etrg-t11026819.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20Fever%202015%20720p%20BluRay%20x264%20AAC-ETRG', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3A43A9F98724BD8C77596E81EB3028B44AA8F5FDDB%26dn%3Dfrozen%2Bfever%2B2015%2B720p%2Bbluray%2Bx264%2Baac%2Betrg%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:43A9F98724BD8C77596E81EB3028B44AA8F5FDDB&dn=frozen+fever+2015+720p+bluray+x264+aac+etrg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/43A9F98724BD8C77596E81EB3028B44AA8F5FDDB.torrent?title=[kat.cr]frozen.fever.2015.720p.bluray.x264.aac.etrg" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/frozen-fever-2015-720p-bluray-x264-aac-etrg-t11026819.html" class="torType filmType"></a>
                                                <a href="/frozen-fever-2015-720p-bluray-x264-aac-etrg-t11026819.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType filmType">
                                                    <a href="/frozen-fever-2015-720p-bluray-x264-aac-etrg-t11026819.html" class="cellMainLink"><strong class="red">Frozen</strong> Fever 2015 720p BluRay x264 AAC-ETRG</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <i title="Elite Uploader" class="ka ka-star ka-vul2" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/megaradon/">megaradon</a> in <span id="cat_11026819"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">62.41 <span>MB</span></td>
                                        <td class="center">2</td>
                                        <td class="center" title="01 Aug 2015, 06:08">4&nbsp;months</td>
                                        <td class="green center">65</td>
                                        <td class="red lasttd center">3</td>
                                    </tr>
                                    <tr class="odd" id="torrent_frozen8516976">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="8516976,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-720p-dvdscr-xvid-ac3-humpday-t8516976.html#comment">127 <i class="ka ka-comment"></i></a> <a class="icon16" href="/frozen-2013-720p-dvdscr-xvid-ac3-humpday-t8516976.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%202013%20720p%20DVDSCR%20XViD%20AC3-HuMPDaY', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3A8631A6C1FEE556246A798946A638D2661C634946%26dn%3Dfrozen%2B2013%2B720p%2Bdvdscr%2Bxvid%2Bac3%2Bhumpday%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:8631A6C1FEE556246A798946A638D2661C634946&dn=frozen+2013+720p+dvdscr+xvid+ac3+humpday&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/8631A6C1FEE556246A798946A638D2661C634946.torrent?title=[kat.cr]frozen.2013.720p.dvdscr.xvid.ac3.humpday" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/frozen-2013-720p-dvdscr-xvid-ac3-humpday-t8516976.html" class="torType filmType"></a>
                                                <a href="/frozen-2013-720p-dvdscr-xvid-ac3-humpday-t8516976.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType filmType">
                                                    <a href="/frozen-2013-720p-dvdscr-xvid-ac3-humpday-t8516976.html" class="cellMainLink"><strong class="red">Frozen</strong> 2013 720p DVDSCR XViD AC3-HuMPDaY</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/ChrisDen/">ChrisDen</a> in <span id="cat_8516976"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">2.36 <span>GB</span></td>
                                        <td class="center">1</td>
                                        <td class="center" title="07 Jan 2014, 21:00">1&nbsp;year</td>
                                        <td class="green center">59</td>
                                        <td class="red lasttd center">4</td>
                                    </tr>
                                    <tr class="even" id="torrent_frozen8903675">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="8903675,0" class="icommentjs kaButton smallButton rightButton" href="/disney-s-frozen-2013-eng-nl-audio-eng-nl-sub-br2dvd-nlu002-t8903675.html#comment">8 <i class="ka ka-comment"></i></a> <a class="icon16" href="/disney-s-frozen-2013-eng-nl-audio-eng-nl-sub-br2dvd-nlu002-t8903675.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Disney%27s%20Frozen%20%282013%29%20Eng%20NL%20Audio%20Eng%20NL%20Sub%20BR2DVD-NLU002', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3A17EA7E292B54A62069594D061D58C8D83CA9B83E%26dn%3Ddisney%2Bs%2Bfrozen%2B2013%2Beng%2Bnl%2Baudio%2Beng%2Bnl%2Bsub%2Bbr2dvd%2Bnlu002%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:17EA7E292B54A62069594D061D58C8D83CA9B83E&dn=disney+s+frozen+2013+eng+nl+audio+eng+nl+sub+br2dvd+nlu002&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/17EA7E292B54A62069594D061D58C8D83CA9B83E.torrent?title=[kat.cr]disney.s.frozen.2013.eng.nl.audio.eng.nl.sub.br2dvd.nlu002" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/disney-s-frozen-2013-eng-nl-audio-eng-nl-sub-br2dvd-nlu002-t8903675.html" class="torType filmType"></a>
                                                <a href="/disney-s-frozen-2013-eng-nl-audio-eng-nl-sub-br2dvd-nlu002-t8903675.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType filmType">
                                                    <a href="/disney-s-frozen-2013-eng-nl-audio-eng-nl-sub-br2dvd-nlu002-t8903675.html" class="cellMainLink">Disney's <strong class="red">Frozen</strong> (2013) Eng NL Audio Eng NL Sub BR2DVD-NLU002</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <a class="plain" href="/user/NLUPPER002/">NLUPPER002</a> in <span id="cat_8903675"><strong><a href="/movies/">Movies</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">4.36 <span>GB</span></td>
                                        <td class="center">16</td>
                                        <td class="center" title="21 Mar 2014, 12:44">1&nbsp;year</td>
                                        <td class="green center">47</td>
                                        <td class="red lasttd center">5</td>
                                    </tr>
                                    <tr class="odd" id="torrent_frozen11026844">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="11026844,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-fever-2015-1080p-bluray-x264-aac-etrg-t11026844.html#comment">15 <i class="ka ka-comment"></i></a> <a class="icon16" href="/frozen-fever-2015-1080p-bluray-x264-aac-etrg-t11026844.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20Fever%202015%201080p%20BluRay%20x264%20AAC-ETRG', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3A47A506E8885C128E2706B72D07AD9C8674330AE9%26dn%3Dfrozen%2Bfever%2B2015%2B1080p%2Bbluray%2Bx264%2Baac%2Betrg%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:47A506E8885C128E2706B72D07AD9C8674330AE9&dn=frozen+fever+2015+1080p+bluray+x264+aac+etrg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/47A506E8885C128E2706B72D07AD9C8674330AE9.torrent?title=[kat.cr]frozen.fever.2015.1080p.bluray.x264.aac.etrg" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/frozen-fever-2015-1080p-bluray-x264-aac-etrg-t11026844.html" class="torType filmType"></a>
                                                <a href="/frozen-fever-2015-1080p-bluray-x264-aac-etrg-t11026844.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType filmType">
                                                    <a href="/frozen-fever-2015-1080p-bluray-x264-aac-etrg-t11026844.html" class="cellMainLink"><strong class="red">Frozen</strong> Fever 2015 1080p BluRay x264 AAC-ETRG</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <i title="Elite Uploader" class="ka ka-star ka-vul2" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/megaradon/">megaradon</a> in <span id="cat_11026844"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">119.29 <span>MB</span></td>
                                        <td class="center">2</td>
                                        <td class="center" title="01 Aug 2015, 06:20">4&nbsp;months</td>
                                        <td class="green center">47</td>
                                        <td class="red lasttd center">3</td>
                                    </tr>
                                    <tr class="even" id="torrent_frozen10726648">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="10726648,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-720p-brrip-900mb-mkvcage-t10726648.html#comment">2 <i class="ka ka-comment"></i></a> <a class="icon16" href="/frozen-2013-720p-brrip-900mb-mkvcage-t10726648.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20%282013%29%20720p%20BRRip%20900MB%20-%20MkvCage', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3A9D51B42EB769D409F26269BA01CE58E0DD14A7BC%26dn%3Dfrozen%2B2013%2B720p%2Bbrrip%2B900mb%2Bmkvcage%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:9D51B42EB769D409F26269BA01CE58E0DD14A7BC&dn=frozen+2013+720p+brrip+900mb+mkvcage&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/9D51B42EB769D409F26269BA01CE58E0DD14A7BC.torrent?title=[kat.cr]frozen.2013.720p.brrip.900mb.mkvcage" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/frozen-2013-720p-brrip-900mb-mkvcage-t10726648.html" class="torType filmType"></a>
                                                <a href="/frozen-2013-720p-brrip-900mb-mkvcage-t10726648.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType filmType">
                                                    <a href="/frozen-2013-720p-brrip-900mb-mkvcage-t10726648.html" class="cellMainLink"><strong class="red">Frozen</strong> (2013) 720p BRRip 900MB - MkvCage</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/MkvCage/">MkvCage</a> in <span id="cat_10726648"><strong><a href="/movies/">Movies</a> > <a href="/highres-movies/">Highres Movies</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">899.49 <span>MB</span></td>
                                        <td class="center">1</td>
                                        <td class="center" title="31 May 2015, 19:59">6&nbsp;months</td>
                                        <td class="green center">42</td>
                                        <td class="red lasttd center">9</td>
                                    </tr>
                                    <tr class="odd" id="torrent_frozen8792999">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="8792999,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-an-original-walt-disney-records-soundtrack-t8792999.html#comment">35 <i class="ka ka-comment"></i></a> <a class="icon16" href="/frozen-an-original-walt-disney-records-soundtrack-t8792999.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20-%20An%20Original%20Walt%20Disney%20Records%20Soundtrack', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3AE46A9E7708AD062DBE509249F4824C8138097495%26dn%3Dfrozen%2Ban%2Boriginal%2Bwalt%2Bdisney%2Brecords%2Bsoundtrack%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:E46A9E7708AD062DBE509249F4824C8138097495&dn=frozen+an+original+walt+disney+records+soundtrack&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/E46A9E7708AD062DBE509249F4824C8138097495.torrent?title=[kat.cr]frozen.an.original.walt.disney.records.soundtrack" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/frozen-an-original-walt-disney-records-soundtrack-t8792999.html" class="torType musicType"></a>
                                                <a href="/frozen-an-original-walt-disney-records-soundtrack-t8792999.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType musicType">
                                                    <a href="/frozen-an-original-walt-disney-records-soundtrack-t8792999.html" class="cellMainLink"><strong class="red">Frozen</strong> - An Original Walt Disney Records Soundtrack</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/catparrot/">catparrot</a> in <span id="cat_8792999"><strong><a href="/music/">Music</a> > <a href="/soundtrack/">Soundtrack</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">602.7 <span>MB</span></td>
                                        <td class="center">61</td>
                                        <td class="center" title="20 Feb 2014, 14:33">1&nbsp;year</td>
                                        <td class="green center">32</td>
                                        <td class="red lasttd center">19</td>
                                    </tr>
                                    <tr class="even" id="torrent_frozen8813192">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="8813192,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-english-movies-dvdrip-xvid-multi-subs-with-sample-rdx-t8813192.html#comment">20 <i class="ka ka-comment"></i></a> <a class="icon16" href="/frozen-2013-english-movies-dvdrip-xvid-multi-subs-with-sample-rdx-t8813192.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%202013%20English%20Movies%20DVDRip%20XViD%20Multi%20Subs%20with%20Sample%20~%20%E2%98%BBrDX%E2%98%BB', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3A2608B0232D5AD9E70447F724AE9111CEDC8E3405%26dn%3Dfrozen%2B2013%2Benglish%2Bmovies%2Bdvdrip%2Bxvid%2Bmulti%2Bsubs%2Bwith%2Bsample%2Brdx%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:2608B0232D5AD9E70447F724AE9111CEDC8E3405&dn=frozen+2013+english+movies+dvdrip+xvid+multi+subs+with+sample+rdx&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/2608B0232D5AD9E70447F724AE9111CEDC8E3405.torrent?title=[kat.cr]frozen.2013.english.movies.dvdrip.xvid.multi.subs.with.sample.rdx" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/frozen-2013-english-movies-dvdrip-xvid-multi-subs-with-sample-rdx-t8813192.html" class="torType filmType"></a>
                                                <a href="/frozen-2013-english-movies-dvdrip-xvid-multi-subs-with-sample-rdx-t8813192.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType filmType">
                                                    <a href="/frozen-2013-english-movies-dvdrip-xvid-multi-subs-with-sample-rdx-t8813192.html" class="cellMainLink"><strong class="red">Frozen</strong> 2013 English Movies DVDRip XViD Multi Subs with Sample ~ ☻rDX☻</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <i title="Elite Uploader" class="ka ka-star ka-vul2" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/teamrdx/">teamrdx</a> in <span id="cat_8813192"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">704.82 <span>MB</span></td>
                                        <td class="center">5</td>
                                        <td class="center" title="26 Feb 2014, 04:34">1&nbsp;year</td>
                                        <td class="green center">38</td>
                                        <td class="red lasttd center">5</td>
                                    </tr>
                                    <tr class="odd" id="torrent_frozen8351831">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="8351831,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-ts-x264-ac3-millenium-t8351831.html#comment">662 <i class="ka ka-comment"></i></a> <a class="icon16" href="/frozen-2013-ts-x264-ac3-millenium-t8351831.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%202013%20TS%20x264%20AC3-MiLLENiUM', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3AF165B9F028B092B2F44E128EB570DB994B0FB6AA%26dn%3Dfrozen%2B2013%2Bts%2Bx264%2Bac3%2Bmillenium%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:F165B9F028B092B2F44E128EB570DB994B0FB6AA&dn=frozen+2013+ts+x264+ac3+millenium&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/F165B9F028B092B2F44E128EB570DB994B0FB6AA.torrent?title=[kat.cr]frozen.2013.ts.x264.ac3.millenium" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/frozen-2013-ts-x264-ac3-millenium-t8351831.html" class="torType filmType"></a>
                                                <a href="/frozen-2013-ts-x264-ac3-millenium-t8351831.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType filmType">
                                                    <a href="/frozen-2013-ts-x264-ac3-millenium-t8351831.html" class="cellMainLink"><strong class="red">Frozen</strong> 2013 TS x264 AC3-MiLLENiUM</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <a class="plain" href="/user/Acesn8s/">Acesn8s</a> in <span id="cat_8351831"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">873.14 <span>MB</span></td>
                                        <td class="center">5</td>
                                        <td class="center" title="12 Dec 2013, 04:14">1&nbsp;year</td>
                                        <td class="green center">33</td>
                                        <td class="red lasttd center">9</td>
                                    </tr>
                                    <tr class="even" id="torrent_frozen8517377">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="8517377,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-dvdscr-xvid-sam-etrg-t8517377.html#comment">188 <i class="ka ka-comment"></i></a> <a class="icon16" href="/frozen-2013-dvdscr-xvid-sam-etrg-t8517377.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20%5B2013%5D%20DVDScr%20XviD-SaM%5BETRG%5D', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3A6B03287DA83A543190D1ECFA947632351F5F0B33%26dn%3Dfrozen%2B2013%2Bdvdscr%2Bxvid%2Bsam%2Betrg%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:6B03287DA83A543190D1ECFA947632351F5F0B33&dn=frozen+2013+dvdscr+xvid+sam+etrg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/6B03287DA83A543190D1ECFA947632351F5F0B33.torrent?title=[kat.cr]frozen.2013.dvdscr.xvid.sam.etrg" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/frozen-2013-dvdscr-xvid-sam-etrg-t8517377.html" class="torType filmType"></a>
                                                <a href="/frozen-2013-dvdscr-xvid-sam-etrg-t8517377.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType filmType">
                                                    <a href="/frozen-2013-dvdscr-xvid-sam-etrg-t8517377.html" class="cellMainLink"><strong class="red">Frozen</strong> [2013] DVDScr XviD-SaM[ETRG]</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/SaM/">SaM</a> in <span id="cat_8517377"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">708.3 <span>MB</span></td>
                                        <td class="center">5</td>
                                        <td class="center" title="07 Jan 2014, 23:28">1&nbsp;year</td>
                                        <td class="green center">32</td>
                                        <td class="red lasttd center">11</td>
                                    </tr>
                                    <tr class="odd" id="torrent_frozen10734807">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="10734807,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-el-reino-del-hielo-spanish-espaÑol-hdrip-elitetorrent-t10734807.html#comment">3 <i class="ka ka-comment"></i></a> <a class="icon16" href="/frozen-el-reino-del-hielo-spanish-espaÑol-hdrip-elitetorrent-t10734807.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20El%20reino%20del%20hielo%20SPANISH%20ESPA%C3%91OL%20HDRip%20ELITETORRENT', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3A12AA6990023EE2D3B0C8A5243C75D66C7E99EAC6%26dn%3Dfrozen%2Bel%2Breino%2Bdel%2Bhielo%2Bspanish%2Bespa%25C3%2591ol%2Bhdrip%2Belitetorrent%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:12AA6990023EE2D3B0C8A5243C75D66C7E99EAC6&dn=frozen+el+reino+del+hielo+spanish+espa%C3%91ol+hdrip+elitetorrent&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/12AA6990023EE2D3B0C8A5243C75D66C7E99EAC6.torrent?title=[kat.cr]frozen.el.reino.del.hielo.spanish.espa%C3%91ol.hdrip.elitetorrent" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/frozen-el-reino-del-hielo-spanish-espaÑol-hdrip-elitetorrent-t10734807.html" class="torType filmType"></a>
                                                <a href="/frozen-el-reino-del-hielo-spanish-espaÑol-hdrip-elitetorrent-t10734807.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType filmType">
                                                    <a href="/frozen-el-reino-del-hielo-spanish-espaÑol-hdrip-elitetorrent-t10734807.html" class="cellMainLink"><strong class="red">Frozen</strong> El reino del hielo SPANISH ESPAÑOL HDRip ELITETORRENT</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/hkcrew/">hkcrew</a> in <span id="cat_10734807"><strong><a href="/movies/">Movies</a> > <a href="/dubbed-movies/">Dubbed Movies</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">1.92 <span>GB</span></td>
                                        <td class="center">1</td>
                                        <td class="center" title="02 Jun 2015, 04:40">6&nbsp;months</td>
                                        <td class="green center">34</td>
                                        <td class="red lasttd center">4</td>
                                    </tr>
                                    <tr class="even" id="torrent_frozen9020905">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="9020905,0" class="icommentjs kaButton smallButton rightButton" href="/idina-menzel-let-it-go-from-frozen-armin-van-buuren-remix-t9020905.html#comment">2 <i class="ka ka-comment"></i></a> <a class="icon16" href="/idina-menzel-let-it-go-from-frozen-armin-van-buuren-remix-t9020905.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Idina%20Menzel%20%E2%80%93%20Let%20It%20Go%20%28From%20Frozen%29%20%5BArmin%20van%20Buuren%20Remix%5D', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3A32D7BFD939DC455DCFD64C76ECF89E375788235C%26dn%3Didina%2Bmenzel%2Blet%2Bit%2Bgo%2Bfrom%2Bfrozen%2Barmin%2Bvan%2Bbuuren%2Bremix%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:32D7BFD939DC455DCFD64C76ECF89E375788235C&dn=idina+menzel+let+it+go+from+frozen+armin+van+buuren+remix&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/32D7BFD939DC455DCFD64C76ECF89E375788235C.torrent?title=[kat.cr]idina.menzel.let.it.go.from.frozen.armin.van.buuren.remix" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/idina-menzel-let-it-go-from-frozen-armin-van-buuren-remix-t9020905.html" class="torType musicType"></a>
                                                <a href="/idina-menzel-let-it-go-from-frozen-armin-van-buuren-remix-t9020905.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType musicType">
                                                    <a href="/idina-menzel-let-it-go-from-frozen-armin-van-buuren-remix-t9020905.html" class="cellMainLink">Idina Menzel – Let It Go (From <strong class="red">Frozen</strong>) [Armin van Buuren Remix]</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/pamabego/">pamabego</a> in <span id="cat_9020905"><strong><a href="/music/">Music</a> > <a href="/mp3/">Mp3</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">14.51 <span>MB</span></td>
                                        <td class="center">1</td>
                                        <td class="center" title="21 Apr 2014, 16:31">1&nbsp;year</td>
                                        <td class="green center">23</td>
                                        <td class="red lasttd center">22</td>
                                    </tr>
                                    <tr class="odd" id="torrent_frozen10064281">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="10064281,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-bdrip-1080p-eng-ita-x265-bluray-il-regno-di-ghiaccio-t10064281.html#comment">3 <i class="ka ka-comment"></i></a> <a class="icon16" href="/frozen-2013-bdrip-1080p-eng-ita-x265-bluray-il-regno-di-ghiaccio-t10064281.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20%282013%29%20BDRip%201080p%20ENG-ITA%20x265%20BluRay%20-%20Il%20Regno%20Di%20Ghiaccio', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3AAEE029C8D3D0A76D8384376E6C126C2EFE885BBC%26dn%3Dfrozen%2B2013%2Bbdrip%2B1080p%2Beng%2Bita%2Bx265%2Bbluray%2Bil%2Bregno%2Bdi%2Bghiaccio%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:AEE029C8D3D0A76D8384376E6C126C2EFE885BBC&dn=frozen+2013+bdrip+1080p+eng+ita+x265+bluray+il+regno+di+ghiaccio&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/AEE029C8D3D0A76D8384376E6C126C2EFE885BBC.torrent?title=[kat.cr]frozen.2013.bdrip.1080p.eng.ita.x265.bluray.il.regno.di.ghiaccio" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/frozen-2013-bdrip-1080p-eng-ita-x265-bluray-il-regno-di-ghiaccio-t10064281.html" class="torType filmType"></a>
                                                <a href="/frozen-2013-bdrip-1080p-eng-ita-x265-bluray-il-regno-di-ghiaccio-t10064281.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType filmType">
                                                    <a href="/frozen-2013-bdrip-1080p-eng-ita-x265-bluray-il-regno-di-ghiaccio-t10064281.html" class="cellMainLink"><strong class="red">Frozen</strong> (2013) BDRip 1080p ENG-ITA x265 BluRay - Il Regno Di Ghiaccio</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <i title="Verified Uploader" class="ka ka-verify" style="font-size: 16px;color:orange;"></i> <a class="plain" href="/user/ShivaShanti/">ShivaShanti</a> in <span id="cat_10064281"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">4.08 <span>GB</span></td>
                                        <td class="center">1</td>
                                        <td class="center" title="11 Jan 2015, 11:41">10&nbsp;months</td>
                                        <td class="green center">31</td>
                                        <td class="red lasttd center">4</td>
                                    </tr>
                                    <tr class="even" id="torrent_frozen8525060">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="8525060,0" class="icommentjs kaButton smallButton rightButton" href="/frozen-2013-dvdscr-nl-subs-dutchreleaseteam-t8525060.html#comment">20 <i class="ka ka-comment"></i></a> <a class="icon16" href="/frozen-2013-dvdscr-nl-subs-dutchreleaseteam-t8525060.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'Frozen%20%282013%29%20DVDScr%20NL%20subs%20DutchReleaseTeam', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3A43D1B1B91D8BC4911EF62440E1E813265BC2AEE2%26dn%3Dfrozen%2B2013%2Bdvdscr%2Bnl%2Bsubs%2Bdutchreleaseteam%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:43D1B1B91D8BC4911EF62440E1E813265BC2AEE2&dn=frozen+2013+dvdscr+nl+subs+dutchreleaseteam&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/43D1B1B91D8BC4911EF62440E1E813265BC2AEE2.torrent?title=[kat.cr]frozen.2013.dvdscr.nl.subs.dutchreleaseteam" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/frozen-2013-dvdscr-nl-subs-dutchreleaseteam-t8525060.html" class="torType filmType"></a>
                                                <a href="/frozen-2013-dvdscr-nl-subs-dutchreleaseteam-t8525060.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType filmType">
                                                    <a href="/frozen-2013-dvdscr-nl-subs-dutchreleaseteam-t8525060.html" class="cellMainLink"><strong class="red">Frozen</strong> (2013) DVDScr NL subs DutchReleaseTeam</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <a class="plain" href="/user/Koedje/">Koedje</a> in <span id="cat_8525060"><strong><a href="/movies/">Movies</a> > <a href="/animation/">Animation</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">887.4 <span>MB</span></td>
                                        <td class="center">9</td>
                                        <td class="center" title="08 Jan 2014, 22:10">1&nbsp;year</td>
                                        <td class="green center">27</td>
                                        <td class="red lasttd center">5</td>
                                    </tr>
                                    <tr class="odd" id="torrent_frozen8320897">
                                        <td>
                                            <div class="iaconbox center floatright">
                                                <a rel="8320897,0" class="icommentjs kaButton smallButton rightButton" href="/va-frozen-soundtrack-2013-mp3-c4-gtrg-t8320897.html#comment">22 <i class="ka ka-comment"></i></a> <a class="icon16" href="/va-frozen-soundtrack-2013-mp3-c4-gtrg-t8320897.html" title="Verified Torrent"><i class="ka ka16 ka-verify ka-green"></i></a> <span data-sc-replace data-sc-slot="_ae58c272c09a10c792c6b17d55c20208" class="none" data-sc-params="{ 'name': 'VA%20-%20Frozen%20%5BSoundtrack%5D%20-%202013%20%28MP3%29%20-%20C4%20%7BGTRG%7D', 'magnet': 'magnet%3A%3Fxt%3Durn%3Abtih%3AA6892632EA49265007B47747B5833568B66F07FB%26dn%3Dva%2Bfrozen%2Bsoundtrack%2B2013%2Bmp3%2Bc4%2Bgtrg%26tr%3Dudp%253A%252F%252Ftracker.publicbt.com%252Fannounce%26tr%3Dudp%253A%252F%252Fglotorrents.pw%253A6969%252Fannounce' }"></span>
                                                <a data-nop title="Torrent magnet link" href="magnet:?xt=urn:btih:A6892632EA49265007B47747B5833568B66F07FB&dn=va+frozen+soundtrack+2013+mp3+c4+gtrg&tr=udp%3A%2F%2Ftracker.publicbt.com%2Fannounce&tr=udp%3A%2F%2Fglotorrents.pw%3A6969%2Fannounce" class="icon16"><i class="ka ka16 ka-magnet"></i></a>
                                                <a data-download title="Download torrent file" href="//torcache.net/torrent/A6892632EA49265007B47747B5833568B66F07FB.torrent?title=[kat.cr]va.frozen.soundtrack.2013.mp3.c4.gtrg" class="icon16"><i class="ka ka16 ka-arrow-down"></i></a>
                                            </div>
                                            <div class="torrentname">
                                                <a href="/va-frozen-soundtrack-2013-mp3-c4-gtrg-t8320897.html" class="torType musicType"></a>
                                                <a href="/va-frozen-soundtrack-2013-mp3-c4-gtrg-t8320897.html" class="normalgrey font12px plain bold"></a>
                                                <div class="markeredBlock torType musicType">
                                                    <a href="/va-frozen-soundtrack-2013-mp3-c4-gtrg-t8320897.html" class="cellMainLink">VA - <strong class="red">Frozen</strong> [Soundtrack] - 2013 (MP3) - C4 {GTRG}</a>

                                                    <span class="font11px lightgrey block">
                                Posted by <a class="plain" href="/user/Kashi2052/">Kashi2052</a> in <span id="cat_8320897"><strong><a href="/music/">Music</a> > <a href="/soundtrack/">Soundtrack</a></strong></span> </span>
                                                </div>
                                        </td>
                                        <td class="nobr center">115.61 <span>MB</span></td>
                                        <td class="center">39</td>
                                        <td class="center" title="07 Dec 2013, 09:18">1&nbsp;year</td>
                                        <td class="green center">27</td>
                                        <td class="red lasttd center">4</td>
                                    </tr>
                                </table>
                                <div class="pages botmarg5px floatright" baseurl="/usearch/frozen/">
                                    <a class="turnoverButton siteButton bigButton kaTurnoverButton pagespecify_js" title="Go to a specific page"><i class="ka ka-zoom"></i></a><a class="turnoverButton siteButton bigButton active">1</a><a rel="nofollow" href="/usearch/frozen/2/" class="turnoverButton siteButton bigButton">2</a><a rel="nofollow" href="/usearch/frozen/3/" class="turnoverButton siteButton bigButton">3</a><a rel="nofollow" href="/usearch/frozen/4/" class="turnoverButton siteButton bigButton">4</a><a rel="nofollow" href="/usearch/frozen/5/" class="turnoverButton siteButton bigButton">5</a>
                                    <a class="turnoverButton siteButton blank nohov"></a><a rel="nofollow" href="/usearch/frozen/77/" class="turnoverButton siteButton bigButton">77</a>
                                    <script type="text/javascript">
                                        $(function () {
                                            if ($('.pages .nohov').length == 0)
                                                $('.pages .kaTurnoverButton').hide();
                                        });
                                        $('.pagespecify_js').unbind('click').on('click', function () {
                                            var pageNum = prompt('Enter page number');
                                            if (!isNaN(pageNum) && parseInt(pageNum) > 0) {
                                                var url = $(this).parent().attr('baseurl');
                                                var last = $(this).parent().find('a[href]').last();
                                                var paramStyle = /\/\?page=/.test(last.attr('href')) ? 2 : (/\/\?.*\&page=/.test(last.attr('href')) ? 1 : 0);
                                                var url_to = paramStyle == 0 || paramStyle == 2 ? (url.substring(0, url.lastIndexOf('/')) + '/' + (paramStyle == 2 ? '?page=' + pageNum + url.substring(url.lastIndexOf('/') + 1).replace(/^\?([^\=]+=)/, '&$1') : pageNum + url.substring(url.lastIndexOf('/')))) : url + '&page=' + pageNum;
                                                console.log(url_to);
                                                if (last.is('.ajaxLink')) { // if last button is .ajaxLink then it implies it's being fancyboxed, or at least the destination page(s) should be fancyboxed.
                                                    $('<a href="' + url_to + '"' + (last.is('[rel="nofollow"]') ? ' rel="nofollow"' : '') + '></a>').fancybox().click();
                                                } else {
                                                    location.href = url_to;
                                                }
                                            }
                                        });
                                    </script>
                                </div>
                                </div>
                                <div class="lightgrey">
                                    Search for "frozen" on <a href="http://torrentz.eu/search?f=frozen">Torrentz.eu</a>
                                </div>
                        </td>
                        <td class="sidebarCell">

                            <div id="sidebar">


                                <span data-sc-slot="_119b0a17fab5493361a252d04bf527db"></span>


                                <div class="spareBlock">
                                    <div class="legend">Advertising (<a href="/auth/login/register/" class="ajaxLink removeAdv" title="Login or register to remove advertising">remove</a>)</div>
                                    <span data-sc-slot="_7063408f1c01d50e0dc2d833186ce962" data-sc-params="{ 'searchQuery': 'frozen' }"></span>
                                </div>


                                <div class="sliderbox">
                                    <h3><a href="/community/">Latest Forum Threads</a><i id="hideLatestThreads" class="sliderBoxToggle ka ka16 ka-arrow2-up foldClose"></i></h3>
                                    <ul id="latestForum" rel="latestForum" class="showBlockJS">
                                        <li>
                                            <a href="/community/show/please-request-ebooks-and-audio-books-here-v12/?unread=17162197">
                                                <i class="ka ka16 ka-community latest-icon"></i>
                                                <p class="latest-title">
                                                    Please request ebooks and audio books here. V12
                                                </p>
                                            </a>
                                            <span class="explanation">by <span class="badgeInline"><span class="online" title="online"></span> <span class="aclColor_1"><a class="plain" href="/user/bcsaturdai/">bcsaturdai</a></span></span>
                                            <time class="timeago" datetime="2015-12-01T15:16:17+00:00">01 Dec 2015, 15:16</time>
                                            </span>
                                        </li>
                                        <li>
                                            <a href="/community/show/ask-experienced-encoder-here/?unread=17162196">
                                                <i class="ka ka16 ka-community latest-icon"></i>
                                                <p class="latest-title">
                                                    Ask an Experienced Encoder Here
                                                </p>
                                            </a>
                                            <span class="explanation">by <span class="badgeInline"><span class="online" title="online"></span> <span class="aclColor_1"><a class="plain" href="/user/Arggonawght/">Arggonawght</a></span></span>
                                            <time class="timeago" datetime="2015-12-01T15:15:57+00:00">01 Dec 2015, 15:15</time>
                                            </span>
                                        </li>
                                        <li>
                                            <a href="/community/show/rap-discography-s-320-kbps-quality/?unread=17162187">
                                                <i class="ka ka16 ka-community latest-icon"></i>
                                                <p class="latest-title">
                                                    RAP Discography`s in 320 kbps quality
                                                </p>
                                            </a>
                                            <span class="explanation">by <span class="badgeInline"><span class="offline" title="offline"></span> <span class="aclColor_eliteuploader"><a class="plain" href="/user/dragan09/">dragan09</a></span></span>
                                            <time class="timeago" datetime="2015-12-01T15:13:51+00:00">01 Dec 2015, 15:13</time>
                                            </span>
                                        </li>
                                        <li>
                                            <a href="/community/show/adopt-uploader-program-v12-all-users-help-thread-115043/?unread=17162181">
                                                <i class="ka ka16 ka-community latest-icon"></i>
                                                <p class="latest-title">
                                                    **Adopt an uploader Program v12-- For all Users to Help**
                                                </p>
                                            </a>
                                            <span class="explanation">by <span class="badgeInline"><span class="offline" title="offline"></span> <span class="aclColor_1"><a class="plain" href="/user/Uterkof/">Uterkof</a></span></span>
                                            <time class="timeago" datetime="2015-12-01T15:12:20+00:00">01 Dec 2015, 15:12</time>
                                            </span>
                                        </li>
                                        <li>
                                            <a href="/community/show/walking-dead-discussion-thread-v2-thread-103224/?unread=17162180">
                                                <i class="ka ka16 ka-community latest-icon"></i>
                                                <p class="latest-title">
                                                    THE WALKING DEAD Discussion Thread V2
                                                </p>
                                            </a>
                                            <span class="explanation">by <span class="badgeInline"><span class="offline" title="offline"></span> <span class="aclColor_1"><a class="plain" href="/user/Leroy_Brown/">Leroy_Brown</a></span></span>
                                            <time class="timeago" datetime="2015-12-01T15:12:18+00:00">01 Dec 2015, 15:12</time>
                                            </span>
                                        </li>
                                        <li>
                                            <a href="/community/show/flac-and-other-lossless-only-thread/?unread=17162174">
                                                <i class="ka ka16 ka-community latest-icon"></i>
                                                <p class="latest-title">
                                                    FLAC and Other Lossless Only Thread.
                                                </p>
                                            </a>
                                            <span class="explanation">by <span class="badgeInline"><span class="offline" title="offline"></span> <span class="aclColor_verified"><a class="plain" href="/user/andyt1000/">andyt1000</a></span></span>
                                            <time class="timeago" datetime="2015-12-01T15:11:14+00:00">01 Dec 2015, 15:11</time>
                                            </span>
                                        </li>
                                    </ul>
                                </div>
                                <!-- div class="sliderbox" -->

                                <div class="sliderbox">
                                    <h3><a href="/blog/">Latest News</a><i class="sliderBoxToggle ka ka16 ka-arrow2-up foldClose"></i></h3>
                                    <ul id="latestNews" rel="latestNews" class="showBlockJS">
                                        <li>
                                            <a href="/blog/post/new-site-rules/">
                                                <i class="ka ka16 ka-rss latest-icon"></i>
                                                <p class="latest-title">
                                                    New site Rules
                                                </p>
                                            </a>
                                            <span class="explanation">by KickassTorrents <time class="timeago" datetime="2015-10-15T14:18:43+00:00">15 Oct 2015, 14:18</time></span>
                                        </li>
                                        <li>
                                            <a href="/blog/post/look-mama-i-m-popular/">
                                                <i class="ka ka16 ka-rss latest-icon"></i>
                                                <p class="latest-title">
                                                    Look, mama, I&#039;m popular!
                                                </p>
                                            </a>
                                            <span class="explanation">by KickassTorrents <time class="timeago" datetime="2015-10-05T17:42:40+00:00">05 Oct 2015, 17:42</time></span>
                                        </li>
                                        <li>
                                            <a href="/blog/post/summer-updates-september-1/">
                                                <i class="ka ka16 ka-rss latest-icon"></i>
                                                <p class="latest-title">
                                                    Summer updates [September, 1]
                                                </p>
                                            </a>
                                            <span class="explanation">by KickassTorrents <time class="timeago" datetime="2015-09-01T16:13:36+00:00">01 Sep 2015, 16:13</time></span>
                                        </li>
                                    </ul>
                                </div>
                                <!-- div class="sliderbox" -->
                                <div class="sliderbox">
                                    <h3>Blogroll<i class="sliderBoxToggle ka ka16 ka-arrow2-up foldClose"></i></h3>
                                    <ul id="blogroll" rel="blogroll" class="showBlockJS">
                                        <li><a href="/blog/felix56/post/deception-point/"><i class="ka ka16 ka-rss latest-icon"></i><p class="latest-title"> Deception Point</p></a><span class="explanation">by <a class="plain aclColor_1" href="/user/felix56/">felix56</a> <time class="timeago" datetime="2015-12-01T05:32:48+00:00">01 Dec 2015, 05:32</time></span></li>
                                        <li><a href="/blog/TheDels/post/derek-savage-roasted/"><i class="ka ka16 ka-rss latest-icon"></i><p class="latest-title"> Derek Savage #Roasted</p></a><span class="explanation">by <a class="plain aclColor_1" href="/user/TheDels/">TheDels</a> <time class="timeago" datetime="2015-12-01T05:17:55+00:00">01 Dec 2015, 05:17</time></span></li>
                                        <li><a href="/blog/Ajay.Ghale/post/li-fi-technology-is-coming-soon-you-are-ready/"><i class="ka ka16 ka-rss latest-icon"></i><p class="latest-title"> Li-Fi Technology Is Coming Soon. You are Ready?</p></a><span class="explanation">by <a class="plain aclColor_1" href="/user/Ajay.Ghale/">Ajay.Ghale</a> <time class="timeago" datetime="2015-12-01T04:06:45+00:00">01 Dec 2015, 04:06</time></span></li>
                                        <li><a href="/blog/CindyKAT/post/december-original-12-days-of-christmas-25-dec-to-5-jan/"><i class="ka ka16 ka-rss latest-icon"></i><p class="latest-title"> December - ORIGINAL 12 Days of Christmas 25 Dec. to 5 Jan.</p></a><span class="explanation">by <a class="plain aclColor_2" href="/user/CindyKAT/">CindyKAT</a> <time class="timeago" datetime="2015-11-30T22:35:20+00:00">30 Nov 2015, 22:35</time></span></li>
                                        <li><a href="/blog/RoughJustice/post/let-me-be-perfectly-clear/"><i class="ka ka16 ka-rss latest-icon"></i><p class="latest-title"> Let Me Be (Perfectly) Clear ...</p></a><span class="explanation">by <a class="plain aclColor_2" href="/user/RoughJustice/">RoughJustice</a> <time class="timeago" datetime="2015-11-30T08:00:56+00:00">30 Nov 2015, 08:00</time></span></li>
                                        <li><a href="/blog/condoghost/post/torrent-removed-by-the-request-of-copyright-owner-and-not-available-for-download/"><i class="ka ka16 ka-rss latest-icon"></i><p class="latest-title"> Torrent &quot;Removed by the request of copyright owner and not available for download&quot;</p></a><span class="explanation">by <a class="plain aclColor_1" href="/user/condoghost/">condoghost</a> <time class="timeago" datetime="2015-11-29T22:43:06+00:00">29 Nov 2015, 22:43</time></span></li>
                                    </ul>
                                </div>
                                <!-- div class="sliderbox" -->

                                <div class="sliderbox">
                                    <h3>Goodies<i class="sliderBoxToggle ka ka16 ka-arrow2-up foldClose"></i></h3>
                                    <ul id="goodies" rel="goodies" class="showBlockJS">

                                        <li>
                                            <a data-nop target="_blank" rel="external" href="http://addons.mozilla.org/en-US/firefox/addon/11412" target="_blank" rel="external">
                                                <span class="ifirefox thirdPartIcons"></span>Firefox search plugin
                                            </a>
                                        </li>
                                        <li>
                                            <a data-nop target="_blank" rel="external" href="/content/utorrent.btsearch">
                                                <span class="iutorrent thirdPartIcons"></span>uTorrent search template
                                            </a>
                                        </li>
                                        <li>
                                            <a data-nop target="_blank" rel="external" href="http://twitter.com/kickasstorrents">
                                                <span class="ifollow thirdPartIcons"></span>Follow us on Twitter
                                            </a>
                                        </li>
                                        <li>
                                            <a data-nop target="_blank" rel="external" href="/blog/post/30/">
                                                <span class="ikat thirdPartIcons"></span>Kickass wallpapers
                                            </a>
                                        </li>
                                        <li>
                                            <a data-nop target="_blank" rel="external" href="http://www.facebook.com/official.KAT.fanclub">
                                                <span class="ifacebook thirdPartIcons"></span>Like us on Facebook
                                            </a>
                                        </li>
                                        <li>
                                            <a data-nop target="_blank" rel="external nofollow" href="http://chat.efnet.org:9090/?channels=%23KAT.ph"><span class="iirc thirdPartIcons"></span>IRC official chat</a>
                                        </li>
                                    </ul>
                                </div>
                                <!-- div class="sliderbox" -->
                                <div class="sliderbox">
                                    <h3>Latest Searches<i class="sliderBoxToggle ka ka16 ka-arrow2-up foldClose"></i></h3>
                                    <ul id="latestSearches" rel="latestSearches" class="showBlockJS">
                                        <li>
                                            <a href="/search/the%20conjuring%202013/">
                                                <i class="ka ka16 ka-zoom latest-icon"></i>
                                                <p class="latest-title">
                                                    the conjuring 2013
                                                </p>
                                            </a>
                                            <span class="explanation">just&nbsp;now</span>
                                        </li>

                                        <li>
                                            <a href="/search/john%20legend%20all%20of%20me/">
                                                <i class="ka ka16 ka-zoom latest-icon"></i>
                                                <p class="latest-title">
                                                    john legend all of me
                                                </p>
                                            </a>
                                            <span class="explanation">just&nbsp;now</span>
                                        </li>

                                        <li>
                                            <a href="/search/megumi%20shino/">
                                                <i class="ka ka16 ka-zoom latest-icon"></i>
                                                <p class="latest-title">
                                                    megumi shino
                                                </p>
                                            </a>
                                            <span class="explanation">just&nbsp;now</span>
                                        </li>

                                        <li>
                                            <a href="/search/forbidden/">
                                                <i class="ka ka16 ka-zoom latest-icon"></i>
                                                <p class="latest-title">
                                                    Forbidden
                                                </p>
                                            </a>
                                            <span class="explanation">just&nbsp;now</span>
                                        </li>

                                        <li>
                                            <a href="/search/frozen/">
                                                <i class="ka ka16 ka-zoom latest-icon"></i>
                                                <p class="latest-title">
                                                    frozen
                                                </p>
                                            </a>
                                            <span class="explanation">just&nbsp;now</span>
                                        </li>

                                        <li>
                                            <a href="/search/minecraft%20server/">
                                                <i class="ka ka16 ka-zoom latest-icon"></i>
                                                <p class="latest-title">
                                                    minecraft server
                                                </p>
                                            </a>
                                            <span class="explanation">just&nbsp;now</span>
                                        </li>

                                        <li>
                                            <a href="/search/nabokov/">
                                                <i class="ka ka16 ka-zoom latest-icon"></i>
                                                <p class="latest-title">
                                                    nabokov
                                                </p>
                                            </a>
                                            <span class="explanation">just&nbsp;now</span>
                                        </li>

                                        <li>
                                            <a href="/search/greys%20anatomy%20s12e04/">
                                                <i class="ka ka16 ka-zoom latest-icon"></i>
                                                <p class="latest-title">
                                                    Greys Anatomy s12e04
                                                </p>
                                            </a>
                                            <span class="explanation">just&nbsp;now</span>
                                        </li>

                                        <li>
                                            <a href="/search/girls%20gone%20wild/">
                                                <i class="ka ka16 ka-zoom latest-icon"></i>
                                                <p class="latest-title">
                                                    Girls Gone Wild
                                                </p>
                                            </a>
                                            <span class="explanation">just&nbsp;now</span>
                                        </li>

                                        <li>
                                            <a href="/search/alloy%20of%20law/">
                                                <i class="ka ka16 ka-zoom latest-icon"></i>
                                                <p class="latest-title">
                                                    alloy of law
                                                </p>
                                            </a>
                                            <span class="explanation">just&nbsp;now</span>
                                        </li>

                                        <li>
                                            <a href="/search/battle%20of%20the%20sexes%202015/">
                                                <i class="ka ka16 ka-zoom latest-icon"></i>
                                                <p class="latest-title">
                                                    battle of the sexes 2015
                                                </p>
                                            </a>
                                            <span class="explanation">just&nbsp;now</span>
                                        </li>

                                    </ul>
                                </div>
                                <!-- div class="sliderbox" -->
                                <div class="sliderbox">
                                    <h3>Friends Links<i class="sliderBoxToggle ka ka16 ka-arrow2-up foldClose"></i></h3>
                                    <ul id="friendsLinks" rel="friendsLinks" class="showBlockJS">

                                        <li>
                                            <a data-nop href="http://torrents.to/" target="_blank" rel="external">
                                                <span class="itorrentsto thirdPartIcons"></span>Torrents.to
                                            </a>
                                        </li>
                                        <li>
                                            <a data-nop href="http://www.torrentdownloads.net/" target="_blank" rel="external">
                                                <span class="itorrentdownloads thirdPartIcons"></span>Torrent Downloads
                                            </a>
                                        </li>




                                        <li>
                                            <a data-nop href="http://torrent-finder.info/" target="_blank" rel="external">
                                                <span class="itorrentfinder thirdPartIcons"></span>Torrent Finder
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                                <!-- div class="sliderbox" -->

                            </div>
                            <a class="showSidebar" id="showsidebar" onclick="showSidebar();" style="display:none;"></a>

                        </td>
                    </tr>
                </table>
                <div class="rightcell">
                </div>
                <!-- div class="rightcell" -->
                <div class="leftcell">
                </div>
                </div>
                <div id="translate_site" style="display:none">
                    <h3>Select Your Language</h3>
                    <div class="textcontent">
                        <div style="-moz-column-width: 12em; -moz-columns: 12em; -webkit-columns: 12em; columns:12em;">
                            <ul>
                                <li class="current_lang"><a href="#" onclick="setLanguage('en', '.kat.cr');return false;" class="plain"><strong>English</strong></a></li>
                                <li><a href="#" onclick="setLanguage('af', '.kat.cr');return false;" class="plain">Afrikaans</a></li>
                                <li><a href="#" onclick="setLanguage('al', '.kat.cr');return false;" class="plain">Albanian</a></li>
                                <li><a href="#" onclick="setLanguage('ar', '.kat.cr');return false;" class="plain">Arabic (Modern)</a></li>
                                <li><a href="#" onclick="setLanguage('eu', '.kat.cr');return false;" class="plain">Basque</a></li>
                                <li><a href="#" onclick="setLanguage('bn', '.kat.cr');return false;" class="plain">Bengali</a></li>
                                <li><a href="#" onclick="setLanguage('bs', '.kat.cr');return false;" class="plain">Bosnian</a></li>
                                <li><a href="#" onclick="setLanguage('bsc', '.kat.cr');return false;" class="plain">Bosnian-Cyrillic</a></li>
                                <li><a href="#" onclick="setLanguage('br', '.kat.cr');return false;" class="plain">Brazilian Portuguese</a></li>
                                <li><a href="#" onclick="setLanguage('bg', '.kat.cr');return false;" class="plain">Bulgarian</a></li>
                                <li><a href="#" onclick="setLanguage('ch', '.kat.cr');return false;" class="plain">Chinese Simplified</a></li>
                                <li><a href="#" onclick="setLanguage('tw', '.kat.cr');return false;" class="plain">Chinese Traditional</a></li>
                                <li><a href="#" onclick="setLanguage('hr', '.kat.cr');return false;" class="plain">Croatian</a></li>
                                <li><a href="#" onclick="setLanguage('cz', '.kat.cr');return false;" class="plain">Czech</a></li>
                                <li><a href="#" onclick="setLanguage('da', '.kat.cr');return false;" class="plain">Danish</a></li>
                                <li><a href="#" onclick="setLanguage('nl', '.kat.cr');return false;" class="plain">Dutch</a></li>
                                <li><a href="#" onclick="setLanguage('tl', '.kat.cr');return false;" class="plain">Filipino</a></li>
                                <li><a href="#" onclick="setLanguage('fi', '.kat.cr');return false;" class="plain">Finnish</a></li>
                                <li><a href="#" onclick="setLanguage('fr', '.kat.cr');return false;" class="plain">French</a></li>
                                <li><a href="#" onclick="setLanguage('ka', '.kat.cr');return false;" class="plain">Georgian</a></li>
                                <li><a href="#" onclick="setLanguage('de', '.kat.cr');return false;" class="plain">German</a></li>
                                <li><a href="#" onclick="setLanguage('el', '.kat.cr');return false;" class="plain">Greek</a></li>
                                <li><a href="#" onclick="setLanguage('he', '.kat.cr');return false;" class="plain">Hebrew</a></li>
                                <li><a href="#" onclick="setLanguage('hi', '.kat.cr');return false;" class="plain">Hindi</a></li>
                                <li><a href="#" onclick="setLanguage('hu', '.kat.cr');return false;" class="plain">Hungarian</a></li>
                                <li><a href="#" onclick="setLanguage('id', '.kat.cr');return false;" class="plain">Indonesian</a></li>
                                <li><a href="#" onclick="setLanguage('it', '.kat.cr');return false;" class="plain">Italian</a></li>
                                <li><a href="#" onclick="setLanguage('kn', '.kat.cr');return false;" class="plain">Kannada</a></li>
                                <li><a href="#" onclick="setLanguage('ko', '.kat.cr');return false;" class="plain">Korean</a></li>
                                <li><a href="#" onclick="setLanguage('lv', '.kat.cr');return false;" class="plain">Latvian</a></li>
                                <li><a href="#" onclick="setLanguage('lt', '.kat.cr');return false;" class="plain">Lithuanian</a></li>
                                <li><a href="#" onclick="setLanguage('mk', '.kat.cr');return false;" class="plain">Macedonian</a></li>
                                <li><a href="#" onclick="setLanguage('ml', '.kat.cr');return false;" class="plain">Malayalam</a></li>
                                <li><a href="#" onclick="setLanguage('ms', '.kat.cr');return false;" class="plain">Malaysian</a></li>
                                <li><a href="#" onclick="setLanguage('no', '.kat.cr');return false;" class="plain">Norwegian</a></li>
                                <li><a href="#" onclick="setLanguage('pr', '.kat.cr');return false;" class="plain">Pirate</a></li>
                                <li><a href="#" onclick="setLanguage('pl', '.kat.cr');return false;" class="plain">Polish</a></li>
                                <li><a href="#" onclick="setLanguage('pt', '.kat.cr');return false;" class="plain">Portuguese</a></li>
                                <li><a href="#" onclick="setLanguage('pa', '.kat.cr');return false;" class="plain">Punjabi</a></li>
                                <li><a href="#" onclick="setLanguage('ro', '.kat.cr');return false;" class="plain">Romanian</a></li>
                                <li><a href="#" onclick="setLanguage('ru', '.kat.cr');return false;" class="plain">Russian</a></li>
                                <li><a href="#" onclick="setLanguage('sr', '.kat.cr');return false;" class="plain">Serbian</a></li>
                                <li><a href="#" onclick="setLanguage('src', '.kat.cr');return false;" class="plain">Serbian-Cyrillic</a></li>
                                <li><a href="#" onclick="setLanguage('si', '.kat.cr');return false;" class="plain">Sinhala</a></li>
                                <li><a href="#" onclick="setLanguage('sk', '.kat.cr');return false;" class="plain">Slovak</a></li>
                                <li><a href="#" onclick="setLanguage('sl', '.kat.cr');return false;" class="plain">Slovenian</a></li>
                                <li><a href="#" onclick="setLanguage('es', '.kat.cr');return false;" class="plain">Spanish</a></li>
                                <li><a href="#" onclick="setLanguage('sv', '.kat.cr');return false;" class="plain">Swedish</a></li>
                                <li><a href="#" onclick="setLanguage('ta', '.kat.cr');return false;" class="plain">Tamil</a></li>
                                <li><a href="#" onclick="setLanguage('te', '.kat.cr');return false;" class="plain">Telugu</a></li>
                                <li><a href="#" onclick="setLanguage('tr', '.kat.cr');return false;" class="plain">Turkish</a></li>
                                <li><a href="#" onclick="setLanguage('uk', '.kat.cr');return false;" class="plain">Ukrainian</a></li>
                                <li><a href="#" onclick="setLanguage('ur', '.kat.cr');return false;" class="plain">Urdu</a></li>
                                <li><a href="#" onclick="setLanguage('vi', '.kat.cr');return false;" class="plain">Vietnamese</a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- div class="textcontent" -->
                </div>
                </div>
                <!--id="main"-->
                </div>
                <!--id="wrap"-->

                <footer class="lightgrey">
                    <ul>
                        <li><a class="plain" data-nop href="#translate_site" id="translate_link"><strong>change language</strong></a></li>
                        <li><a href="/rules/" class="lower">rules</a></li>
                        <li><a href="/ideabox/">idea box</a></li>
                        <li class="lower"><a href="/achievements/">Achievements</a></li>
                        <li><a href="/trends/">trends</a></li>
                        <li class="lower"><a href="/latest-searches/">Latest Searches</a></li>
                        <li><a href="/request/">torrent requests</a></li>
                    </ul>
                    <ul>
                        <li><a href="/about/">about</a></li>
                        <li><a href="/privacy/">privacy</a></li>
                        <li><a href="/dmca/">dmca</a></li>
                        <li><a href="/logos/">logos</a></li>
                        <li><a href="/contacts/">contacts</a></li>
                        <li><a href="/api/">api</a></li>
                        <li><a href="https://kastatus.com">KAT status</a></li>
                        <li><a target="_blank" rel="external nofollow" href="http://chat.efnet.org:9090/?channels=%23KAT.ph">chat</a></li>
                    </ul>
                </footer>
                <a class="feedbackButton eventsButtons" href="/issue/create/" id="feedback"><span>Report a bug</span></a>
                <span data-sc-slot="_673e31f53f8166159b8e996c4124765b"></span>
                <span data-sc-slot="_e7050fb15fd39b3e4e99a5be4a57b6ea"></span>
                <script>
                    sc('addGlobal', 'pagetype', 'other');
                </script>
                <script type="text/javascript">
                    <!--
                    document.write("<a style='display:none;' href='http://www.liveinternet.ru/click' " +
                            "target=_blank><img src='//counter.yadro.ru/hit?t45.6;r" +
                            escape(document.referrer) + ((typeof (screen) == "undefined") ? "" :
                                ";s" + screen.width + "*" + screen.height + "*" + (screen.colorDepth ?
                                    screen.colorDepth : screen.pixelDepth)) + ";u" + escape(document.URL) +
                            ";h" + escape(document.title.substring(0, 80)) + ";" + Math.random() +
                            "' alt='' title='LiveInternet' " +
                            "border='0' width='0' height='0'><\/a>")
                        //-->
                </script>

</body>

</html>
'''
import bs4
from ast import literal_eval
soup = bs4.BeautifulSoup(data)

links = soup.select("div.iaconbox span")
for span in links:
    magnet = literal_eval(span["data-sc-params"])
    print magnet["name"], magnet["magnet"]

# import requests
#
# url = "http://www.elitetorrent.net/categoria/1/estrenos/modo:listado/pag:1"
# browser = requests.Session()
# page = "1"
# import bs4
#
# response = browser.get( url + page)
# soup = bs4.BeautifulSoup(response.text)
# links = soup.select("a.nombre")
# for link in links:
#     print link.get("title", ""), link["href"]

# import re
#
# datos = re.search("var datos =(.*?);", data, re.DOTALL).group(1).replace("{", "").replace("}", "")
# params = {}
# for item in datos.split("\n"):
#     if item.strip() != "":
#         key, value = item.strip()[:-1].split(':')
#         params[key] = value.replace("'", "")
# #settings.debug(params)
# opciones = re.search("var options =(.*?);", data, re.DOTALL).group(1).replace("{", "").replace("}", "") + ": ''"
# params1 = {}
# for item in opciones.split("\n"):
#     if item.strip() != "":
#         key, value = item.strip()[:-1].split(':')
#         params1[key] = value.replace("'", "")
# #settings.debug(params1)
# urlPage = re.search('url: "(.*?)"', data).group(1)
