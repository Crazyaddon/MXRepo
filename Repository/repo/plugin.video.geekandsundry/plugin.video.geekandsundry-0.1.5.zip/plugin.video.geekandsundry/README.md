plugin.video.geekandsundry
==========================

Geek & Sundry for Kodi (XBMC)
----------------------------
This addon allows access to videos on the Geek & Sundry site at http://geekandsundry.com

Installation should be done through Kodi System::Settings::Add-ons::Get Add-Ons::All Add-Ons::Video Add-Ons::Geek & Sundry

If you want to ensure you are using the latest version of the addon you can install my [repository .zip file](http://ruuks-repo.googlecode.com/files/ruuk.addon.repository-1.0.0.zip).

Installation of the repository should be done through Kodi System::Settings::Add-ons::Install from zip file

Support is available at: http://forum.xbmc.org/showthread.php?tid=180283

Currently implemented Geek & Sundry features:
  * Newest Videos (The Geek & Sundry video feed)
  * On-Air Shows (Listed directly in the top category list)
  * Vlogs
  * All Shows
