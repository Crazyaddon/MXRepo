
__version__ = '0.3.2'
__author__ = 'Christian Kreutzer'
__license__ = 'BSD'
