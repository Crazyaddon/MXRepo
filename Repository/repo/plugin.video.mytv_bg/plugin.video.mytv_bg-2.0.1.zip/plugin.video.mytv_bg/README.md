# plugin.video.mytv_bg
Addon for kodi/xbmc
=======
### Welcome to MyTV.bg Addon Pages.
# plugin.video.mytv_bg
Addon for kodi/xbmc

### Как да инсталираме адона за kodi/xbmc
1. Свалете адона Download ZIP.
2. От **kodi/xbmc** влезте в **systems/settings/add-ons/** и изберете **Install from zip file**. След което избирате вече сваления файл.
3. Преди да го пробвате как работи ще трябва да си въведете **username** и **password** за достъп от **configure**. Това може да стане през следния път: **systems/settings/add-ons/** и влизате в **My add-ons** намирате **Video add-ons** и избирате **MyTV.bg**.

Новия API позволява автоматично да се update данните както и менютата.

### Authors and Contributors
Author: **Ivan Georgiev**
Email: **sasbass@targovishte.com**

### Support or Contact
Ако имате нужда от помощ или просто желаете да се свържите с нас i.georgiev@mytv.bg или на support@mytv.bg
