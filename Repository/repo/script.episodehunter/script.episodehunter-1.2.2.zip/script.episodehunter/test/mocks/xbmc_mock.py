
class Player(object):
    pass
