"""
Background process
"""

from resources.lib.eh_player import EHPlayer

player = EHPlayer()
player.run()
