__BASE_URL__ = "http://api.episodehunter.tv"
__NAME__ = "EpisodeHunter"
__HTTP_TIMEOUT__ = 15  # Timeout in seconds
