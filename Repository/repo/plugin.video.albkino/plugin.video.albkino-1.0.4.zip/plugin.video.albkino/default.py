#!/usr/bin/python
# -*- coding: latin-1 -*-

import sys, xbmc
import xbmc,xbmcplugin
import xbmcgui
import sys
import urllib, urllib2
import time
import re
from htmlentitydefs import name2codepoint as n2cp
import httplib
import urlparse
from os import path, system
import socket
from urllib2 import Request, URLError, urlopen
from urlparse import parse_qs
from urllib import unquote_plus

thisPlugin = int(sys.argv[1])
addonId = "plugin.video.albkino"
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
if not path.exists(dataPath):
       cmd = "mkdir -p " + dataPath
       system(cmd)
       
Host = "http://www.albkino.co/"   

cachefold=None
try:
                  myfile = file(r"/etc/xbmc.txt")       
                  icount = 0
                  for line in myfile.readlines():
                       cachefold = line
                       break
except:
                      pass
if  cachefold is None:   
                   try:cachefold=sys.argv[3]
                   except:cachefold="/media/hdd"    
       
#Host = "http://www.filma24-al.com/movie-genre/aventure/"
def getUrl(url):
        pass#print "Here in getUrl url =", url
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link
	
def getUrl2(url, referer):
        pass#print "Here in getUrl2 url =", url
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        req.add_header('Referer', referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link	

def showContent():
        content = getUrl(Host)
        pass#print "content A =", content
        i1 = 0           
        if i1 == 0:
                regexcat = 'a href="http://www.albkino.co/browse-(.*?)-videos.*?class="">(.*?)<'
                match = re.compile(regexcat,re.DOTALL).findall(content)
                pass#print "match =", match
                for url, name in match:
                        pic = " "
                        pass#print "Here in Showcontent url1 =", url
                        addDirectoryItem(name, {"name":name, "url":url, "mode":1}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)
                
#http://www.albkino.co/browse-402-videos-3-date.html
def getPage(name, url):
                pages = [1, 2, 3, 4, 5, 6]
                
                for page in pages:
                        url1 = "http://www.albkino.co/browse-" + url + "-videos-" + str(page) + "-date.html"
                        name = "Page " + str(page)
                        pic = " "
                        addDirectoryItem(name, {"name":name, "url":url1, "mode":2}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)
#http://www.eporner.com/hd-porn/497308/Elegant-Blonde-In-Threesome-Action/#

def getVideos(name1, urlmain):
        url = urlmain
	content = getUrl(url)
	pass#print "content A =", content

	regexvideo = '<div class="pm-li-video">.*?<a href="(.*?)".*?<img src="(.*?)" alt="(.*?)"'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "match =", match
        for url, pic, name in match:
                 ##pass#print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)	         
        
def getVideos2(name, url):
	content = getUrl(url)
	pass#print "content B =", content
        """
	regexvideo = '<iframe src="(.*?)"'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "match =", match
        content2 = getUrl(match[0])
        pass#print "content2 =", content2
        regexvideo = 'type="video.*?src="(.*?)"'
        match = re.compile(regexvideo,re.DOTALL).findall(content2)
        pass#print "match B=", match
        vidurl = match[0]
        vidurl = vidurl.replace("\\", "")
	pass#print "vidurl =", vidurl
        playVideo(name, vidurl)
        
        """
        regexvideo = '<iframe src="(.*?)"'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "match =", match
        vid = match[0]
        vid = vid.replace("/embed/", "/f/")
        n1 = vid.find("/f/", 0)
        n2 = vid.find("/", (n1+8))
        pass#print "n1, n2 =", n1, n2
        vid1 = vid[:n2]
        vid2 = vid[(n2+1):]
        vidurl = vid1 + "|" + vid2
        pass#print "vidurl =", vidurl
        from openload import resolve
        vurl = resolve(vidurl)
        pass#print "vurl =", vurl
        playVideo(name, vurl)
        
        
        
        
        

def showError(self, error):
        pass#print "ERROR :", error
        	        		
def getVideos3(name1, urlmain):
        url = urlmain + "page/3/"
	content = getUrl(url)
	pass#print "content B1 =", content

	regexvideo = 'div class="boxim.*?a href="(.*?)".*?Boxoffice\/timthumb.*?src=(.*?)\&amp.*?div class="btitle.*?title=".*?>(.*?)<'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "match =", match
        for url, pic, name in match:
                 ##pass#print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":5}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)	         

def getVideos4(name, url):
    pass#print "In getVideos4 url A=", url
    content = getUrl(url)
    pass#print "content C =", content
    html = content
   
    html = html.replace('\n\r', '').replace('\r', '').replace('\n', '').replace('\\', '')
    children = []
    names = []
    pass#print "html =", html
    """
    if re.search('https://video.google.com/get_player', html):
        names.append("google")
        docId = re.compile('docid=(.+?)"').findall(html)[0]
        children.append('https://docs.google.com/file/d/' + docId + '/preview')

    if children is None or len(children) == 0:
            children = re.compile('<iframe src="(.+?)"').findall(html)
            if children is None or len(children) == 0:
                    children = re.compile('docs.google.com/file/d/(.+?)"').findall(html)[0]
            names = []
            i = 0
            for child in children:
                   i = i+1
                   names.append("option " + str(i)) 
                   

    pass#print "names =", names
    pass#print "children =", children
    i = 0
    """
    match = re.compile('<iframe src="(.+?)"').findall(html)
    name = "Filepup"
    url = (match[0])
    pic = " "
    pass#print "name =", name
    pass#print "url =", url
    addDirectoryItem(name, {"name":name, "url":url, "mode":6}, pic)
    n1 = html.find("shik7.png", 0)
    n2 = html.find("></p>", n1)
    html = html[n1:n2]
    pass#print "html B=", html
    regexvideo = 'a href="(.+?)".*?img src="(.+?)"'
    match = re.compile(regexvideo,re.DOTALL).findall(html) 
    pass#print "match B=", match
    for url, name in match:
           n3 = name.rfind("/")
           name = name[(n3+1):]
           name = name[:-5]
           pic = " "
           pass#print "name B=", name
           pass#print "url B=", url
           addDirectoryItem(name, {"name":name, "url":url, "mode":6}, pic)
    
    xbmcplugin.endOfDirectory(thisPlugin)

def getVideos5(name, url):
    pass#print "In getVideos5 name =", name
    pass#print "In getVideos5 url =", url
    if "filepup" in url:  
        content = getUrl(url)
        pass#print "content E1 =", content
        
        regexvideo = 'video id="FilePup_Stream.*?src="(.+?)"'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "match =", match
        stream_url = match[0]
        pass#print "stream_url =", stream_url
        playVideo(name, stream_url)
    else:
        content = getUrl(url)
        content = content.decode('utf8')
        pass#print "content E =", content
        regexvideo = 'window.location="(.+?)"'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
	url = match[0]
        import urlresolver
        stream_url = urlresolver.HostedMediaFile(url=url).resolve()
        pass#print "stream_url =", stream_url
        playVideo(name, stream_url)

def getVideos5X(name1, urlmain):
        url = urlmain + "/videos?p=5"
	content = getUrl(url)
	#pass#print "content B =", content

	regexvideo = 'thumb_container video.*?href="(.*?)" title="(.*?)">'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        ##pass#print "match =", match
        for url, name in match:
                 name = name.replace('"', '')
                 url = "http://www.deviantclip.com" + url
                 pic = " " 
                 ##pass#print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)

                
def playVideo(name, url):
           pass#print "Here in playVideo url =", url
           pic = "DefaultFolder.png"
           li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
           player = xbmc.Player()
           player.play(url, li)

std_headers = {
	'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
	'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'en-us,en;q=0.5',
}  

def addDirectoryItem(name, parameters={},pic=""):
    li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
    url = sys.argv[0] + '?' + urllib.urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)


def parameters_string_to_dict(parameters):
    ''' Convert parameters encoded in a URL to a dict. '''
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict

params = parameters_string_to_dict(sys.argv[2])
name =  str(params.get("name", ""))
url =  str(params.get("url", ""))
url = urllib.unquote(url)
mode =  str(params.get("mode", ""))
pass#print "name =", name
pass#print "url =", url

if not sys.argv[2]:
	ok = showContent()
else:
	if mode == str(1):
		ok = getPage(name, url)	

	elif mode == str(2):
		ok = getVideos(name, url)	
	elif mode == str(3):
	        ok = getVideos2(name, url)
#		ok = playVideo(name, url)	
	elif mode == str(4):
		ok = getVideos3(name, url)	
	elif mode == str(5):
		ok = getVideos4(name, url)
	elif mode == str(6):
#	        ok = playVideo(name, url)
		ok = getVideos5(name, url)
	elif mode == str(7):
	        ok = playVideo(name, url)
		


































































