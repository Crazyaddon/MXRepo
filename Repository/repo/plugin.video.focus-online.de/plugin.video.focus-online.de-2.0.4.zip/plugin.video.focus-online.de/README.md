![](https://raw.githubusercontent.com/bromix/repository.bromix.storage/master/plugin.video.focus-online.de/icon.png)
# **Links:**

* [FOCUS Online](www.focus.de/videos)

[![](https://www.paypalobjects.com/en_GB/i/btn/btn_donate_LG.gif)](https://goo.gl/U5oVOj) [![](https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif)](https://goo.gl/15V9TN) [![](https://www.paypalobjects.com/de_DE/i/btn/btn_donate_LG.gif)](https://goo.gl/oEjE9E) [![](https://pledgie.com/campaigns/29261.png?skin_name=chrome)](https://goo.gl/K4RZrZ) 

# **Changelog:**

## **2.0.3**

* localization was missing a text and the ID was wrong

## **2.0.2**

* moved from *.xml to *.po localizations

## **2.0.1**

* added missing Fanart in root menu


# **Images:**
![](http://i.imgur.com/cQDWsdn.png)
