infoLabels ={}
fanart ="xxx"
print infoLabels.get("backdrop_url",fanart)