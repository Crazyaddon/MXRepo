# coding: utf-8
__author__ = 'Mancuniancol'
from os import path
from xbmc import translatePath
from xbmcaddon import Addon

version = "0.0.0.0"
path = path.join(translatePath('special://temp'), "version-mod-tvguia.txt")
try:
    with open(path, 'r') as fp:
        for line in fp:
            version = line
except:
    pass

newVersion = Addon().getAddonInfo('version')

print newVersion, version
if version not in newVersion:
    import main

    with open(path, 'w') as fp:
        fp.write(newVersion)
