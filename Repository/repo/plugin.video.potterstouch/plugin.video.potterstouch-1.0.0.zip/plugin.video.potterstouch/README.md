The Potter's Touch
===============

The Potter's Touch, a weekly program, with Bishop T.D. Jakes, tackles today's topics and confronts the hidden issues and invisible scars that go untreated. This broadcast carries healing and restoration into homes of hurting people, unearthing taboo topics and offering practical and spiritual solutions to life's toughest questions.