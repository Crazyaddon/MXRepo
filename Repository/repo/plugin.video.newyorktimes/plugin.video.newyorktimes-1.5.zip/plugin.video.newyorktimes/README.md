New York Times Plugin for XBMC
==============================

Watch videos from http://video.on.nytimes.com

### Contact

idleloop -at- yahoo.com

### Original author:

web@jonathanbeluch.com  
jbel on [http://forum.xbmc.org](http://forum.xbmc.org)
