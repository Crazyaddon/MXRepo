![](https://raw.githubusercontent.com/bromix/repository.bromix.storage/master/plugin.video.break_com/icon.png)
# **Links:**

* [Break Videos](www.break.com)

[![](https://www.paypalobjects.com/en_GB/i/btn/btn_donate_LG.gif)](https://goo.gl/U5oVOj) [![](https://www.paypalobjects.com/en_US/i/btn/btn_donate_LG.gif)](https://goo.gl/15V9TN) [![](https://www.paypalobjects.com/de_DE/i/btn/btn_donate_LG.gif)](https://goo.gl/oEjE9E) [![](https://pledgie.com/campaigns/29261.png?skin_name=chrome)](https://goo.gl/K4RZrZ) 

# **Changelog:**

## **4.0.2**

* localization was missing a text and the ID was wrong

## **4.0.1**

* moved from *.xml to *.po localizations

## **4.0.0**

* framework


# **Images:**
![](http://i.imgur.com/qV00Jwc.png)
![](http://i.imgur.com/qY8yMeY.png)
