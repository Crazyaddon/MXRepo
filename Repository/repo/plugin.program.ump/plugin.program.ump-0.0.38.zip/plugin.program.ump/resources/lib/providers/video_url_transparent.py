import json

def run(hash,ump,referer=None):
	return hash