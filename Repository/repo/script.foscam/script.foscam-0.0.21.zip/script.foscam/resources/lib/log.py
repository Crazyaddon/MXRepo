try:
    import xbmc
except ImportError:
    def log(message):
        print message
        
    log_normal = log
    log_verbose = log
    log_error = log
else:
    import xbmcaddon
    import xbmcgui

    __addon__ = xbmcaddon.Addon()

    __id__ = __addon__.getAddonInfo('id')
    __version__ = __addon__.getAddonInfo('version')


    def log(message, level=xbmc.LOGNOTICE):
        xbmc.log("{0} v{1}: {2}".format(__id__, __version__, message), level=level)
       
    def log_normal(message):
        if int(__addon__.getSetting('debug')) > 0:
            log(message)
    
    def log_verbose(message):
        if int(__addon__.getSetting('debug')) == 2:
            log(message)
        
    def log_error(message):
        log(message, xbmc.LOGERROR) 