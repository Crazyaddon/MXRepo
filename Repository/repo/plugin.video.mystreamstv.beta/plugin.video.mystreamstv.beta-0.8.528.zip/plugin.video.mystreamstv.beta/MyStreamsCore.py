'''
    MyStreamsTV plugin for XBMC
    Copyright (C) 2012 SmoothStreams

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import os
import re
import sys
import json
import time
import urllib
import subprocess

class MyStreamsCore:
    def __init__(self):
        self.settings = sys.modules["__main__"].settings
        self.language = sys.modules["__main__"].language
        self.common = sys.modules["__main__"].common
        self.cache = sys.modules["__main__"].cache
        self.downloader = sys.modules["__main__"].downloader
        self.xbmc = sys.modules["__main__"].xbmc
        self.xbmcgui = sys.modules["__main__"].xbmcgui
        self.xbmcplugin = sys.modules["__main__"].xbmcplugin
        self.scheduler = sys.modules["__main__"].scheduler
        self.xbmcvfs = sys.modules["__main__"].xbmcvfs

        self.servers = ["dEU.SmoothStreams.tv", "d88.SmoothStreams.tv", "d11.SmoothStreams.tv", "dNAE.SmoothStreams.tv", "dNAW.SmoothStreams.tv", "dNA.SmoothStreams.tv", "dSG.SmoothStreams.tv"]

        if hasattr(sys.modules["__main__"], "xbmcaddon"):
            self.xbmcaddon = sys.modules["__main__"].xbmcaddon
        else:
            import xbmcaddon
            self.xbmcaddon = xbmcaddon

        return None

    def showMessage(self, heading, message):
        duration = ([1, 2, 3, 4, 5, 6, 7, 8, 9, 10][int(self.settings.getSetting('notification_length'))]) * 1000
        self.xbmc.executebuiltin((u'XBMC.Notification("%s", "%s", %s)' % (heading, message, duration)).encode("utf-8"))

    def safeDecodeUnicode(self, data):
        try:
            return data.decode("utf-8")
        except:
            try:
                return data.decode("utf-8", "ignore")
            except:
                return repr(data)

    def makeChannelList(self):
        self.common.log("")
        size = 50
        if self.scheduler.use_cache:
            channel_name, playing_now, playing_next = self.cache.cacheFunction(self.scheduler.getChanInfo, self.scheduler.getNow(1000))
        else:
            channel_name, playing_now, playing_next = self.scheduler.getChanInfo()

        for chan in range(1, size + 1):
            if chan < 10:
                chan = "0" + str(chan)
            else:
                chan = str(chan)

            name = "#" + chan

            if chan in channel_name:
                name = "#" + self.safeDecodeUnicode(channel_name[chan])
                playing = "%s %s\r\n" % (self.language(30101), self.safeDecodeUnicode(channel_name[chan]))
            else:
                playing = "%s %s\r\n" % (self.language(30101), chan)

            if chan in playing_now:
                playing = "%s: %s\r\n" % (self.language(30106), self.safeDecodeUnicode(playing_now[chan]))
                name += " - Now: " + self.safeDecodeUnicode(playing_now[chan])

            if chan in playing_next:
                if chan not in playing_now or playing_next[chan] != playing_now[chan]:
                    try:
                        playing += "%s: %s\r\n" % (self.language(30107), self.safeDecodeUnicode(playing_next[chan]))
                    except: # Unicode utf8 python crap.
                        pass
                    name += " - Next: " + self.safeDecodeUnicode(playing_next[chan])

            listitem = self.xbmcgui.ListItem(label=name)
            listitem.setProperty("Video", "true")
            listitem.setProperty("IsPlayable", "true")
            listitem.setInfo(type='Video', infoLabels={"Title": name, "plot": playing})
            #listitem.addStreamInfo("video", {"codec": "h264", "aspect": 1.78, "width": 1280, "height": 720})
            cm = []
            if self.downloader:
                if False: # Enable download and play
                    if self.settings.getSetting("download_and_playing") == "true":
                        cm.append((self.language(30111), "XBMC.RunPlugin(%s?path=%s&action=download_and_play&chan=%s)" % (sys.argv[0], "/root/channels/", chan)))
                        cm.append((self.language(30110), "XBMC.RunPlugin(%s?path=%s&action=stop_download&chan=%s)" % (sys.argv[0], "/root/channels/", chan)))
                    else:
                        cm.append((self.language(30109), "XBMC.RunPlugin(%s?path=%s&action=download_and_play&chan=%s)" % (sys.argv[0], "/root/channels/", chan)))
                cm.append((self.language(30103), "XBMC.RunPlugin(%s?path=%s&action=download&chan=%s)" % (sys.argv[0], "/root/channels/", chan)))
            cm.append((self.language(30108), "XBMC.Action(Info)",))

            cm.append(("play_channel", "XBMC.RunPlugin(%s?path=%s&action=play_channel&chan=%s)" % (sys.argv[0], "/root/channels/", chan)))

            listitem.addContextMenuItems(cm)

            url = sys.argv[0] + "?path=/root/channels/&action=play_channel&chan=%s" % chan
            self.xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, isFolder=False, totalItems=size)

        self.xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True, cacheToDisc=False)
        self.common.log("Done")

    def getChanUrl(self, params={}):
        self.common.log(repr(params))
        get = params.get

        server = self.servers[int(self.settings.getSetting("server"))]

        if self.settings.getSetting("high_def") == "true":
            quality = "q1"  # HD - 2800k
        elif True:
            quality = "q2"  # LD - 1250k
        else:
            quality = "q3"  # Mobile - 400k ( Not in settings)

        chan = get("chan")
        if self.settings.getSetting("SUserN") == "":
            self.common.log("No login credentials, trying to set again")
            self.login()

        uname = self.settings.getSetting("SUserN")
        pword = self.settings.getSetting("SPassW")

        service = self.settings.getSetting("service")
        if self.settings.getSetting("server_type") == "0":
            if service == "1":
                self.common.log("Using Live247.tv")
                stream_port = "2935"
            elif service in ["0"]:
                self.common.log("Using Mystreams/uSport")
                stream_port = "29350"
            elif service == "2":
                self.common.log("Using StarStreams")
                stream_port = "3935"
            elif service == "3":
                self.common.log("Using MMA")
                stream_port = "5540"

            stream_type = "rtmp"
            chan_template = "%s://%s:%s/view?u=%s&p=%s/ch%s%s.stream"
            url = chan_template % (stream_type, server, stream_port, uname, pword, chan, quality)

            # This fails. Causes XBMC to deadlock
            #url += '|' + urllib.urlencode({'User-Agent': sys.modules["__main__"].plugin})
        else:
            if service == "1":
                self.common.log("Using Live247.tv")
                stream_port = "12935"
            elif service in ["0"]:
                self.common.log("Using Mystreams/uSport")
                stream_port = "29355"
            elif service == "2":
                self.common.log("Using StarStreams")
                stream_port = "39355"
            elif service == "3":
                self.common.log("Using MMA")
                stream_port = "5545"

            stream_type = "http"
            chan_template = "%s://%s:%s/view/ch%s%s.stream/playlist.m3u8?u=%s&p=%s"
            url = chan_template % (stream_type, server, stream_port, chan, quality, uname, pword)
            url += '|' + urllib.urlencode({'User-Agent': sys.modules["__main__"].plugin})

        if self.scheduler.use_cache:
            channel_name, playing_now, playing_next = self.cache.cacheFunction(self.scheduler.getChanInfo, self.scheduler.getNow(1000))
        else:
            channel_name, playing_now, playing_next = self.getChanInfo()

        name = "#" + chan

        if chan in channel_name:
            name = "#" + self.safeDecodeUnicode(channel_name[chan])

        if chan in playing_now:
            name += " - Now: " + self.safeDecodeUnicode(playing_now[chan])

        if chan in playing_next:
            if chan not in playing_now or playing_next[chan] != playing_now[chan]:
                name += " - Next: " + self.safeDecodeUnicode(playing_next[chan])

        self.common.log("Done")
        return (name, url)

    def playChan(self, params={}):
        self.common.log("")
        get = params.get
        (name, url) = self.getChanUrl(params)
        downloader_settings = self.xbmcaddon.Addon(id='script.module.simple.downloader')
        turl = self.xbmc.translatePath(downloader_settings.getAddonInfo("profile")) + u"live" + get("chan") + ".avi"
        if self.xbmcvfs.exists(turl):
            self.common.log("Found local live stream: " + turl)
            url = turl

        self.common.log("Playing: " + url)
        listitem = self.xbmcgui.ListItem(name, path=url)
        # listitem.setInfo(type='Video', infoLabels=video)
        self.xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listitem)
        
        self.common.log("Done")

    def download(self, params={}):
        self.common.log("")
        get = params.get
        filename = self.common.getUserInput(self.language(30104))
        minutes = self.common.getUserInputNumbers(self.language(30105))
        if not minutes:
            self.common.log("No duration set")
            return None

        (name, url) = self.getChanUrl(params)

        if len(url) > 10:
            if not self.settings.getSetting("download_path"):
                self.showMessage(self.language(30600), self.language(30601))
                self.settings.openSettings()

            download_path = self.settings.getSetting("download_path")

            if download_path:
                video = {"live": "true",
                         "url": url,
                         "download_path": download_path,
                         "duration": int(minutes) * 60,
                         "Title": filename,
                         "flashVer": "SmoothStreams (15,0,8,208)"
                         }

                if filename.find(".") == -1:
                    self.common.log("Adding .avi to filename")
                    filename += ".avi"

                if get("async"):
                    self.downloader.download(filename, video, async=False)
                else:
                    self.downloader.download(filename, video)

        self.common.log("Done")

    def stopDownload(self, params={}):
        self.common.log("")
        get = params.get
        self.downloader._stopCurrentDownload()
        self.settings.setSetting("download_and_playing", "")
        downloader_settings = self.xbmcaddon.Addon(id='script.module.simple.downloader')
        turl = self.xbmc.translatePath(downloader_settings.getAddonInfo("profile")) + u"live" + get("chan") + ".avi"
        if self.xbmcvfs.exists(turl):
            self.common.log("Found local live stream, moving to downloads: " + turl)
            url = turl
            self.common.log("Found local live stream, moving to downloads: " + self.settings.getSetting("download_path"))

        self.common.log("Done")

    def downloadAndPlay(self, params={}):
        self.common.log("")
        get = params.get
        #filename = self.common.getUserInput(self.language(30104))
        filename = u"live" + get("chan")

        downloader_settings = self.xbmcaddon.Addon(id='script.module.simple.downloader')

        (name, url) = self.getChanUrl(params)

        if len(url) > 10:
            if not self.settings.getSetting("download_path"):
                self.showMessage(self.language(30600), self.language(30601))
                self.settings.openSettings()

            download_path = self.settings.getSetting("download_path")

            if download_path:
                video = {"live": "true",
                         "url": url,
                         "download_path": download_path,
                         "Title": filename,
                         "flashVer": "SmoothStreams (15,0,8,208)"
                         }

                if filename.find(".avi") == -1:
                    self.common.log("Adding .avi to filename")
                    filename += ".avi"

                url = self.xbmc.translatePath(downloader_settings.getAddonInfo("profile")) + filename
                if not self.xbmcvfs.exists(url):
                    self.downloader.download(filename, video)
                    self.settings.setSetting("download_and_playing", "true")

                size = 0
                start = time.time()
                while size < 1024 * 1024 * 10:
                    self.common.log(u"Waiting for %s to buffer: %s" % (url, str(size)))
                    time.sleep(1)
                    try:
                        size = os.path.getsize(url)
                    except:
                        pass
                    if start + 120 < time.time():
                        break

                listitem = self.xbmcgui.ListItem(name, path=url)
                #listitem.setInfo(type='Video', infoLabels=video)
                listitem.setProperty("Video", "true")
                listitem.setProperty("IsPlayable", "true")
                self.common.log(u"Starting playback of: %s - %s" % (sys.argv[1], url))
                #self.xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listitem)
                #self.xbmcplugin.setResolvedUrl(handle=0, succeeded=True, listitem=listitem)
                #self.xbmcplugin.setResolvedUrl(handle=1, succeeded=True, listitem=listitem)
                player = self.xbmc.Player()
                while player.isPlaying():
                    time.sleep(1)
                self.common.log(u"Playback of %s stopped. Stopping download." % (url))
                #self.xbmcvfs.delete(url)

        self.common.log("Done")

    def makeMain(self):
        self.common.log("")
        size = 3

        url = sys.argv[0] + "?path=/root/channels"
        listitem = self.xbmcgui.ListItem(self.language(30100))
        listitem.setProperty("Folder", "true")
        self.common.log("Channels url: %s, handle: %s" % (url, sys.argv[1]))
        self.xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, isFolder=True, totalItems=size)

        url = sys.argv[0] + "?path=/root/schedules"
        listitem = self.xbmcgui.ListItem(self.language(30102))
        listitem.setProperty("Folder", "true")
        self.common.log("Schedules url: %s, handle: %s" % (url, sys.argv[1]))
        self.xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, isFolder=True, totalItems=size)

        url = sys.argv[0] + "?path=/root&action=settings"
        listitem = self.xbmcgui.ListItem(self.language(30200))
        listitem.setProperty("Folder", "true")
        self.common.log("Settings url: %s, handle: %s" % (url, sys.argv[1]))
        self.xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=listitem, isFolder=True, totalItems=size)

        self.xbmcplugin.endOfDirectory(handle=int(sys.argv[1]), succeeded=True, cacheToDisc=False)
        self.common.log("Done")

    def login(self):
        self.common.log("")
        service = int(self.settings.getSetting("service"))
        if service == 3:
            url = "http://www.mma-tv.net/loginForm.php"
        elif service == 2:
            url = "http://starstreams.tv/t.php"
        else:
            url = "http://smoothstreams.tv/login.php"

        uname = self.settings.getSetting("username")
        pword = self.settings.getSetting("user_password")

        post_data = {"username": uname, "password": pword, "site": ["mystreams", "live247", "starstreams", "mma-tv"][service]}
        result = self.common.fetchPage({"link": url, "post_data": post_data, "refering": url, "hide_post_data": "true"})

        try:
            result = json.loads(result["content"])
            if "id" in result and "password" in result:
                self.common.log("login result: " + repr(result))
                self.settings.setSetting("SUserN", str(result["id"]))
                self.settings.setSetting("SPassW", result["password"])
                self.common.log("Login complete")
                return True
        except Exception as e:
            self.common.log("Error parsing login result: " + repr(e) + " - " + repr(result))

        if "error" in result:
            self.showMessage(self.language(30600) + " " + self.language(30603), result["error"])
        else:
            self.showMessage(self.language(30600), self.language(30603))

        self.common.log("Login failure: " + repr(result))
        return False

    def averageList(self, lst):
        self.common.log(repr(lst), 5)
        avg_ping = 0
        avg_ping_cnt = 0
        for p in lst:
            try:
                avg_ping += float(p)
                avg_ping_cnt += 1
            except:
                self.common.log("Couldn't convert %s to float" % repr(p))
        self.common.log("Done", 5)
        return avg_ping / avg_ping_cnt

    def testServers(self, update_settings=False):
        self.common.log("")
        self.common.log("Original server: " + self.servers[int(self.settings.getSetting("server"))] + " - " + self.settings.getSetting("server"))
        res = ""
        ping = False
        for i, server in enumerate(self.servers):
            ping_results = False
            try:
                if self.xbmc.getCondVisibility('system.platform.windows'):
                    p = subprocess.Popen(["ping", "-n", "4", server], stdout=subprocess.PIPE, stderr=subprocess.PIPE, shell=True)
                else:
                    p = subprocess.Popen(["ping", "-c", "4", server], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                ping_results = re.compile("time=(.*?)ms").findall(p.communicate()[0])
            except:
                self.common.log("Platform doesn't support ping. Disable auto server selection")
                self.settings.setSetting("auto_server", "false")

            if ping_results:
                self.common.log("Server %s - %s: n%s" % (i, server, repr(ping_results)))
                avg_ping = self.averageList(ping_results)
                if avg_ping != 0:
                    if avg_ping < ping or not ping:
                        res = server
                        ping = avg_ping
                        if update_settings:
                            self.common.log("Updating settings")
                            self.settings.setSetting("server", str(i))
                else:
                    self.common.log("Couldn't get ping")
        self.common.log("Done %s: %s" % (res, ping))
        return res


    def showMessage(self, heading, message):
        #duration = ([1, 2, 3, 4, 5, 6, 7, 8, 9, 10][int(self.settings.getSetting('notification_length'))]) * 1000
        duration = 5
        self.xbmc.executebuiltin('XBMC.Notification("%s", "%s", %s)' % (heading, message, duration))

    def getXBMCVersion(self):
        self.common.log("", 3)
        version = self.xbmc.getInfoLabel( "System.BuildVersion" )
        self.common.log(version, 3)
        for key in ["-", " "]:
            if version.find(key) -1:
                version = version[:version.find(key)]
        version = float(version)
        self.common.log(repr(version))
        return version

    def navigation(self, params):
        params = self.common.getParameters(params)
        get = params.get

        self.common.log(repr(params))

        if get("path") == "/root/channels":
            self.makeChannelList()
        elif get("path") == "/root/schedules":
            self.scheduler.makeListOfSchedules()
        elif get("action") == "settings":
            self.settings.openSettings()
            if self.settings.getSetting("username") != "" and self.settings.getSetting("user_password") != "":
                self.login()
        elif get("action") == "login":
            self.login()
        elif get("action") == "play_channel":
            self.playChan(params)
        elif get("action") == "download_and_play":
            self.downloadAndPlay(params)
        elif get("action") == "stop_download":
            self.stopDownload(params)
        elif get("action") == "download":
            self.download(params)
        elif get("schedule") != None:
            self.scheduler.getSchedule(params)

        self.common.log("Done")
