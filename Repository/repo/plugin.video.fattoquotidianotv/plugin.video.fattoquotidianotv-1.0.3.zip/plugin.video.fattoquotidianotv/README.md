plugin.video.fattoquotidianotv
=================

Kodi unofficial plugin for Il Fatto Quotidiano TV (tested on Kodi 15.2 Isengard).
