# -*- coding: utf-8 -*-
from .lib.funimation import Funimation
