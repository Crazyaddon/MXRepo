#!/usr/bin/python
# -*- coding: latin-1 -*-

import sys, xbmc
import xbmc,xbmcplugin
import xbmcgui
import sys
import urllib, urllib2
import time
import re
from htmlentitydefs import name2codepoint as n2cp
import httplib
import urlparse
from os import path, system
import socket
from urllib2 import Request, URLError, urlopen
from urlparse import parse_qs
from urllib import unquote_plus

thisPlugin = int(sys.argv[1])
addonId = "plugin.video.filma24-al"
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
if not path.exists(dataPath):
       cmd = "mkdir -p " + dataPath
       system(cmd)
       
#Host = "http://www.filma24-al.com/movie-genre/aventure/"
def getUrl(url):
        pass#print "Here in getUrl url =", url
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link
	
def showContent():
        names = []
        urls = []
        names.append("Aksion")
        urls.append("http://www.filma24-al.com/movie-genre/aksion/")
        names.append("Aventure")
        urls.append("http://www.filma24-al.com/movie-genre/aventure/")
        names.append("Fantazi")
        urls.append("http://www.filma24-al.com/movie-genre/fantazi/")
        names.append("Drame")
        urls.append("http://www.filma24-al.com/movie-genre/drame/")
        names.append("Horror")
        urls.append("http://www.filma24-al.com/movie-genre/horror/")
        names.append("Hindi")
        urls.append("http://www.filma24-al.com/movie-genre/hindi/")
        names.append("Komedi")
        urls.append("http://www.filma24-al.com/movie-genre/komedi/")
        names.append("Krim")
        urls.append("http://www.filma24-al.com/movie-genre/krim/")
        names.append("Romance")
        urls.append("http://www.filma24-al.com/movie-genre/romance/")
        names.append("Thriller")
        urls.append("http://www.filma24-al.com/movie-genre/thriller/")
    
        i = 0           
        for name in names:
                url = urls[i]
                i = i+1
                pic = " "
                addDirectoryItem(name, {"name":name, "url":url, "mode":2}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)

def getVideos(name1, urlmain):
        url = urlmain
	content = getUrl(url)
	pass#print "content A =", content

	regexvideo = 'div class="boxim.*?a href="(.*?)".*?Boxoffice\/timthumb.*?src=(.*?)\&amp.*?div class="btitle.*?title=".*?>(.*?)<'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "match =", match
        for url, pic, name in match:
                 ##pass#print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":5}, pic)
	name = "More videos"
	addDirectoryItem(name, {"name":name, "url":urlmain, "mode":3}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)	         
        
def getVideos2(name1, urlmain):
        url = urlmain + "page/2/"
	content = getUrl(url)
	pass#print "content B =", content

	regexvideo = 'div class="boxim.*?a href="(.*?)".*?Boxoffice\/timthumb.*?src=(.*?)\&amp.*?div class="btitle.*?title=".*?>(.*?)<'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "match =", match
        for url, pic, name in match:
                 ##pass#print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":5}, pic)
	name = "More videos"
	addDirectoryItem(name, {"name":name, "url":urlmain, "mode":4}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)	         
        	        		
def getVideos3(name1, urlmain):
        url = urlmain + "page/3/"
	content = getUrl(url)
	pass#print "content B1 =", content

	regexvideo = 'div class="boxim.*?a href="(.*?)".*?Boxoffice\/timthumb.*?src=(.*?)\&amp.*?div class="btitle.*?title=".*?>(.*?)<'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "match =", match
        for url, pic, name in match:
                 ##pass#print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":5}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)	         

def getVideos4(name, url):
    pass#print "In getVideos4 url A=", url
    content = getUrl(url)
    pass#print "content C =", content
    html = content
   
    html = html.replace('\n\r', '').replace('\r', '').replace('\n', '').replace('\\', '')
    children = []
    names = []
    pass#print "html =", html
    """
    if re.search('https://video.google.com/get_player', html):
        names.append("google")
        docId = re.compile('docid=(.+?)"').findall(html)[0]
        children.append('https://docs.google.com/file/d/' + docId + '/preview')

    if children is None or len(children) == 0:
            children = re.compile('<iframe src="(.+?)"').findall(html)
            if children is None or len(children) == 0:
                    children = re.compile('docs.google.com/file/d/(.+?)"').findall(html)[0]
            names = []
            i = 0
            for child in children:
                   i = i+1
                   names.append("option " + str(i)) 
                   

    pass#print "names =", names
    pass#print "children =", children
    i = 0
    """
    match = re.compile('<iframe src="(.+?)"').findall(html)
    name = "Filepup"
    url = (match[0])
    pic = " "
    pass#print "name =", name
    pass#print "url =", url
    addDirectoryItem(name, {"name":name, "url":url, "mode":6}, pic)
    n1 = html.find("shik7.png", 0)
    n2 = html.find("></p>", n1)
    html = html[n1:n2]
    pass#print "html B=", html
    regexvideo = 'a href="(.+?)".*?img src="(.+?)"'
    match = re.compile(regexvideo,re.DOTALL).findall(html) 
    pass#print "match B=", match
    for url, name in match:
           n3 = name.rfind("/")
           name = name[(n3+1):]
           name = name[:-5]
           pic = " "
           pass#print "name B=", name
           pass#print "url B=", url
           addDirectoryItem(name, {"name":name, "url":url, "mode":6}, pic)
    
    xbmcplugin.endOfDirectory(thisPlugin)

def getVideos5(name, url):
    pass#print "In getVideos5 name =", name
    pass#print "In getVideos5 url =", url
    if "filepup" in url:  
        content = getUrl(url)
        pass#print "content E1 =", content
        
        regexvideo = 'video id="FilePup_Stream.*?src="(.+?)"'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "match =", match
        stream_url = match[0]
        pass#print "stream_url =", stream_url
        playVideo(name, stream_url)
    else:
        content = getUrl(url)
        content = content.decode('utf8')
        pass#print "content E =", content
        regexvideo = 'window.location="(.+?)"'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
	url = match[0]
        import urlresolver
        stream_url = urlresolver.HostedMediaFile(url=url).resolve()
        pass#print "stream_url =", stream_url
        playVideo(name, stream_url)

def getVideos5X(name1, urlmain):
        url = urlmain + "/videos?p=5"
	content = getUrl(url)
	#pass#print "content B =", content

	regexvideo = 'thumb_container video.*?href="(.*?)" title="(.*?)">'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        ##pass#print "match =", match
        for url, name in match:
                 name = name.replace('"', '')
                 url = "http://www.deviantclip.com" + url
                 pic = " " 
                 ##pass#print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)

                
def playVideo(name, url):
           pass#print "Here in playVideo url =", url
           pic = "DefaultFolder.png"
           li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
           player = xbmc.Player()
           player.play(url, li)

std_headers = {
	'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
	'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'en-us,en;q=0.5',
}  

def addDirectoryItem(name, parameters={},pic=""):
    li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
    url = sys.argv[0] + '?' + urllib.urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)


def parameters_string_to_dict(parameters):
    ''' Convert parameters encoded in a URL to a dict. '''
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict

params = parameters_string_to_dict(sys.argv[2])
name =  str(params.get("name", ""))
url =  str(params.get("url", ""))
url = urllib.unquote(url)
mode =  str(params.get("mode", ""))
pass#print "name =", name
pass#print "url =", url

if not sys.argv[2]:
	ok = showContent()
else:
	if mode == str(2):
		ok = getVideos(name, url)	
	elif mode == str(3):
	        ok = getVideos2(name, url)
#		ok = playVideo(name, url)	
	elif mode == str(4):
		ok = getVideos3(name, url)	
	elif mode == str(5):
		ok = getVideos4(name, url)
	elif mode == str(6):
#	        ok = playVideo(name, url)
		ok = getVideos5(name, url)
	elif mode == str(7):
	        ok = playVideo(name, url)
		


































































