# Call behaviour - Music
__setting_key_music_action_on_call__			=	'music_action_on_call'
__setting_key_unmute_music__					=	'unmute_music'
__setting_key_play_music__						=	'play_music'
__setting_key_music_volume__					=	'music_volume'
__setting_key_reset_music_volume__				=	'reset_music_volume'

# Call behaviour - Video
__setting_key_video_action_on_call__			=	'video_action_on_call'
__setting_key_unmute_video__					=	'unmute_video'
__setting_key_play_video__						=	'play_video'
__setting_key_video_volume__					=	'video_volume'
__setting_key_reset_video_volume__				=	'reset_video_volume'

# Advanced
__setting_key_base_auth_enabled__				=	'base_auth_enabled'
__setting_key_username__						=	'username'
__setting_key_password__						=	'password'
__setting_key_port__							=	'port'