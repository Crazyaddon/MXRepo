plugin.video.myvevo
================


Kodi Addon for VEVO website

Version 2.0.12 website change
Version 2.0.9 Added bitrate selection
Version 2.0.8 Added Flat Icons
Version 2.0.7 json library fix for android
Version 2.0.6 Added Favorite Artists from Library, fixed search performance
Version 2.0.5 Rename Playlist and error handling
Version 2.0.4 Add Playlists, User Login and cleanup
Version 2.0.3 Added features, related vids, next page
Version 2.0.2 Fix for search
version 2.0.1 initial release

