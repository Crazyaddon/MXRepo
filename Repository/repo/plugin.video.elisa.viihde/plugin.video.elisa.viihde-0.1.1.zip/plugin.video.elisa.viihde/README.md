KODI/XBMC-plugin Elisa Viihteelle
=====

https://github.com/enyone/XBMC-Elisa-Viihde-plugin

Käyttää uutta beta.elisaviihde.fi rajapintaa https://github.com/enyone/elisaviihde kirjaston avulla.

Pluginin alkuperäinen toteuttaja: **zippoman**

Korjauksia ja muutoksia toteuttaneet: **purtsi**, **teerytko**, **anylonen**, **ottok**, **enyone**
