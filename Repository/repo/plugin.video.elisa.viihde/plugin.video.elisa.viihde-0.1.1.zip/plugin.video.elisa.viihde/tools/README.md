# Tools #

## Code formatting ##

Jotta koodin muotoilussa säilyisi joku roti, on se muotoiltava ennen kommitoimista tai sen yhteydessä.

Helpoiten homman saa hoidettua tekemällä lisäämällä gittiin pre-commit hookin, jossa ajetaan muuttuneille tiedostoille autopep8.

### Autopep8 ###

https://pypi.python.org/pypi/autopep8

### Git pre-commit hook ###

https://gist.github.com/temoto/6183235
