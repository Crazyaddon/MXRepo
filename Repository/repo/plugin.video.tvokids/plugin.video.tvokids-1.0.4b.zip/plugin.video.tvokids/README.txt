plugin.video.tvokids
================

Kodi Addon for TVO Kids Video website

Version 1.0.4 better images
Version 1.0.2 Fix subtitles setting text
Version 1.0.1 initial release

