plugin.video.metv
================

Kodi V2 Addon for MeTV website

Version 2.0.2 cleanup for release and website change
version 2.0.1 initial release

