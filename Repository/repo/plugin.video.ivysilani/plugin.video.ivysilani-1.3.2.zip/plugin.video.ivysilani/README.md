### iVysílání - Česká Televize

Doplněk pro přehrávání videí z archivu České televize i živého vysílání. Je založen na API, které využívá mobilní aplikace pro Android a nabízí přehrávání streamů pomocí protokolu HTTP Live Streaming. Zroveň je schopný pro video vybrat nejlepší dostupnou kvalitu.
