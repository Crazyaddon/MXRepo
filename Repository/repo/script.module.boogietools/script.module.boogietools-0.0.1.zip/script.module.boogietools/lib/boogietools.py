import urllib
import urllib2
import sys
import urlparse
import os

import xbmcaddon
import xbmcgui
import xbmc

import pytz
import time
import datetime
import pickle
import json
import os
from cookielib import LWPCookieJar, LoadError
from StringIO import StringIO
import gzip
import socket

import cloudfare
from external.unescape import unescape

ua="Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36"

class HeadRequest(urllib2.Request):
	def get_method(self):
		return "HEAD"

def get_page(url,encoding,ua=ua,query=None,referer=None,headers=None,data=None,timeout=5,range=None,head=False,tout=None,forcecookie=None):
	#load cookies
	cfile=os.path.join( addondir("script.module.boogietools"), 'resources', 'data', "cookie")
	cj=LWPCookieJar(cfile)
	if os.path.exists(cfile):
		try:
			cj.load()
		except LoadError:
			pass

	if not query is None:
		query=urllib.urlencode (dict ([k, v.encode('utf-8') if isinstance (v, unicode) else v] for k, v in query.items())) 
		url=url+"?"+query
	if not data is None:
		data=urllib.urlencode (dict ([k, v.encode('utf-8') if isinstance (v, unicode) else v] for k, v in data.items()))

	#change timeout
	if tout is None:
		tout=socket.getdefaulttimeout()
	
	header={'Accept-encoding':'gzip'}
	if not headers is None :
		for k,v in headers.iteritems():
			header[k]=v
	
	if not referer is None:
		header["Referer"]=referer
	
	header["User-Agent"]=ua

	if not forcecookie is None:
		cstr=""
		for k,v in forcecookie.iteritems():
			cstr+="%s=%s; "%(k,v)
		header["Cookie"]=cstr

	if head==True:
		req=HeadRequest(url,headers=header)
	else:
		if not range is None : headers["Range"]="bytes=%d-%d"%(range)
		req=urllib2.Request(url,data=data,headers=header)

	req = urllib2.Request(url, data, header)

	opener=urllib2.build_opener(urllib2.HTTPCookieProcessor(cj))

	response = cloudfare.ddos_open(opener, req, data,timeout=timeout)

	if not head and response.info().get('Content-Encoding') == 'gzip':
		buf = StringIO(response.read())
		f = gzip.GzipFile(fileobj=buf)
		stream = f.read()
	elif not head:
		stream=response.read()

	if head :
		return response

	if encoding is None:
		#binary data
		src=stream
	else:
		#unicode data
		src=unicode(unescape(stream.decode(encoding,"ignore")))

	try:
		cj.save()
	except:
		try:
			os.remove(cfile)
		except:
			pass

	return src
	
def link_to(page="root",args={}):
	query={}
	query["page"]=page
	query["args"]=args
	return sys.argv[0] + '?' + urllib.urlencode(query)

def link_from():
	p,h,u=sys.argv
	result=urlparse.parse_qs(u[1:])
	page=result.get("page",["root"])[0]
	args=eval(result.get("args",["None"])[0])
	return int(h),page,args

def init(plugin,dir=["resources","lib"]):
	addon = xbmcaddon.Addon(plugin)
	addon_dir = xbmc.translatePath( addon.getAddonInfo('path') )
	sys.path.append(os.path.join( addon_dir, *dir ) )

def localtime_from_timezone(datet,tz):
	event_time=pytz.timezone(tz).localize(datet,is_dst=True)
	utc_time=event_time.astimezone(pytz.utc)
	is_dst = time.daylight and time.localtime().tm_isdst > 0
	utc_offset = - (time.altzone if is_dst else time.timezone)
	return utc_time+datetime.timedelta(0,utc_offset)

def notify(head,mes):
	dialog=xbmcgui.Dialog().notification(head,mes)

def notify_error(e,silent=True):
	frm = inspect.trace()[-1]
	mod = inspect.getmodule(frm[0])
	modname = mod.__name__ if mod else frm[1]
	errtype= e.__class__.__name__
	if not silent:
		notify("ERROR","%s : %s"%(modname, errtype))
	print traceback.format_exc()

def initdirs(pname):
	addon = xbmcaddon.Addon(pname)
	addon_dir = xbmc.translatePath( addon.getAddonInfo('path') )
	sys.path.append(os.path.join( addon_dir, 'resources', 'lib' ) )

def addondir(pname):
	addon = xbmcaddon.Addon(pname)
	return xbmc.translatePath( addon.getAddonInfo('path') )

def setliprop(li,prop,val):
	if not isinstance(val,str):
		val=pickle.dumps(val)
	li.setProperty(prop,val)
	return li

def getliprop(li,prop):
	val=li.getProperty(prop)
	try:
		val=pickle.loads(val)
	except KeyError:
		pass
	except EOFError:
		pass
	return val

def setliprops(li,d):
	for k,v in d.iteritems():
		setliprop(li,k,v)

def getliprops(li,l):
	d={}
	for i in l:
		d[i]=getliprop(li,i)
	return d

def web_search(type,query):
	#type: web,images
	urls=[]
	query={"v":"1.0","q":query}
	j=json.loads(get_page("http://ajax.googleapis.com/ajax/services/search/%s"%type,"utf-8",query=query))
	status=j.get("responseStatus",0)
	if status==200:
		results=j["responseData"]["results"]
		for result in results:
			urls.append(result["unescapedUrl"])
	return urls

def obfus(s):
	news=""
	for c in s:
		news+=unichr((3*ord(c)+66)%65535)
	return news

def deobfus(s):
	news=""
	for c in s:
		news+=unichr(((ord(c)-66)/3)%65535)
	return news
