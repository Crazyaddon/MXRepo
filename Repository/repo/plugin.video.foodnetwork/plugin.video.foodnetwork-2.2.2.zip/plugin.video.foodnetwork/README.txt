plugin.video.cook
================

Kodi Addon for Cooking Channel website

V2.2.1 Initial version
V2.2.2 cleanup for release