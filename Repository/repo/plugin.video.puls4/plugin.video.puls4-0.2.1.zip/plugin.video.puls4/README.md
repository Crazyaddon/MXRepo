Puls4 XBMC Addon
=======
Puls4 is an addon that gives you access to the Puls4 Video Platform.


Requirements
------------
Tested on Gotham and KODI


Supported platforms
-------------------
Windows, Linux , Android and OSX


Current Features
----------------
* All Shows
* H264 Stream (HD/SD)
* Top Videos
* Highlights


Known Issues
------------
* None so far


Legal
-----
This addon gives you access to videos on the Puls4 Website but is not endorsed, certified or otherwise approved in any way by PULS 4 TV GmbH & Co KG
