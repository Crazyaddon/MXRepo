# plugin.video.heritagechannel
The Heritage Channnel - video addon for Kodi Helix (v14) / Isengard (v15). 
Videos from cultural, natural, scientific, academic, technical and other heritage organisations from across the world.

See also http://addons.kodi.tv/show/plugin.video.heritagechannel // http://kodi.wiki/view/Add-on:The_Heritage_Channel // http://forum.kodi.tv/showthread.php?tid=235754

How to install: http://kodicommunity.com/how-to-install-the-heritage-channel-on-kodi/

So far includes 70 insitutions:
1 Musée du Louvre,Paris
2 National Gallery,London
3 Metropolitan Museum of Art,New York City
4 Tate Modern,London
5 National Gallery of Art,Washington, D.C
6 Musée d'Orsay,Paris
7 Victoria and Albert Museum,London
8 Reina Sofía,Madrid
9 National Museum of Korea,Seoul
10 Rijksmuseum,Amsterdam
11 Amsterdam Museum,Amsterdam
12 Van Gogh Museum,Amsterdam
13 Stedelijk Museum,Amsterdam
14 Maritiem Museum,Rotterdam
15 Museum Boijmans Van Beuningen,Rotterdam
16 Gemeentemuseum,The Hague
17 Nationaal Archief,The Hague
18 Koninklijke Bibliotheek, national library of the Netherlands,The Hague
19 Beeld en Geluid, Institute for Sound and Vision,Hilversum
20 Museum of Modern Art,New York
21 Guggenheim Museum,New York
22 American Museum of Natural History,New York
23 Smithsonian National Air and Space Museum, Washington, D.C
24 Smithsonian American Art Museum,Washington, D.C.
25 J. Paul Getty Museum,Los Angeles
26 Art Institute of Chicago,Chicago
27 Portland Museum of Art,Portland, Maine
28 The British Museum,London
29 British Library,London
30 Natural History Museum,London
31 Museo del Prado,Madrid
32 Museo Thyssen-Bornemisza,Madrid
33 Museu Picasso,Barcelona
34 National Gallery of Ireland,Dublin
35 Kunsthistorisches Museum,Vienna
36 Somerset House, London
37 National Portrait Gallery, London
38 National Museums of Scotland, Edinburgh
39 Fine Arts Museums of San Francisco
40 Saatchi Gallery, London
41 Grand Palais, Paris
42 Tokyo National Museum, Tokyo
43 Dali Theatre and Museum, Figueres
44 Musée du quai Branly, Paris
45 Australian Centre for the Moving Image, Melbourne
46 Queensland Art Gallery | Gallery of Modern Art, Brisbane
47 Mori Art Museum, Tokyo
48 Los Angeles County Museum of Art, Los Angeles
49 Institut Valencià d'Art Modern, Valencia
50 Art Gallery of New South Wales, Sydney
51 Museum of Fine Arts, Boston
52 Acropolis Museum, Athens
53 Smithsonian National Portrait Gallery, Washington DC 
54 Glasgow Museums, Glasgow
55 Royal Academy of Arts, London 
56 Montreal Museum of Fine Arts, Montreal 
57 Museum of Liverpool, Liverpool
58 The Israel Museum, Jerusalem 
59 Belvedere Palace and Museum, Vienna
60 Royal Ontario Museum, Toronto 
61 Serpentine Galleries, London 
62 National Museums in Berlin | Staatlichen Museen zu Berlin
63 Musée de l'Orangerie, Paris 
64 Museum of Contemporary Art  Australia, Sydney 
65 Art Gallery of Ontario, Toronto
66 Museum of Fine Arts, Houston 
67 Melbourne Museum | Museum Victoria, Melbourne
68 Musée du Louvre-Lens, Paris
69 National Gallery of Australia, Canberra 
70 Ashmolean Museum, Oxford 

