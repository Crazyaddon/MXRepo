# -*- coding: utf-8 -*-
'''
kinkin
'''

import urllib,urllib2,re,xbmcplugin,xbmcgui,os,gzip
import requests
import settings
import time,datetime
from datetime import date, timedelta,datetime
from common import notification, get_url, regex_get_all, regex_from_to, create_directory, write_to_file, read_from_file, clean_file_name, get_file_size, wait, wait_dl_only
from threading import Timer
from meta import TheTVDBInfo
from hashlib import md5
from helpers import clean_file_name
from furk import FurkAPI
import json
import glob
import shutil
from threading import Thread
import cookielib
from t0mm0.common.net import Net
from helpers import clean_file_name
from metahandler import metahandlers
import hashlib
s = requests.session()

metainfo = metahandlers.MetaData()
net = Net()

LIBRARY_FORMAT = settings.lib_format()
ADDON = settings.addon()
SC_FURK=True
SHOW_FANART = settings.use_fanart()
UNAIRED = settings.show_unaired()
FURK_ACCOUNT = settings.furk_account()
FURK_USER = settings.furk_user()
FURK_PASS = settings.furk_pass()
FURK_SORT = settings.furk_sort()
FURK_RESULTS = settings.furk_results()
FURK_MODERATED = settings.furk_moderated()
FURK_LIM_FS = settings.furk_limit_file_size()
FURK_LIM_FS_NUM = settings.furk_limit_fs_num()
FURK_LIM_FS_MIN = settings.furk_limit_fs_min()
FURK_LIM_FS_TV = settings.furk_limit_file_size_tv()
FURK_LIM_FS_NUM_TV = settings.furk_limit_fs_num_tv()
IMDB_LIST1 = settings.imdb_list1()
IMDB_LIST2 = settings.imdb_list2()
IMDB_LIST3 = settings.imdb_list3()
IMDB_LIST4 = settings.imdb_list4()
IMDB_LIST5 = settings.imdb_list5()
IMDB_LIST6 = settings.imdb_list6()
IMDB_LIST7 = settings.imdb_list7()
IMDB_LIST8 = settings.imdb_list8()
IMDB_LIST9 = settings.imdb_list9()
IMDB_LIST10 = settings.imdb_list10()
IMDB_LISTNAME1 = settings.imdb_listname1()
IMDB_LISTNAME2 = settings.imdb_listname2()
IMDB_LISTNAME3 = settings.imdb_listname3()
IMDB_LISTNAME4 = settings.imdb_listname4()
IMDB_LISTNAME5 = settings.imdb_listname5()
IMDB_LISTNAME6 = settings.imdb_listname6()
IMDB_LISTNAME7 = settings.imdb_listname7()
IMDB_LISTNAME8 = settings.imdb_listname8()
IMDB_LISTNAME9 = settings.imdb_listname9()
IMDB_LISTNAME10 = settings.imdb_listname10()
NEWMOVIE_DAYS = settings.newmovie_days()
CUSTOMQUALITY = settings.custom_quality()
TVCUSTOMQUALITY = settings.tvcustom_quality()
NUM_VOTES = settings.imdb_filter_votes()
IMDB_RESULTS = settings.imdb_results()
ONECLICK_SEARCH = settings.oneclick_search()
QUALITYSTYLE = settings.qualitystyle()
QUALITYSTYLE_TV = settings.qualitystyle_tv()
PREFERRED2 = settings.preferred2()
CUSTOMQUALITY2 = settings.custom_quality2()
TVPREFERRED2 = settings.preferred_tv2()
TVCUSTOMQUALITY2 = settings.tvcustom_quality2()
DOWNLOAD_MOVIES = settings.movies_download_directory()
DOWNLOAD_TV = settings.tv_download_directory()
DOWNLOAD_TEMP = settings.temp_download_directory()
DOWNLOAD_MUSIC = settings.music_download_directory()
DOWNLOAD_SPEED = settings.download_speed()
DOWNLOAD_SUB = settings.download_subtitles()
TRAILER_RESTRICT = settings.restrict_trailer()
TRAILER_QUALITY = settings.trailer_quality()
TRAILER_ONECLICK = settings.trailer_one_click()
ENABLE_SUBS = settings.subscription_update()
ENABLE_META = settings.download_meta()
TV_PATH = settings.tv_show_directory()
MOVIE_PATH = settings.movies_directory()
SHOW_SPECIALS = settings.show_special()
FAV = settings.favourites_file()
FAV_TV = settings.favourites_TV_file()
FAV_PEOPLE = settings.people_list()
FAV_ARTISTS = settings.favourites_artists_file()
FAV_ALBUMS = settings.favourites_albums_file()
IMDB_URL=settings.imdb_search_url()
IMDB_LIST_URL=settings.imdb_list_url()
IMDB_WL_URL=settings.imdb_watchlist_url()
SUB = settings.subscription_file()
cookie_jar = settings.cookie_jar()
FURK = FurkAPI(cookie_jar)
addon_path = os.path.join(xbmc.translatePath('special://home/addons'), '')
fanart = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.whatthefurk', 'fanart.jpg'))
iconart = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.whatthefurk', 'icon.png'))
artf = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.whatthefurk', 'art'))
art = xbmc.translatePath(os.path.join('special://home/addons/plugin.video.whatthefurk', ''))
CACHE_PATH = settings.cache_path()
from_date = (date.today() + timedelta(1))
to_date = (from_date + timedelta(30))
d = (date.today() - timedelta(days=180))
releasedate = "%s,%s" % (d,from_date)
TVDB_KEY = '63AFB061FABE358C'
dialog = xbmcgui.Dialog()
quality_list = ["Custom Search","Any", "3D", "1080P", "720P", "HDTV", "DVDSCR", "SCREENER", "BDRIP", "BRRIP", "BluRay 720P", "BluRay 1080P", "DVDRIP", "R5", "TELESYNC", "TS", "CAM"]
quality_list_return = ["customsearch","", "3D","1080P", "720P", "HDTV", "DVDSCR", "SCREENER", "BDRIP", "BRRIP", "BluRay 720P", "BluRay 1080P", "DVDRIP", "R5", "TELESYNC", "TS", "CAM"]
quality_list_tv = ["Custom Search","Any", "Season Search", "1080P", "720P", "HDTV", "DVDSCR", "SCREENER", "BDRIP", "BRRIP", "BluRay 720P", "BluRay 1080P", "DVDRIP", "R5", "TELESYNC", "TS", "CAM"]
quality_list_return_tv = ["customsearch","", "seasonsearch","1080P", "720P", "HDTV", "DVDSCR", "SCREENER", "BDRIP", "BRRIP", "BluRay 720P", "BluRay 1080P", "DVDRIP", "R5", "TELESYNC", "TS", "CAM"]
comingsoon = "%s,%s" % (from_date, to_date)
releasetext = " [COLOR gold](released from %s)[/COLOR]" % d
soontext = "[COLOR gold] (%s to %s)[/COLOR]" % (from_date, to_date)

trans_table = ''.join( [chr(i) for i in range(128)] + [' '] * 128 )

traktapi='f801f9d16b1d8d1ffbeaa306ceaed040ac1303883a0b9be27ac0838058e91eed'
def get_trakt(url,limit, cache_time=7200):
    header_dict = {}
    header_dict['Content-Type'] = 'application/json'
    header_dict['trakt-api-key'] = traktapi
    header_dict['trakt-api-version'] = '2'
    url = 'http://api-v2launch.trakt.tv/%s&limit=%s' % (url, limit)
    h = hashlib.md5(url).hexdigest()
    cache_file = os.path.join(CACHE_PATH, h)
    age = get_file_age(cache_file)
    if age > 0 and age < cache_time:
        r = read_from_file(cache_file, silent=True)
        if r:
            return r
    else:
        req = net.http_GET(url, headers=header_dict).content.encode("utf-8").translate(trans_table)
        write_to_file(cache_file, req)
        return req


def get_file_age(file_path):
    try:    
        stat = os.stat(file_path)
        fileage = datetime.fromtimestamp(stat.st_mtime)
        now = datetime.now()
        delta = now - fileage
        return delta.seconds
    except:
        return -1

def open_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent','Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.93 Safari/537.36')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    return link
	
def login_at_furk():
    if FURK_ACCOUNT:
        if FURK.login(FURK_USER, FURK_PASS):
            return True
        else:
            dialog = xbmcgui.Dialog()
            dialog.ok("Login failed", "The addon failed to login at Furk.net.", "Make sure you have confirmed your email and your", "login information is entered correctly in addon-settings")
            return False
    else:
        return False

def MENU(name):
    addDir("Movies", 'url',100,os.path.join(artf, 'movies.png'), 'blank','blank','','','','')
    addDir("TV Shows", 'url',200,os.path.join(artf, 'tvshows.png'), 'blank','blank','','','','')
    addDir("Music", 'url',300,os.path.join(artf, 'music.png'), 'blank','blank','','','','')
    addDir("Furk", 'url',500,os.path.join(artf, 'furk.png'), 'blank','blank','','','','')
    addDir("My People", 'url',600,os.path.join(artf, 'mypeople.png'), 'blank','blank','','','','')
    addDir("IMDB Watchlists", 'url',700,os.path.join(artf, 'imdbwatchlists.png'), 'blank','blank','','','','')
    addDir("TV Subscriptions", 'url',750,os.path.join(artf, 'tvsubscriptions.png'), 'blank','blank','','','','')
    addDir("Favourites", 'url',800,os.path.join(artf, 'favourites.png'), 'blank','blank','','','','')
    addDir("Maintenance", 'url',900,os.path.join(artf, 'maintenance.png'), 'blank','blank','','','','')

def movie_menu(name):
    addDir("Top Movies", 'imdb',101,os.path.join(artf, 'topmovies.png'), 'boxoffice_gross_us,desc',',','1','<><><><><>feature,documentary,tv_movie<><>released','moviemenu')
    addDir("New Movies" + releasetext, 'imdb',101,os.path.join(artf, 'newmovies.png'), 'release_date_us,desc',releasedate,'1','<><><><><>feature,documentary,tv_movie<><>released','moviemenu')
    addDir("Coming Soon" + soontext, 'imdb',101,os.path.join(artf, 'comingsoon.png'), 'release_date_us',comingsoon,'1','<><><><><>feature,documentary,tv_movie<><>released', 'moviemenu')
    addDir("DVD Releases", 'imdb',120,os.path.join(artf, 'dvdreleases.png'), 'blank','blank','','','moviemenu')
    addDir("Trending Movies", 'movies/trending?extended=images&page=',130,os.path.join(artf, 'trending.png'), 'blank','blank','1','','moviemenu')
    addDir("Most Popular", 'movies/popular?extended=images&page=',130,os.path.join(artf, 'mostpopular.png'), 'blank','blank','1','','moviemenu')
    addDir("Most Played Last 7 Days", 'movies/played/weekly?extended=images&page=',130,os.path.join(artf, 'mostplayed7.png'), 'blank','blank','1','','moviemenu')
    addDir("Most Played Last 30 Days", 'movies/played/monthly?extended=images&page=',130,os.path.join(artf, 'mostplayed30.png'), 'blank','blank','1','','moviemenu')
    addDir("Movies by MPAA Rating", 'imdb',104,os.path.join(artf, 'mpaa.png'), 'blank','blank','1','','moviemenu')
    addDir("Movies by Genre", 'imdb',105,os.path.join(artf, 'genre.png'), 'blank','blank','1','','moviemenu')
    addDir("Movies by Group", 'imdb',106,os.path.join(artf, 'group.png'), 'blank','blank','1','','moviemenu')
    addDir("Movies by Studio", 'imdb',107,os.path.join(artf, 'studio.png'), 'blank','blank','1','','moviemenu')
    addDir("Scene Releases", 'nzb',108,os.path.join(artf, 'scene.png'), 'blank','blank','1','<><><><>','moviemenu')
    addDir("Search Movies", 'imdb',1500,os.path.join(artf, 'search.png'), 'blank','blank','1','','moviemenu')
	
def scene_releases_menu():
    addDir("Top Downloads - This Week", 'http://www.nzbmovieseeker.com/Toplists/',109,os.path.join(artf, 'topdownloads-thisweek.png'), 'blank','blank','1','<><><><>','moviemenu')
    addDir("Top Downloads - This Month", 'http://www.nzbmovieseeker.com/Toplists/Downloads/Month/',109,os.path.join(artf, 'topdownloads-thismonth.png'), 'blank','blank','1','<><><><>','moviemenu')
    addDir("Top Downloads - This Year", 'http://www.nzbmovieseeker.com/Toplists/Downloads/Year/',109,os.path.join(artf, 'topdownloads-thisyear.png'), 'blank','blank','1','<><><><>','moviemenu')
    addDir("Most Requested", 'http://www.nzbmovieseeker.com/Toplists/Watchlist/',109,os.path.join(artf, 'mostrequested.png'), 'blank','blank','1','<><><><>','moviemenu')

def scene_releases_list(url):
    infoLabels = None
    dp = xbmcgui.DialogProgress()
    dp.create("What the Furk",'Getting titles')
    dp.update(0)
    body = get_url(url, cache=CACHE_PATH)
    all_tr = regex_get_all(body, '<div class="release-wrapper">', '<div class="plot">')
    nItem = len(all_tr)
    count = 0
    for tr in all_tr:
        all_td = regex_get_all(tr, '<h3>', '</h3>')
        imdb_id = 'tt' + regex_from_to(all_td[0], 'NZB/', '-')
        name = regex_from_to(all_td[0], 'title">', '<').replace(':',' ')
        thumb = regex_from_to(tr,'<img src="', '"')
        try:
            splitname =name.split(' (')
            name = splitname[0]
            year = splitname[1].replace(')','')
        except:
            name = name
            year = ''
        if ENABLE_META:
            infoLabels = get_meta(clean_file_name(name),'movie',year)
            if infoLabels['title']=='':
                 name="%s (%s)" % (clean_file_name(name),year)
            else:
                name="%s (%s)" % (clean_file_name(infoLabels['title']),year)
            if infoLabels['cover_url']=='':
                iconimage=thumb
            else:
                iconimage=infoLabels['cover_url']
        else:
            name="%s (%s)" % (clean_file_name(name),year)
            iconimage=thumb
        count = count + 1
        titlelist = str(count) + ' of ' + str(nItem) + ': ' + name
        progress = count / float(nItem) * 100               
        dp.update(int(progress), 'Adding title',titlelist)
        if dp.iscanceled():
            return
        addDir(clean_file_name(name),'nzb',1000,iconimage, clean_file_name(name),imdb_id,'','','movies',infoLabels=infoLabels)

def dvd_release_menu():
    now = datetime.now()
    currentyear = now.year
    currentmonth = now.month
    url = 'http://www.ondvdreleases.com/new-dvd-releases-'
    month_list = ["01-January","02-February", "03-March", "04-April", "05-May", "06-June", "07-July", "08-August", "09-September", "10-October", "11-November", "12-December"]
    year_list = ["2020","2019","2018","2017","2016","2015","2014", "2013", "2012", "2011", "2010"]
    for y in year_list:
        if int(y)<=int(currentyear) or (int(y)==int(currentyear)+1 and int(currentmonth)==12):
            addDirPlayable('[COLOR gold]' + y + ' DVD Releases[/COLOR]', 'url',9999,os.path.join(artf, y + 'dvdreleases.png'), 'blank','','','','')
            for m in month_list:
                mn=m.split('-')[0]
                url='http://www.ondvdreleases.com/new-dvd-releases-%s-%s/' % (y,mn)
                title=m
                addDir(title,url,121,os.path.join(artf, title.lower() + '.png'), 'blank','blank','','','na')
		
def dvd_release_results(name,url,iconimage):
    infoLabels = None
    dp = xbmcgui.DialogProgress()
    dp.create("What the Furk",'Getting titles')
    dp.update(0)
    body = get_url(url, cache=CACHE_PATH).replace('\t','').replace('\n','').replace('&#039;',"'").translate(trans_table)
    match = re.compile('<div class="mtitle"><a href="(.+?)" class="tit">(.+?)</a></div>').findall(body)
    #match = re.compile('<h3><a href="(.+?)" class="tit">(.+?)</a> [(](.+?)[)]</h3>').findall(body)
    nItem = len(match)
    count = 0
    for di,title in match:
    #for di,title,year in match:
            name = title
            thumb=''
            count = count + 1
            titlelist = str(count) + ' of ' + str(nItem) + ': ' + name
            progress = count / float(nItem) * 100               
            dp.update(int(progress), 'Adding title',titlelist)
            if dp.iscanceled():
                return
            infoLabels = get_meta(clean_file_name(name),'movie',"")
            imdb=infoLabels['imdb']
            if infoLabels['title']=='':
                 name="%s (%s)" % (clean_file_name(name),"0000")
            else:
                name="%s (%s)" % (clean_file_name(infoLabels['title']),infoLabels['year'])
            if infoLabels['cover_url']=='':
                iconimage=thumb
            else:
                iconimage=infoLabels['cover_url']
            addDir(name, 'imdb',1000,iconimage, name,imdb,'1','','movies',infoLabels=infoLabels)
			
def trakt_movies(name,url,start):
    limit='10'
    origurl=url
    if start!='NA':
        url="%s%s" % (url,start)
        nextpage=int(start)+1
        limit='50'
    dp = xbmcgui.DialogProgress()
    dp.create("What the Furk",'Getting titles') 
    dp.update(0)

    body=get_trakt(url,limit)
    data=json.loads(body)
    nItem=int(limit)
    count = 0
    for i in data:
        try:
            name = i['movie']['title']
            year = i['movie']['year']
            traktid = i['movie']['ids']['trakt']
            imdb_id = i['movie']['ids']['imdb']
            slug = i['movie']['ids']['slug']
            if i['movie']['images']['poster']['thumb'] == None:
                thumb = i['movie']['images']['fanart']['thumb']
            else:
                thumb = i['movie']['images']['poster']['thumb']
        except:
            name = i['title']
            year = i['year']
            traktid = i['ids']['trakt']
            imdb_id = i['ids']['imdb']
            slug = i['ids']['slug']
            try:
                if i['images']['poster']['thumb'] == None:
                    thumb = i['images']['fanart']['thumb']
                else:
                    thumb = i['images']['poster']['thumb']
            except:
                thumb=iconart
        count = count + 1
        titlelist = str(count) + ' of ' + str(nItem) + ': ' + name
        progress = count / float(nItem) * 100               
        dp.update(int(progress), 'Adding title',titlelist)
        if dp.iscanceled():
            return
        if ENABLE_META:
            infoLabels = get_meta(clean_file_name(name),'movie',str(year))
            imdb=infoLabels['imdb']
            if infoLabels['title']=='':
                name="%s (%s)" % (clean_file_name(name),year)
            else:
                name="%s (%s)" % (clean_file_name(infoLabels['title']),year)
            if infoLabels['cover_url']=='':
                iconimage=''
            else:
                iconimage=infoLabels['cover_url']
        else:
            infoLabels = None
            if thumb==None:
                iconimage=iconart
            else:
                iconimage=thumb
            imdb=imdb_id
            name="%s (%s)" % (clean_file_name(name),year)
        addDir(name, 'imdb',1000,iconimage, name,imdb,'1','','movies',infoLabels=infoLabels)
    if start != 'NA':
        addDir(">> Next Page", origurl,130,'', 'blank','blank',str(nextpage),'','np')
    setView('movies', 'movies-view')

def trakt_shows(name,url,start):
    limit='10'
    origurl=url
    if start!='NA':
        url="%s%s" % (url,start)
        nextpage=int(start)+1
        limit='50'
    dp = xbmcgui.DialogProgress()
    dp.create("What the Furk",'Getting titles')
    dp.update(0)
    body=get_trakt(url,limit)
    data=json.loads(body)
    nItem=int(limit)
    count = 0
    thumb='na'
    for i in data:
        try:
            name = i['show']['title']
            year = i['show']['year']
            traktid = i['show']['ids']['trakt']
            imdb_id = i['show']['ids']['imdb']
            slug = i['show']['ids']['slug']
        except:
            name = i['title']
            year = i['year']
            traktid = i['ids']['trakt']
            imdb_id = i['ids']['imdb']
            slug = i['ids']['slug']
        count = count + 1
        titlelist = str(count) + ' of ' + str(nItem) + ': ' + name
        progress = count / float(nItem) * 100               
        dp.update(int(progress), 'Adding title',titlelist)
        if dp.iscanceled():
            return
        infoLabels = get_meta(name,'tvshow','',season=None,episode=None,imdb=None,episode_title=None)
        imdb=imdb_id
        if imdb=='' or imdb==None:
            imdb='na'
        if infoLabels['title']=='':
             name="%s (%s)" % (clean_file_name(name),year)
        else:
            name="%s (%s)" % (clean_file_name(infoLabels['title']),year)
        if infoLabels['cover_url']=='':
            iconimage=thumb
        else:
            iconimage=infoLabels['cover_url']
        addDir(name, imdb,210,iconimage, name,'','1','','tvshows',infoLabels=infoLabels)
    addDir(">> Next Page", origurl,230,'', 'blank','blank',str(nextpage),'','np')
    setView('tvshows', 'tvshows-view')

def movies_mpaas_menu():
    mpaas = ['G', 'PG', 'PG-13', 'R', 'NC-17']
    for mpaa in mpaas:
        mpaa1 = "%s:%s" % ("us",mpaa.lower().replace('-','_'))
        addDir(mpaa, 'imdb',102,os.path.join(artf, '%s.png' % mpaa.lower().replace('-','')), 'release_date_us,desc','b','1','<><><><>%s<>feature,documentary,tv_movie<><>released' % mpaa1,'moviemenu')
		
def movies_genres_menu():
    genres = ['Action', 'Adventure', 'Animation', 'Comedy', 'Crime', 'Documentary', 'Drama', 'Family',
              'Fantasy', 'History', 'Horror', 'Romance', 'Sci-Fi', 'Thriller', 'War', 'Western']
    for genre in genres:
        addDir(genre, 'imdb',102,os.path.join(artf, '%s.png' % genre.lower().replace('-','')), 'release_date_us,desc','b','1','%s<><><><><>feature,documentary,tv_movie<><>released' % genre,'moviemenu')

def movies_groups_menu():
    groups = ['Now Playing US', 'Oscar Winners', 'Oscar Nominees', 'Oscar Best Picture Winners', 'Oscar Best Director Winners',
          'Golden Globe Winners', 'Golden Globe Nominees', 'National Film Registry', 'Razzie Winners', 'Top 100', 'Bottom 100']
    for group in groups:
        addDir(group, 'imdb',102,os.path.join(artf, '%s.png' % group.lower().replace(' ','')), 'release_date_us,desc','b','1','<>%s<><><><>feature,documentary,tv_movie<><>released' % group,'moviemenu')
		
def movies_studios_menu():
    studios = ['Columbia', 'Disney', 'Dreamworks', 'Fox', 'Mgm', 'Paramount', 'Universal', 'Warner']
    for studio in studios:
        addDir(studio, 'imdb',102,os.path.join(artf, '%s.png' % studio.lower().replace('-','')), 'release_date_us,desc','b','1','<><>%s<><><>feature,documentary,tv_movie<><>released' % studio,'moviemenu')
		
def watchlists(name):
    addDir("My Movie Watchlist", IMDB_WL_URL,701,os.path.join(artf, 'imdbmovies.png'), 'blank','blank','1','','<><><><><>feature,documentary,tv_movie<><>released','moviemenu')
    addDir("My TV Watchlist", IMDB_WL_URL,701,os.path.join(artf, 'imdbtv.png'), 'blank','blank','1','','<><><><><>tv_series,tv_special,mini_series<><>released','tvshowsmenu')
    if IMDB_LIST1 != 'Enter the IMDB list code':
        addDir(IMDB_LISTNAME1, IMDB_LIST_URL + IMDB_LIST1,701,os.path.join(artf, 'imdb1.png'), 'blank','blank','1','','','')
    if IMDB_LIST2 != 'Enter the IMDB list code':
        addDir(IMDB_LISTNAME2, IMDB_LIST_URL + IMDB_LIST2,701,os.path.join(artf, 'imdb2.png'), 'blank','blank','1','','','')  
    if IMDB_LIST3 != 'Enter the IMDB list code':
        addDir(IMDB_LISTNAME3, IMDB_LIST_URL + IMDB_LIST3,701,os.path.join(artf, 'imdb3.png'), 'blank','blank','1','','','')  
    if IMDB_LIST4 != 'Enter the IMDB list code':
        addDir(IMDB_LISTNAME4, IMDB_LIST_URL + IMDB_LIST4,701,os.path.join(artf, 'imdb4.png'), 'blank','blank','1','','','')  
    if IMDB_LIST5 != 'Enter the IMDB list code':
        addDir(IMDB_LISTNAME5, IMDB_LIST_URL + IMDB_LIST5,701,os.path.join(artf, 'imdb5.png'), 'blank','blank','1','','','')  
    if IMDB_LIST6 != 'Enter the IMDB list code':
        addDir(IMDB_LISTNAME6, IMDB_LIST_URL + IMDB_LIST6,701,os.path.join(artf, 'imdb6.png'), 'blank','blank','1','','','')  
    if IMDB_LIST7 != 'Enter the IMDB list code':
        addDir(IMDB_LISTNAME7, IMDB_LIST_URL + IMDB_LIST7,701,os.path.join(artf, 'imdb7.png'), 'blank','blank','1','','','')  
    if IMDB_LIST8 != 'Enter the IMDB list code':
        addDir(IMDB_LISTNAME8, IMDB_LIST_URL + IMDB_LIST8,701,os.path.join(artf, 'imdb8.png'), 'blank','blank','1','','','')  
    if IMDB_LIST9 != 'Enter the IMDB list code':
        addDir(IMDB_LISTNAME9, IMDB_LIST_URL + IMDB_LIST9,701,os.path.join(artf, 'imdb9.png'), 'blank','blank','1','','','')  
    if IMDB_LIST10 != 'Enter the IMDB list code':
        addDir(IMDB_LISTNAME10, IMDB_LIST_URL + IMDB_LIST10,701,os.path.join(artf, 'imdb10.png'), 'blank','blank','1','','','')

def watchlist_menu(name,url,iconimage,sort, release, start,videotype,parms):
    origurl=url
    count = 0
    params = {}
    nstart = str(int(start) + 250)
    dp = xbmcgui.DialogProgress()
    dp.create("What the Furk",'Getting titles')
    dp.update(0)
    if name.startswith('My'):
        parsplit = parms.split('<>')
        ttype = parsplit[5]
        tname = parsplit[6]
        params["title_type"] = ttype
        params["start"] = start
        params["view"] = 'compact'
        url = "%s%s%s" % (url, urllib.urlencode(params),"&sort=listorian:asc")
    else:
        if 'shows' in name.lower():
            ttype='series'
        else:
            ttype='movies'
        url = "%s/?start=1&view=compact&sort=listorian:asc" % url
    body = get_url(url, cache=CACHE_PATH)
    all_tr = regex_get_all(body, '<tr data-item', '</tr>')
    nItem = len(all_tr)     
    for tr in all_tr:
        all_td = regex_get_all(tr, '<td', 'td>')
        imdb_id = regex_from_to(all_td[1], 'title/', '/')
        name = regex_from_to(all_td[1], '/">', '</a>')
        year = regex_from_to(all_td[2], 'year">', '</td>')
        count = count + 1
        titlelist = str(count) + ' of ' + str(nItem) + ': ' + name
        progress = count / float(nItem) * 100               
        dp.update(int(progress), 'Adding title',titlelist)
        if dp.iscanceled():
            return
        if 'tv_special' in ttype or 'series' in ttype:
            url = "http://www.imdb.com/title/%s/" % imdb_id
            name = name.replace('24: Live Another Day','24')
            imdb_id=imdb_id.replace('tt1598754','tt0285331')
            if ENABLE_META:
                infoLabels = get_meta(name,'tvshow','',season=None,episode=None,imdb=imdb_id,episode_title=None)
        else:
            if ENABLE_META:
                infoLabels = get_meta(clean_file_name(name),'movie',year)
        if ENABLE_META:
            if infoLabels['title']=='':
                name="%s (%s)" % (clean_file_name(name),year)
            else:
                name="%s (%s)" % (clean_file_name(infoLabels['title']),year)
            if infoLabels['cover_url']=='':
                iconimage=iconart
            else:
                iconimage=infoLabels['cover_url']
        else:
            infoLabels = None
            name="%s (%s)" % (clean_file_name(name),year)
            iconimage=iconart
        if 'tv_special' in ttype or 'series' in ttype:
            addDir(name, imdb_id,210,iconimage, name,imdb_id,'1','','tvshows',infoLabels=infoLabels)
            setView('tvshows', 'tvshows-view')
        else:
            addDir(name, 'imdb',1000,iconimage, name,imdb_id,'1','','movies',infoLabels=infoLabels)
            setView('movies', 'movies-view')
	

def movie_sort(name,url,iconimage,sort, release, start,parms,videotype):
    sort_id = ['User Rating', 'Number of Votes', 'Year', 'Release Date', 'Box Office Gross', 'Moviemeter', 'Alphabetical']
    for s in sort_id:
        if s == 'User Rating':
            sort = 'user_rating,desc'
        elif s == 'Number of Votes':
            sort = 'num_votes,desc'
        elif s == 'Year':
            sort = 'year,desc'
        elif s == 'Release Date':
            sort = 'release_date_us,desc'
        elif s == 'Box Office Gross':
            sort = 'boxoffice_gross_us,desc'
        elif s == 'Moviemeter':
            sort = 'moviemeter,desc'
        else:
            sort = 'alpha'
        addDir(s,'imdb',101,os.path.join(artf, 'sort_%s.png' % s.lower().replace(' ','')),sort, release, start,parms,videotype)
    

def movie_results(name,url,iconimage,sort, release, start,parms,videotype):
    dp = xbmcgui.DialogProgress()
    dp.create("What the Furk",'Getting titles')
    dp.update(0)
    parsplit = parms.split('<>')
    genre = parsplit[0]
    group = parsplit[1]
    studio = parsplit[2]
    has = parsplit[3]
    mpaa1 = parsplit[4]
    ttype = parsplit[5]
    tname = parsplit[6]
    pstatus = parsplit[7]
    if 'Coming Soon' in name:
        numvotes=""
    else:
        numvotes=NUM_VOTES
    nstart = str(int(start) + 50)
    params = {}
    params["release_date"] = release
    params["sort"] = sort
    params["title"] = tname
    params["title_type"] = ttype
    params["production_status"] = pstatus
    params["genres"] = genre.lower()
    params["groups"] = group.replace(' ', '_').lower()
    params["companies"] = studio.lower()
    params["has"] = has
    params["num_votes"] = numvotes
    params["certificates"] = mpaa1
    params["view"] = 'simple'
    params["start"] = start
    params["count"] = IMDB_RESULTS
    url = "%s%s" % (IMDB_URL, urllib.urlencode(params))
    body = get_url(url, cache=CACHE_PATH)#
    all_tr = regex_get_all(body, '<tr class=', '</tr>')
    nItem = len(all_tr)
    count = 0
    for tr in all_tr:
   
        all_td = regex_get_all(tr, '<td', '</td>')
        imdb_id = regex_from_to(all_td[1], '/title/', '/')
        name = regex_from_to(all_td[1], '/">', '</a>')
        year = regex_from_to(all_td[1], '<span class="year_type">\(', '\)').replace(' TV Series', '').replace(' Mini-Series', '')
        try:
            rating = regex_from_to(all_td[2], '<b>', '</b>')
            votes = regex_from_to(all_td[3], '\n', '\n')
        except:
            rating = ""
            votes = ""
        count = count + 1
        titlelist = str(count) + ' of ' + str(nItem) + ': ' + name
        progress = count / float(nItem) * 100               
        dp.update(int(progress), 'Adding title',titlelist)
        if dp.iscanceled():
            return
        if 'tv_special' in ttype or 'series' in ttype:
            url = "http://www.imdb.com/title/%s/" % imdb_id
            name = name.replace('24: Live Another Day','24')
            imdb_id=imdb_id.replace('tt1598754','tt0285331')
            if ENABLE_META:
                infoLabels = get_meta(name,'tvshow','',season=None,episode=None,imdb=imdb_id,episode_title=None)
        else:
            if ENABLE_META:
                infoLabels = get_meta(clean_file_name(name),'movie',year)
        if ENABLE_META:
            if infoLabels['title']=='':
                name="%s (%s)" % (clean_file_name(name),year)
            else:
                name="%s (%s)" % (clean_file_name(infoLabels['title']),year)
            if infoLabels['cover_url']=='':
                iconimage=iconart
            else:
                iconimage=infoLabels['cover_url']
        else:
            infoLabels = None
            name="%s (%s)" % (clean_file_name(name),year)
            iconimage=iconart
        if 'tv_special' in ttype or 'series' in ttype:
            addDir(name, imdb_id,210,iconimage, name,imdb_id,'1','','tvshows',infoLabels=infoLabels)
            setView('tvshows', 'tvshows-view')
        else:
            addDir(name, 'imdb',1000,iconimage, name,imdb_id,'1','','movies',infoLabels=infoLabels)
            setView('movies', 'movies-view')
    if len(tname)<2:
        addDir(">> Next Page", 'imdb',101,iconimage, sort,',',nstart,parms,'')

    
	
def movie_similar(name, url, iconimage,imdb):
    dp = xbmcgui.DialogProgress()
    dp.create("What the Furk",'Getting titles')
    dp.update(0)
    url = "%s%s%s" % ('http://m.imdb.com/title/',imdb,'/similarities')
    body = get_url(url, cache=CACHE_PATH).replace('\n',''	).replace('(','AX').replace(')','AZ')
    all_tr = regex_from_to(body, '<section class="similarities posters">', '</section>')
    match = re.compile('<a href="/title/(.+?)/">(.+?)</a> AX(.+?)AZ').findall(all_tr)
    nItem = len(match)
    count = 0
    for imdb,mname,year in match:
        count = count + 1
        titlelist = str(count) + ' of ' + str(nItem) + ': ' + mname
        progress = count / float(nItem) * 100               
        dp.update(int(progress), 'Adding title',titlelist)
        if dp.iscanceled():
            return
        infoLabels = get_meta(clean_file_name(mname),'movie',year)
        if infoLabels['title']=='':
             name="%s (%s)" % (clean_file_name(mname),year)
        else:
            name="%s (%s)" % (clean_file_name(infoLabels['title']),year)
        if infoLabels['cover_url']=='':
            iconimage=iconart
        else:
            iconimage=infoLabels['cover_url']
        addDir(name, 'imdb',1000,iconimage, name,imdb,'1','','movies',infoLabels=infoLabels)
    setView('movies', 'movies-view')
    
    
	
def view_trailer(name, url, iconimage):

    menu_texts = []
    menu_data = []
    menu_res = []
    menu_list_item = []
    title1 = name[:-6].rstrip()
    pDialog = xbmcgui.DialogProgress()
    pDialog.create('Searching for trailer')
    dialog = xbmcgui.Dialog()
    try:
        url = "http://www.hd-trailers.net/movie/%s/" % title1.lower().replace(' ','-').replace(':','-')
        response = s.get(url).text
        match=re.compile('href="http://(.+?)" rel=(.+?)title="(.+?)">(.+?)</a></td>').findall(response) 
        if len(match)==0:
            url = "http://www.hd-trailers.net/movie/" + title1.lower().replace(' ','-').replace(':','-').replace('and','-')
            response = s.get(url).text
            match=re.compile('href="http://(.+?)" rel=(.+?)title="(.+?)">(.+?)</a></td>').findall(response) 
            if len(match)==0:
                dialog.ok("Trailer Search", 'No trailers found for:', name) 
                return
        for url, info, title, res in match:
            if url.find('apple')>0:
                url = '%s|User-Agent=QuickTime' % ("http://" + url)
            elif url.find('youtube')>0:
                video_id = url.replace('www.youtube.com/watch?v=','')
                url = (
                    'plugin://plugin.video.youtube/'
                    '?action=play_video&videoid=%s' % video_id
                )
            else:
                url = "http://" + url
            if TRAILER_RESTRICT:
                if url.find('yahoo')<0 and res==TRAILER_QUALITY:
                    menu_texts.append("[%s] %s" % (res, clean_file_name(title, use_blanks=False)))
                    menu_list_item.append(clean_file_name(title, use_blanks=False))
                    menu_data.append(url)
                    menu_res.append(res)
            else:
                if url.find('yahoo')<0:
                    menu_texts.append("[%s] %s" % (res, clean_file_name(title, use_blanks=False)))
                    menu_list_item.append(clean_file_name(title + ' ' + url, use_blanks=False))
                    menu_data.append(url)
                    menu_res.append(res)
					
        if TRAILER_ONECLICK:
            menu_id =0
        else:
            menu_id = dialog.select('Select Trailer', menu_texts)
        if(menu_id < 0):
            return (None, None)
            dialog.close()
        else:	
            url = menu_data[menu_id]
            name = menu_texts[menu_id]
            list_item = menu_list_item[menu_id]
			
        pDialog.close()
    
        listitem = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage, path=url)
        xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
        handle = str(sys.argv[1])    
        if handle != "-1":
            listitem.setProperty("IsPlayable", "true")
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
        else:
            xbmcPlayer.play(url, listitem)
    except:
        dialog.ok("Trailer Search", 'No trailers found for:', name)	

def tv_menu(name):
    addDir("Most Popular (IMDB)", 'imdb',101,os.path.join(artf, 'mostpopular.png'), 'num_votes',',','1','<><><><><>tv_series,tv_special,mini_series<><>released','tvshowsmenu')
    addDir("Active Shows", 'imdb',102,os.path.join(artf, 'activeshows.png'), 'boxoffice_gross_us,desc',',','1','<><><><><>tv_series,tv_special,mini_series<><>active','tvshowsmenu')
    addDir("Trending Shows", 'shows/trending?page=',230,os.path.join(artf, 'trending.png'), 'blank','blank','1','','tvshowsmenu')
    addDir("Most Popular", 'shows/popular?page=',230,os.path.join(artf, 'mostpopular.png'), 'blank','blank','1','','tvshowsmenu')
    addDir("Most Played Last 7 Days", 'shows/played/weekly?page=',230,os.path.join(artf, 'mostplayed7.png'), 'blank','blank','1','','tvshowsmenu')
    addDir("Most Played Last 30 Days", 'shows/played/monthly?page=',230,os.path.join(artf, 'mostplayed30.png'), 'blank','blank','1','','tvshowsmenu')
    addDir("Most Watched Last 7 Days", 'shows/watched/weekly?page=',230,os.path.join(artf, 'mostwatched7.png'), 'blank','blank','1','','tvshowsmenu')
    addDir("Most Watched Last 30 Days", 'shows/watched/monthly?page=',230,os.path.join(artf, 'mostwatched30.png'), 'blank','blank','1','','tvshowsmenu')
    addDir("TV Shows by Genre", 'imdb',205,os.path.join(artf, 'genre.png'), '',',','1','<><><><><>tv_series,tv_special,mini_series<><>released','tvshowsmenu')
    addDir("TV Shows by Group", 'imdb',206,os.path.join(artf, 'group.png'), '',',','1','<><><><><>tv_series,tv_special,mini_series<><>released','tvshowsmenu')
    addDir("Search TV Shows", 'imdb',1500,os.path.join(artf, 'search.png'), 'blank','blank','1','','')
		
def tv_genres_menu():
    genres = ['Action', 'Adventure', 'Animation', 'Comedy', 'Crime', 'Documentary', 'Drama', 'Family',
              'Fantasy', 'History', 'Horror', 'Romance', 'Sci-Fi', 'Thriller', 'War', 'Western']
    for genre in genres:
        addDir(genre, 'imdb',102,os.path.join(artf, '%s.png' % genre.lower().replace('-','')), 'release_date_us,desc','','1','%s<><><><><>tv_series,tv_special,mini_series<><>released' % genre,'tvshowsmenu')

def tv_groups_menu():
    groups = ['Emmy Winners', 'Emmy Nominees', 'Golden Globe Winners', 'Golden Globe Nominees']
    for group in groups:
        addDir(group, 'imdb',102,os.path.join(artf, '%s.png' % group.lower().replace(' ','')), 'release_date_us,desc','','1','<>%s<><><><>tv_series,tv_special,mini_series<><>released' % group,'tvshowsmenu')
	
def tv_seasons(name,imdb_id,iconimage,rootname,imdb,videotype):
    dp = xbmcgui.DialogProgress()
    dp.create("What the Furk",'Getting Seasons')
    dp.update(0)
    eplist = []
    if 'trakt' in imdb_id:
        body = get_url(imdb_id, cache=CACHE_PATH).translate(trans_table)
        imdb_id=regex_from_to(body,'href="http://imdb.com/title/','"')
    url = 'http://thetvdb.com/api/GetSeriesByRemoteID.php?imdbid=%s&language=en' % imdb_id
    body = get_url(url, cache=CACHE_PATH)
    tvdbid = regex_from_to(body, '<id>', '</id>')
    tvdb_url = 'http://thetvdb.com/api/%s/series/%s/all/en.xml' % (TVDB_KEY, tvdbid)
    body = get_url(tvdb_url, cache=CACHE_PATH)
    seasons = set()
    episodes = regex_get_all(body, '<Episode>', '</Episode>')
    
    for e in episodes:
        try:
            first_aired = regex_from_to(e, '<FirstAired>', '</FirstAired>')
        except:
            first_aired = ""
        if len(first_aired) > 0:
            d = first_aired.split('-')
            episode_date = date(int(d[0]), int(d[1]), int(d[2]))
            season_number = int(regex_from_to(e, '<SeasonNumber>', '</SeasonNumber>'))
            if UNAIRED:
                seasons.add(season_number)
            else:
                if date.today() > episode_date:
                    seasons.add(season_number)
    nItem = len(seasons)
    count = 0                
    for season in sorted(seasons):
        infoLabels = get_meta(clean_file_name(name),'tvshow',year=None,season=season,episode=None,imdb=imdb_id,episode_title=None)
        iconimage = 'http://thetvdb.com/banners/seasons/%s-%s.jpg' % (tvdbid,season)
        title = "Season %s" % season
        count = count + 1
        titlelist = str(count) + ' of ' + str(nItem) + ': ' + name
        progress = count / float(nItem) * 100               
        dp.update(int(progress), 'Adding Season',titlelist)
        if dp.iscanceled():
            return
        if SHOW_SPECIALS and int(season)==0:
            addDir(title, tvdb_url,211,iconimage, rootname,imdb_id,imdb_id,'',videotype,infoLabels=infoLabels)
        if int(season)>0:
            addDir(title, tvdb_url,211,iconimage, rootname,imdb_id,imdb_id,'',videotype,infoLabels=infoLabels)
    setView('seasons', 'seasons-view')

def tv_episodes(name,url,iconimage,start,rootname,imdb,videotype):
    dp = xbmcgui.DialogProgress()
    dp.create("What the Furk",'Getting Episodes')
    dp.update(0)
    body = get_url(url, cache=CACHE_PATH).translate(trans_table)
    sn = name.replace('Season ', '')
    episodes = regex_get_all(body, '<Episode>', '</Episode>')
    count = 0 
    for e in episodes:
        es = regex_from_to(e, '<SeasonNumber>', '</SeasonNumber>')
        en = regex_from_to(e, '<EpisodeNumber>', '</EpisodeNumber>')
        if es==sn:
            try:
                epname = regex_from_to(e, '<EpisodeName>', '</EpisodeName>')
            except:epname=""
        else:
            epname="--"
        
        try:
            first_aired = regex_from_to(e, '<FirstAired>', '</FirstAired>')
        except:
            first_aired = ""
        if len(first_aired) > 0 and es == sn:
            d = first_aired.split('-')
            episode_date = date(int(d[0]), int(d[1]), int(d[2]))
            cleaned_name = clean_file_name(epname, use_blanks=False)
            infoLabels = get_meta(clean_file_name(rootname),'episode',year=None,season=es,episode=en,imdb=imdb,episode_title=None)
            text = "S%.2dE%.2d - %s" % (int(es), int(en), cleaned_name)
            count = count + 1
            titlelist = str(count) + ': ' + text
            progress = count / float(12) * 100               
            dp.update(int(progress), 'Adding Episode',titlelist)
            if dp.iscanceled():
                return
            if infoLabels['cover_url']=='':
                iconimage=iconimage
            else:
                iconimage=infoLabels['cover_url']
            if UNAIRED:
                if date.today() > episode_date:
                    display = "S%.2dE%.2d - %s" % (int(es), int(en), cleaned_name)
                elif date.today() == episode_date:
                    display = "[COLOR orange]%s S%.2dE%.2d - %s[/COLOR]" % (first_aired, int(es), int(en), cleaned_name)
                elif date.today() < episode_date:
                    display = "[COLOR red]%s S%.2dE%.2d - %s[/COLOR]" % (first_aired, int(es), int(en), cleaned_name)
                addDir(display, 'url',1000,iconimage, rootname,imdb,'na','na',videotype,infoLabels=infoLabels)
            elif date.today() > episode_date:
                display = "S%.2dE%.2d - %s" % (int(es), int(en), cleaned_name)
                addDir(display, 'url',1000,iconimage, rootname,imdb,'na','na',videotype,infoLabels=infoLabels)
    setView('episodes', 'episodes-view')
            

            

	
def music_menu(name):
    addDir('Search Artist','artist',304,os.path.join(artf, 'searchartist.png'),'','','','','music')
    addDir('Search Album','album',304,os.path.join(artf, 'searchalbum.png'),'','','','','music')
    addDir('UK Album Chart','http://www.billboard.com/charts/united-kingdom-albums',302,os.path.join(artf, 'ukalbums.png'),'','','','','music')
    addDir('UK Single Chart - Top 100','http://www.officialcharts.com/singles-chart/',302,os.path.join(artf, 'uksingles.png'),'','','','','music')
    addDir('BillBoard 200','http://www.billboard.com/charts/billboard-200',302,os.path.join(artf, 'billboard200.png'),'','','','','music')
    addDir('Hot 100 Singles','http://www.billboard.com/charts/hot-100',302,os.path.join(artf, 'hot100sinlges.png'),'','','','','music')
    addDir('Country Albums','http://www.billboard.com/charts/country-albums',302,os.path.join(artf, 'countryalbums.png'),'','','','','music')
    addDir('HeatSeeker Albums','http://www.billboard.com/charts/heatseekers-albums',302,os.path.join(artf, 'heatseekeralbums.png'),'','','','','music')
    addDir('Independent Albums','http://www.billboard.com/charts/independent-albums',302,os.path.join(artf, 'independentalbums.png'),'','','','','music')
    addDir('Catalogue Albums','http://www.billboard.com/charts/catalog-albums',302,os.path.join(artf, 'cataloguealbums.png'),'','','','','music')
    addDir('Folk Albums','http://www.billboard.com/charts/folk-albums',302,os.path.join(artf, 'folkalbums.png'),'','','','','music')
    addDir('Blues Albums','http://www.billboard.com/charts/blues-albums',302,os.path.join(artf, 'bluesalbums.png'),'','','','','music')
    addDir('Tastemaker Albums','http://www.billboard.com/charts/tastemaker-albums',302,os.path.join(artf, 'tastemakeralbums.png'),'','','','','music')
    addDir('Rock Albums','http://www.billboard.com/charts/rock-albums',302,os.path.join(artf, 'rockalbums.png'),'','','','','music')
    addDir('Alternative Albums','http://www.billboard.com/charts/alternative-albums',302,os.path.join(artf, 'alternativealbums.png'),'','','','','music')
    addDir('Hard Rock Albums','http://www.billboard.com/charts/hard-rock-albums',302,os.path.join(artf, 'hardrockalbums.png'),'','','','','music')
    addDir('Digital Albums','http://www.billboard.com/charts/digital-albums',302,os.path.join(artf, 'digitalalbums.png'),'','','','','music')
    addDir('R&B Albums','http://www.billboard.com/charts/r-b-hip-hop-albums',302,os.path.join(artf, 'rbalbums.png'),'','','','','music')
    addDir('Top R&B/Hip-Hop Albums','http://www.billboard.com/charts/r-and-b-albums',302,os.path.join(artf, 'toprbalbums.png'),'','','','','music')
    addDir('Dance Electronic Albums','http://www.billboard.com/charts/dance-electronic-albums',302,os.path.join(artf, 'dancealbums.png'),'','','','','music')
	
def search_artist(url):
    if url == 'artist':
        keyboard = xbmc.Keyboard('', 'Search Artist', False)
    else:
        keyboard = xbmc.Keyboard('', 'Search Album', False)
    keyboard.doModal()

    if keyboard.isConfirmed():
        query = keyboard.getText()
        if len(query) > 0:
            search_artists(query,url)

def search_artists(query,url):
    music=[]
    if url == 'artist':
        artist=query.replace(' ', '+')  
        link = get_url('http://www.allmusic.com/search/artists/'+artist)
        match=re.compile('<div class="photo">\n.+?a href="(.+?)" data-tooltip=".+?">\n.+?img src="(.+?).jpg.+?" height=".+?" alt="(.+?)">').findall(link)
        for url,icon,artist in match:
            url='http://www.allmusic.com'+url+'/discography'
            iconimage=icon.replace('JPG_170','JPG_400')+'.jpg'
            addDir(clean_file_name(artist),url,305,iconimage,'','','','','musicartist')
    else:
        album=query.replace(' ', '+') 
        link = get_url('http://www.allmusic.com/search/albums/'+album).replace('\n','')
        match=re.compile('<div class="cover">.+?href="(.+?)" title="(.+?)".+?<img src="(.+?).jpg.+?".+?<div class="artist">.+?a href=".+?">(.+?)</a>').findall(link)
        for url,name,icon,artist in match:
            url='http://www.allmusic.com'+'/album'+url
            iconimage=icon.replace('JPG_170','JPG_250')+'.jpg'
            addDir(artist.replace('&amp;', '&') + ' - ' + name.replace('&amp;', '&'),'url',303,iconimage,'','','','','musicalbum')
            #addDir(artist, name,'music file disc menu',iconimage)

def discography(artist,url,icon):
    music=[]
    link = get_url(url)
    match=re.compile('<td class="cover">\n.+?a href="(.+?)"\n.+?title="(.+?)"\n.+?data-tooltip=".+?">\n.+?div class=".+?" style=".+?" ><img class=".+?" src=".+?" data-original="(.+?).jpg.+?"').findall(link)
    uniques=[]
    addDir(artist.replace('&amp;', '&') + ' - Discography','url',303,icon,'','','','','music')
    for url,name,iconimage in match:
        if name not in uniques:
            uniques.append(name)
            url='http://www.allmusic.com'+'/album'+url
            iconimage=iconimage.replace('JPG_250','JPG_400').replace('JPG_75','JPG_400')+'.jpg'
            name=str(name).replace("'",'').replace(',','') .replace(":",'').replace('&amp;','And').replace('.','')
            addDir(artist.replace('&amp;', '&') + ' - ' + name.replace('&amp;', '&'),'url',303,iconimage,'','','','','musicalbum')
	
def chart_lists(name, url):
    req = urllib2.Request(url)
    req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link=response.read()
    response.close()
    if "officialcharts" in url:
        all_list = regex_get_all(link, '<div class="track">', '<div class="label')
        for list in all_list:
            iconimage = regex_from_to(list, '<img src="', '"')
            titles=regex_get_all(list,'<a href=','/a>')
            artist = regex_from_to(titles[1], '">', '<').replace('&#039;',"'").replace('&#39;',"'")
            title = regex_from_to(titles[0], '">', '<').replace('&#039;',"'").replace('&#39;',"'")
            addDir(artist.replace('&amp;', '&') + ' - ' + title.replace('&amp;', '&'),'url',303,iconimage,'','','','','musicalbum')
    elif "billboard" in url and '<span class="chart_position' not in link:
        link=link.replace('\n','').replace('\t','')
        match=re.compile('<span class="this-week">(.+?)</span><span class="last-week">(.+?)</span></div><div class="row-image"(.+?)<div class="row-title"><h2>(.+?)</h2><h3><a href="(.+?)" data-tracklabel="Artist Name">(.+?)</a>').findall(link)
        for pos,lw,iconimage,title,artisturl,artist in match:
            text = "%s %s" % (artist, title)
            try:
                iconimage='http://' + regex_from_to(iconimage,'http://','.jpg') + '.jpg'
            except:
                iconimage='http://www.billboard.com/sites/all/themes/bb/images/default/no-album.png'
            if not 'Single' in name and not 'Best Songs of 2014' in text:
                addDir(artist.replace('&amp;', '&') + ' - ' + title.replace('&amp;', '&'),'url',303,iconimage,'','','','','musicalbum')
            elif not 'Best Songs of 2014' in text:
                addDir(artist.replace('&amp;', '&') + ' - ' + title.replace('&amp;', '&'),'url',303,iconimage,'','','','','musicsingle')
    else:
        all_list=regex_get_all(link,'<span class="chart_position','</header>')
        for a in all_list:
            title=regex_from_to(a,'<h1>','</h1>').rstrip()
            try:
                artist=regex_from_to(a,' title="','">').strip()
            except:
                artist=regex_from_to(a,'<p class="chart_info">','</p>').strip()
            try:
                iconimage=regex_from_to(a,'Image" src="','"')
            except:
                iconimage='http://www.billboard.com/sites/all/themes/bb/images/default/no-album.png'
            text = "%s %s" % (artist, title)
            if not 'Single' in name and not 'Best Songs of 2014' in text:
                addDir(artist.replace('&amp;', '&') + ' - ' + title.replace('&amp;', '&'),'url',303,iconimage,'','','','','musicalbum')
            elif not 'Best Songs of 2014' in text:
                addDir(artist.replace('&amp;', '&') + ' - ' + title.replace('&amp;', '&'),'url',303,iconimage,'','','','','musicsingle')
	
def furk_menu(name):
    addDirPlayableResolve("Account Info", 'url',503,os.path.join(artf, 'accountinfo.png'), 'blank','blank','','','','')
    addDir("Search Furk (Video)", 'url',502,os.path.join(artf, 'searchvideo.png'), 'blank','blank','','','','')
    addDir("Search Furk (Audio)", 'url',502,os.path.join(artf, 'searchaudio.png'), 'blank','blank','','','','')
    addDir("My Files - Finished", '0',501,os.path.join(artf, 'myfilesfinished.png'), "","",'','','mff')
    addDir("My Files - Deleted", '1',501,os.path.join(artf, 'myfilesdeleted.png'), "","",'','','mfd')
    addDir("My Files - Active", 'active',556,os.path.join(artf, 'myfilesactive.png'), "","",'','','')
    addDir("My Files - Failed", 'failed',556,os.path.join(artf, 'myfilesfailed.png'), "","",'','','')
	
def account_info(name):
    if not login_at_furk():
        return []
    accinfo = FURK.account_info()
    try:	
        text = []
        info = str(accinfo).replace("'","QTE")
	
        acctype = regex_from_to(info, 'nameQTE: uQTE', 'QTE, ')
     
        limit_mth = float(regex_from_to(info, 'bw_limit_monthQTE: uQTE', 'QTE, '))/1073741824
        used_bw_mth = float(regex_from_to(info, 'bw_used_monthQTE: uQTE', 'QTE, '))/1073741824
        rem_bw_mth = limit_mth - used_bw_mth
        multi_mth = regex_from_to(info, 'is_not_last_monthQTE: uQTE', 'QTE, ')
        if multi_mth == '1':
            text = "resets"
        else:
            text = "expires"
	
        bw_days_left = float(regex_from_to(info, 'bw_month_time_leftQTE: uQTE', 'QTE, '))/60/60/24
        rem_days = "%.1f" % bw_days_left
		


        dialog = xbmcgui.Dialog()
        dialog.ok(("Account Type: " + acctype) + " - " + ("%.0fGB" % limit_mth) + " pm", ("Current Month: " + '[COLOR red]' + ("%.1fGB" % used_bw_mth) + '[/COLOR]' + " / " + '[COLOR green]' + ("%.1fGB" % rem_bw_mth) + '[/COLOR]' + " / " + ("%.1fGB" % limit_mth)), "", ("Bandwidth limit " + text + " in " + str(rem_days) + " days"))

    except:
        info = regex_from_to(str(accinfo).replace("'","QTE"), 'QTEbw_statsQTE', ']}') 
        all_bytes = regex_get_all(info, 'uQTEbytesQTE: u', ', uQTE')

        day1 = regex_from_to(all_bytes[0], 'QTE: uQTE', 'QTE, u')
        day2 = regex_from_to(all_bytes[1], 'QTE: uQTE', 'QTE, u')
        day3 = regex_from_to(all_bytes[2], 'QTE: uQTE', 'QTE, u')
        day4 = regex_from_to(all_bytes[3], 'QTE: uQTE', 'QTE, u')
        day5 = regex_from_to(all_bytes[4], 'QTE: uQTE', 'QTE, u') 
        day6 = regex_from_to(all_bytes[5], 'QTE: uQTE', 'QTE, u')
        day7 = regex_from_to(all_bytes[6], 'QTE: uQTE', 'QTE, u')
		
        if float(day1) > 1073741824:
            day1_tot =  float(day1)/1073741824
            day1_text = "%.2fGB" % day1_tot
        else:
            day1_tot = float(day1)/1048576
            day1_text = "%.1fMB" % day1_tot
			
        week_tot = int(day1) + int(day2) + int(day3) + int(day4) + int(day5) + int(day6) + int(day7)
        if float(week_tot) > 1073741824:
            week_total =  float(week_tot)/1073741824
            week_text = "%.2fGB" % week_total
        else:
            week_total =  float(week_tot)/1048576
            week_text = "%.1fMB" % week_total
        
        dialog = xbmcgui.Dialog()		
        dialog.ok("Account Type: Free", "Used Today: " + str(day1_text), "Last 7 Days: " + str(week_text))
		
def add_download(name, info_hash):
    dialog = xbmcgui.Dialog()
    if dialog.yesno("Add Download", "Download this file to your Furk account?", "Success depends on number of seeders"):
        response = FURK.dl_add(info_hash)
        if response['status'] == 'ok':
            notify = 'XBMC.Notification(Download added to Furk account,Check status in Furk menu,3000)'
            xbmc.executebuiltin(notify)
        else:
            notify = 'XBMC.Notification(Error,Unable to add download,3000)'
            xbmc.executebuiltin(notify)

def myfiles(unlinked):
    if unlinked=='0':
        type='mff'
    elif unlinked=='1':
        type='mfd'
    else: type='finished'
    if not login_at_furk():
        return []
		
    my_files = FURK.file_get(unlinked)
    files = my_files.files
	
    for f in files:
        count_files = (f.files_num_video)
        name = f.name
        url = f.url_dl
        id = f.id
        size = f.size
        size = float(size)/1073741824
        size = "[%.2fGB]" % size
        text = "%s %s [%s files]" %(size, name, count_files)
        try:
            poster = f.ss_urls_tn[0]
        except:
            poster = ""

        #try:
        addDir(text, id,1001,poster, name,"myfiles",id,"mf0",type)
        setView('movies', 'movies-view')
        #except:
            #pass
			
def get_downloads(dl_status):
    downloads = str(FURK.dl_get(dl_status))
    dls_all = regex_from_to(str(downloads), "dls': ", ", u'found_dls")
    all_dls = regex_get_all(dls_all, '{', 'None}')
    
    items = []
    for dls in all_dls:
        name = regex_from_to(dls, "name': u'", "', u")
        size = regex_from_to(dls, "size': u'", "', u")
        speed = regex_from_to(dls, "speed': u'", "', u")
        downloaded = regex_from_to(dls, "have': u'", "', u")
        seeders = regex_from_to(dls, "seeders': u'", "', u")
        id = regex_from_to(dls, "id': u'", "', u")
        fail_reason = regex_from_to(dls, "fail_reason': u'", "', u")
        size = float(size)/1073741824
        size = "[%.2fGB]" % size
        if int(speed) < 1048576:
            speed = float(speed)/1024
            speed = "[%.0fkB/s]" % speed
        else:
            speed = float(speed)/1024/1024
            speed = "[%.0fMB/s]" % speed
        downloaded = downloaded + "%"
        if dl_status=='failed':
            text="%s [COLOR orange]%s[/COLOR]" % (name,fail_reason)
        else:
            text="%s %s %s" % (name,downloaded,speed)
        addDirPlayable(text,id,99999,'','','','','','torrents')
        #addDir(text, id,'mode','', name,"myfiles",size,"mf0",'torrents')
			
def myfiles_add(name, id):
    dialog = xbmcgui.Dialog()
    response = FURK.file_link(id)

    if response['status'] == 'ok':
        dialog.ok("Add to My Files", name, 'Success - Added to My Files')
    else:
        dialog.ok("Add to My Files", name, response['status']) 
    return (None, None)
    dialog.close()

def myfiles_remove(name, id):
    dialog = xbmcgui.Dialog()
    response = FURK.file_unlink(id)
    if response['status'] == 'ok':
        dialog.ok("Remove from My Files", name, 'Success')
    else:
        dialog.ok("Remove from My Files", name, 'Error')
    return (None, None)
    dialog.close()
	
def myfiles_clear(name, id):
    dialog = xbmcgui.Dialog()
    response = FURK.file_clear(id)

    if response['status'] == 'ok':
        dialog.ok("Clear Deleted file", name, 'Success - File removed')
    else:
        dialog.ok("Clear Deleted file", name, response['status']) 
    return (None, None)
    dialog.close()


def myfiles_protect(name, id):
    dialog = xbmcgui.Dialog()
    is_protected = '1'
    response = FURK.file_protect(id, is_protected)
    if response['status'] == 'ok':
        dialog.ok("File Protection", name, 'Protected')
    else:
        if response['error'] == 'limit exceeded':
            dialog.ok("File Protection", name, 'Error! Your storage limit for protected files is exceeded','Current usage is ' + response['usage'] + ' GB')
        elif response['error'] == 'not premium':
            dialog.ok("File Protection", name, 'Error! This feature is for premium users only')
        elif response['status'] == 'error':
            dialog.ok("File Protection", name, response['error'])
    return (None, None)
    dialog.close()


def myfiles_unprotect(name, id):
    dialog = xbmcgui.Dialog()
    is_protected = '0'
    response = FURK.file_protect(id, is_protected)
    if response['status'] == 'ok':
        dialog.ok("File Protection", name, 'Unprotected')
    else:
        if response['error'] == 'limit exceeded':
            dialog.ok("File Protection", name, 'Error! Your storage limit for protected files is exceeded','Current usage is ' + response['usage'] + ' GB')
        elif response['error'] == 'not premium':
            dialog.ok("File Protection", name, 'Error! This feature is for premium users only')
        elif response['status'] == 'error':
            dialog.ok("File Protection", name, response['error'])
    return (None, None)
    dialog.close()	
	
def mypeople_menu(name):
    addDir("[COLOR cyan]Search People[/COLOR]", 'imdb',601,'', 'blank','blank','1','','')
    if os.path.isfile(FAV_PEOPLE):
        s = read_from_file(FAV_PEOPLE)
        search_list = s.split('\n')
        for list in search_list:
            if list != '':
                list1 = list.split('<>')
                name = list1[0]
                url = list1[1]
                rootname = list1[1]
                imdb = list1[3]
                thumb = list1[4]
                addDir(name, url,602,thumb, 'blank','blank','1','','actors')


def search_actors():
    keyboard = xbmc.Keyboard("", 'Search People', False)
    keyboard.doModal()
    if keyboard.isConfirmed():
        query = keyboard.getText()
        if len(query) > 0:
            url = "http://www.imdb.com/search/name?name=%s" % urllib.quote(query)
            body = get_url(url, cache=CACHE_PATH)

            all_tr = regex_get_all(body, '<tr class=', '</tr>')
            for tr in all_tr:
                all_td = regex_get_all(tr, '<td', '</td>')
                imdb_id = regex_from_to(all_td[2], 'href="/name/', '/')
                name = regex_from_to(all_td[2], '/">', '</a>')
                try:
                    profession = ' (' + regex_from_to(all_td[2], 'description">', ', <a href') + ')'
                except:
                    profession = ""
                photo = regex_from_to(all_td[1], '<img src="', '" ')
                photo = photo.replace("54", "214").replace("74", "314").replace("CR1", "CR12")
                addDir(name + profession, imdb_id,602,photo, 'blank','blank','1','','actors')
				
def movies_actors(name, imdb_id,photo):
    dp = xbmcgui.DialogProgress()
    dp.create("What the Furk",'Getting titles')
    dp.update(0)
    url = "%s%s" % ("http://www.imdb.com/name/", imdb_id)
    body = get_url(url, cache=CACHE_PATH).replace('\n','').replace('\t','').replace('\t','').translate(trans_table)
    #match=re.compile('filmo-row (.+?)" id="(.+?)"><span class="year_column">&nbsp;(.+?)</span><b><a href="/title/(.+?)/?ref_=(.+?)">(.+?)</a>(.+?)<br/></div>').findall(body)
    match=re.compile('filmo-row (.+?)" id="(.+?)"><span class="year_column">(.+?)</span><b><a href="/title/(.+?)/?ref_=(.+?)">(.+?)</a>(.+?)<br/>').findall(body)
    nItem = 0
    count=0
    for d1,id,year,imdb_id,d2,title,exclude in match:
        if exclude.find("(TV")<0 and exclude.find("(Shor")<0 and exclude.find("(Vid")<0 and ('actor' in id or 'director' in id or 'actress' in id) and (not 'class="in_production"' in title and not 'class="in_production"' in exclude):
            nItem=nItem+1
    for d1,id,year,imdb_id,d2,title,exclude in match:
        if exclude.find("(TV")<0 and exclude.find("(Shor")<0 and exclude.find("(Vid")<0 and ('actor' in id or 'director' in id or 'actress' in id) and (not 'class="in_production"' in title and not 'class="in_production"' in exclude):
            year=year.replace('&nbsp;','')
            count=count+1
            titlelist = str(count) + ' of ' + str(nItem) + ': ' + title
            progress = count / float(nItem) * 100               
            dp.update(int(progress), 'Filtering Titles',titlelist)
            if dp.iscanceled():
                return
            infoLabels = get_meta(clean_file_name(title),'movie',year)
            if infoLabels['title']=='':
                 mname="%s (%s)" % (clean_file_name(title),year)
            else:
                mname="%s (%s)" % (clean_file_name(infoLabels['title']),year)
            if infoLabels['cover_url']=='':
                iconimage=photo
            else:
                iconimage=infoLabels['cover_url']
            addDir(mname, 'imdb',1000,iconimage, name,imdb_id,'1','','movies',infoLabels=infoLabels)

	
def subscriptions_menu(name):
    addDir("Name", 'url',mode,iconimage, 'blank','blank')
	
def favourites_menu(name):
    addDir("Favourite Movies", 'url',801,os.path.join(artf, 'favouritemovies.png'), 'blank','blank','','','','movies')
    addDir("Favourite TV Shows", 'url',802,os.path.join(artf, 'favouritetvshows.png'), 'blank','blank','','','','tvshows')
    addDir("Favourite Artists", 'url',803,os.path.join(artf, 'favouritemusic.png'), 'blank','blank','','','','music')
    addDir("Favourite Albums", 'url',804,os.path.join(artf, 'favouritemusic.png'), 'blank','blank','','','','music')
	
def maintenance_menu(name):
    addDirPlayable("Delete Cache Files", 'url',901,os.path.join(artf, 'deletecache.png'),'blank','','','','maint')
    addDirPlayable("Delete Packages", 'url',902,os.path.join(artf, 'deletecache.png'),'blank','','','','maint')
    addDirPlayable("Rebuild TV Subscriptions", 'url',903,os.path.join(artf, 'tvsubscriptions.png'),'blank','','','','maint')
	
############################### MAINTENANCE #############################################################################
def deletecachefiles():
	# Set path to What th Furk cache files
    wtf_cache_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.whatthefurk/cache'), '')
		
    for root, dirs, files in os.walk(wtf_cache_path):
        file_count = 0
        file_count += len(files)
	
    # Count files and give option to delete
        if file_count > 0:

            dialog = xbmcgui.Dialog()
            if dialog.yesno("Delete What the Furk Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
			
                for f in files:
    	            os.unlink(os.path.join(root, f))
                for d in dirs:
    	            shutil.rmtree(os.path.join(root, d))
					
        else:
            dialog = xbmcgui.Dialog()
            dialog.ok("Delete What the Furk Cache Files", "There are no cache files to delete")
	
    # Check if platform is ATV2.....if yes count files and give option to delete	
    if xbmc.getCondVisibility('system.platform.ATV2'):
        atv2_cache_a = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'Other')
        
        for root, dirs, files in os.walk(atv2_cache_a):
		file_count = 0
        file_count += len(files)
		
        if file_count > 0:

            dialog = xbmcgui.Dialog()
            if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'Other'", "Do you want to delete them?"):
			
                for f in files:
    	            os.unlink(os.path.join(root, f))
                for d in dirs:
    	            shutil.rmtree(os.path.join(root, d))
					
        else:
            dialog = xbmcgui.Dialog()
            dialog.ok("Delete Cache Files", "There are no ATV2 'Other' cache files to delete")
			
        atv2_cache_b = os.path.join('/private/var/mobile/Library/Caches/AppleTV/Video/', 'LocalAndRental')
        
        for root, dirs, files in os.walk(atv2_cache_b):
		file_count = 0
        file_count += len(files)
		
        if file_count > 0:

            dialog = xbmcgui.Dialog()
            if dialog.yesno("Delete ATV2 Cache Files", str(file_count) + " files found in 'LocalAndRental'", "Do you want to delete them?"):
			
                for f in files:
    	            os.unlink(os.path.join(root, f))
                for d in dirs:
    	            shutil.rmtree(os.path.join(root, d))
					
        else:
            dialog = xbmcgui.Dialog()
            dialog.ok("Delete Cache Files", "There are no ATV2 'LocalAndRental' cache files", "to delete")
			
def deletepackages():
    packages_cache_path = xbmc.translatePath(os.path.join('special://home/addons/packages', ''))
    try:    
        for root, dirs, files in os.walk(packages_cache_path):
            file_count = 0
            file_count += len(files)
            
        # Count files and give option to delete
            if file_count > 0:
    
                dialog = xbmcgui.Dialog()
                if dialog.yesno("Delete Package Cache Files", str(file_count) + " files found", "Do you want to delete them?"):
                            
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    for d in dirs:
                        shutil.rmtree(os.path.join(root, d))
                    dialog = xbmcgui.Dialog()
                    dialog.ok("Delete Packages", "Success")
    except: 
        dialog = xbmcgui.Dialog()
        dialog.ok("Delete Packages", "Unable to delete")
		
def rebuild_subscriptions():
    OLDSUB = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.whatthefurk'), 'subsciption.list')
    try:
        if os.path.isfile(OLDSUB):
            s = read_from_file(OLDSUB)
            search_list = s.split('\n')
            for list in search_list:
                
                if list != '':
                    data = list.split('\t')
                    if ' (' in data[0]:
                        tv_show_name = clean_file_name(data[0].split(' (')[0])
                    else:
                        tv_show_name = clean_file_name(data[0])
                    imdb = data[1]
                    infoLabels = get_meta(tv_show_name,'tvshow','',season=None,episode=None,imdb=imdb,episode_title=None)
                    if infoLabels['cover_url']=='':
                        iconimage=iconart
                    else:
                        iconimage=infoLabels['cover_url']
                    deleteexistingsubs(tv_show_name)
                    add_favourite(tv_show_name, imdb, tv_show_name, '',iconimage, SUB, "Added to Library/Subscribed")
        get_subscriptions('Refresh Subs','url')
    except:
        pass
		
					
def deleteexistingsubs(name):
    try:    
        for root, dirs, files in os.walk(TV_PATH):
            file_count = 0
            file_count += len(files)
            
        # Count files and give option to delete
            for d in dirs:
                if d==name:
                    for f in files:
                        os.unlink(os.path.join(root, f))
                    shutil.rmtree(os.path.join(root, d))
    except: 
        pass

			
def deletemetafiles():
	# Set path to What the Furk meta files
    try:
        wtf_meta_path = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.whatthefurk/meta'), '')
        for root, dirs, files in os.walk(wtf_meta_path):
            file_count = 0
            file_count += len(files)
	
    # Count files and give option to delete
            if file_count > 0:
			
                for f in files:
    	            os.unlink(os.path.join(root, f))
                for d in dirs:
    	            shutil.rmtree(os.path.join(root, d))
    except:pass
		
############################### END MAINTENANCE #############################################################################
	
def help(name):
    addDir("Name", 'url',mode,iconimage, 'blank','blank')
	
def search_imdb(name,url):
    keyboard = xbmc.Keyboard('', name, False)
    keyboard.doModal()
    if keyboard.isConfirmed():
        query = keyboard.getText()
        if 'Movies' in name:
            if len(query) > 0:
                movie_results('search','search','','release_date_us,desc', '', '1','<><><><><>feature,documentary,tv_movie<>%s<>' % query,'movies')
        elif 'TV' in name:
            if len(query) > 0:
                movie_results('search','search','','release_date_us,desc', '', '1','<><><><><>tv_series,mini_series,tv_special<>%s<>' % query,'tvshows')
        elif 'Search Furk (Video)' in name:
            if len(query) > 0:
                if '|' in query:
                    furksearch(query,"extended")
                elif '...' in query:
                    furksearch(query,"any")
                else:
                    furksearch(query,"all")
        elif 'Search Furk (Audio)' in name:
            if len(query) > 0:
                if '|' in query:
                    furksearchaudio(query,"extended",'',query)
                elif '...' in query:
                    furksearchaudio(query,"any",'',query)
                else:
                    furksearchaudio(query,"all",'',query)
				
	
def favourites_movies(name):
    if os.path.isfile(FAV):
        s = read_from_file(FAV)
        search_list = s.split('\n')
        for list in search_list:
            if list != '':
                list1 = list.split('<>')
                title = list1[0]
                name=title.split(' (')[0]
                year=title.split(' (')[1].replace(')','')
                url = list1[1]
                rootname = list1[1]
                imdb = list1[3]
                thumb = list1[4]
                if ENABLE_META:
                    infoLabels = get_meta(clean_file_name(name),'movie',year)
                    if infoLabels['title']=='':
                        name=name
                    else:
                        name=infoLabels['title']
                    if infoLabels['cover_url']=='':
                        iconimage=thumb
                    else:
                        iconimage=infoLabels['cover_url']
                else:
                    infoLabels =None
                    iconimage=thumb
                addDir(title, url,1000,thumb, title,imdb,'1','','movies',infoLabels=infoLabels)
    setView('movies', 'movies-view')
	
def favourites_tv(name):
    if os.path.isfile(FAV_TV):
        s = read_from_file(FAV_TV)
        search_list = s.split('\n')
        for list in search_list:
            if list != '':
                list1 = list.split('<>')
                title = list1[0]
                name=title.split(' (')[0]
                year=title.split(' (')[1].replace(')','')
                rootname = list1[2]
                imdb = list1[1]
                thumb = list1[4]
                if ENABLE_META:
                    infoLabels = get_meta(name,'tvshow','',season=None,episode=None,imdb=imdb,episode_title=None)
                    if infoLabels['title']=='':
                        name=title
                    else:
                        name=infoLabels['title'] + ' (' + year + ')'
                    if infoLabels['cover_url']=='':
                        iconimage=thumb
                    else:
                        iconimage=infoLabels['cover_url']
                else:
                    infoLabels =None
                    name=title
                    iconimage=thumb
                addDir(name, imdb,210,iconimage, name,'','1','','tvshows',infoLabels=infoLabels)
    setView('tvshows', 'tvshows-view')
	
def favourites_artists(name):
    if os.path.isfile(FAV_ARTISTS):
        s = read_from_file(FAV_ARTISTS)
        search_list = s.split('\n')
        for list in search_list:
            if list != '':
                list1 = list.split('<>')
                artist = list1[0]
                url = list1[1]
                thumb = list1[4]
                addDir(clean_file_name(artist),url,305,thumb,'','','','','musicartist')
	
def favourites_albums(name):
    if os.path.isfile(FAV_ALBUMS):
        s = read_from_file(FAV_ALBUMS)
        search_list = s.split('\n')
        for list in search_list:
            if list != '':
                list1 = list.split('<>')
                title = list1[0]
                url = list1[1]
                thumb = list1[4]
                addDir(title,'url',303,thumb,'','','','','musicalbum')
				
def get_subscriptions(name,url):
    try:
        if os.path.isfile(SUB):
            s = read_from_file(SUB)
            search_list = s.split('\n')
            for list in search_list:
                if list != '':
                    list1 = list.split('<>')
                    title = list1[0]
                    url = list1[1]
                    thumb = list1[4]
                    create_tv_show_strm_files(title, url, thumb,url,thumb, 'false')
    except:
        xbmc.log("[What the Furk] Failed to fetch subscription")
				
def subscriptions():
    if os.path.isfile(SUB):
        s = read_from_file(SUB)
        search_list = s.split('\n')
        for list in search_list:
            if list != '':
                list1 = list.split('<>')
                title = list1[0]
                url = list1[1]
                thumb = list1[4]
                if ENABLE_META:
                    infoLabels = get_meta(title,'tvshow',year=None,season=None,episode=None,imdb=url)
                    if infoLabels['title']=='':
                        name=title
                    else:
                        name=infoLabels['title']
                    if infoLabels['cover_url']=='':
                        iconimage=thumb
                    else:
                        iconimage=infoLabels['cover_url']
                else:
                    infoLabels =None
                    name=title
                    iconimage=thumb
                addDir(name, url,210,iconimage, name,'','1','','tvshows',infoLabels=infoLabels)
			

		
####################### FILE SEARCH #######################################
def video_search(name, url, iconimage,rootname,imdb,videotype,source):
    length=''
    vid_info=''
    menu_texts = []
    menu_data = []
    menu_linkid = []    
    countfurk=0
    name_orig=name
    if SC_FURK:
        if videotype=='tvshows':
            name = "%s %s" % (rootname.split(' (')[0], name.split(' ')[0])
            season_name="%s Season %s" % (rootname.split(' (')[0], int(regex_from_to(name_orig,'S','E')))
        if (videotype=='movies' and (QUALITYSTYLE == "preferred" or ' 3D' in name)) or (videotype=='tvshows' and QUALITYSTYLE_TV == "preferred"):
            operator="%7C"
            if ' 3D' in name:
                searchstring = str(name.replace(",","").replace("-"," ").replace(" Documentary","").replace(" TV Movie","").replace(":"," ").replace("(","").replace(")",""))
            else:
                if videotype=='movies':
                    searchstring = "%s %s %s %s" % (str(name.replace("-"," ").replace(" Documentary","").replace(" TV Movie","").replace(":"," ").replace("(","").replace(")","")), str(CUSTOMQUALITY), str(operator), str(CUSTOMQUALITY2))
                else:
                    searchstring = "%s %s %s %s" % (str(name.replace("-"," ").replace(" TV Series","").replace(" Mini Series","").replace(":"," ").replace("(","").replace(")","")), str(TVCUSTOMQUALITY), str(operator), str(TVCUSTOMQUALITY2))
            files=[]
            try:
                files = search_furk(searchstring,"extended")
            except:pass
            count=0
            for f in files:
                if f.is_ready == "0":
                    count=count+1
                if (count == len(files) and len(files)>0) or len(files)==0:
                    time.sleep(F_DELAY)
                    notify = 'XBMC.Notification(No custom-quality files found,Now searching for any quality,3000)'
                    xbmc.executebuiltin(notify)
                    files.extend(search_furk(str(name.replace("-","").replace(" Documentary","").replace(" TV Movie","").replace(":","").replace("(","").replace(")","")), "all"))
        else:
            if videotype=='tvshows':
                quality_id = dialog.select("Select your preferred option", quality_list_tv)
                quality = quality_list_return_tv[quality_id]
            else:
                quality_id = dialog.select("Select your preferred option", quality_list)
                quality = quality_list_return[quality_id]
            if(quality_id < 0):
                return (None, None)
                dialog.close()
            if(quality_id == 0):
                if videotype=='tvshows':
                    searchstring = rootname.split(' (')[0]
                else:
                    searchstring = rootname
                keyboard = xbmc.Keyboard(searchstring, 'Custom Search', False)
                keyboard.doModal()
                if keyboard.isConfirmed():
                    searchstring = keyboard.getText()
            elif(quality_id == 1):
                searchstring = str(name.replace("-"," ").replace(" Documentary","").replace(" TV Movie","").replace(":"," ").replace("(","").replace(")",""))
            elif(quality_id == 2 and videotype=='tvshows'):
                searchstring = str(season_name.replace("-"," ").replace(" Documentary","").replace(" TV Movie","").replace(":"," ").replace("(","").replace(")",""))
            else:
                searchstring = "%s %s" % (str(name.replace("-"," ").replace(" Documentary","").replace(" TV Movie","").replace(":"," ").replace("(","").replace(")","")), quality)
            files=[]
            try:
                files = search_furk(searchstring, "all")
            except:pass

        if FURK_LIM_FS:
            fs_limit = FURK_LIM_FS_NUM
        else:
            fs_limit = 100
        for f in files:
            if float(f.size)/1073741824 < fs_limit and ((f.type == "video" and f.video_info.find("mpeg2video")<0) or f.is_ready =="0"):
                name = f.name.encode('utf-8','ignore')
                url = f.url_dl
                id = f.id
                video_info = f.video_info
                try:
                    match = re.compile('Duration: (.+?), start: (.+?),').findall(video_info)
                    match2 = re.compile('bitrate: (.+?) ').findall(video_info)
                    match1 = re.compile('Video: (.+?), (.+?), (.+?),').findall(video_info.replace('[',''))
                    for duration, start in match:
                        duration = duration.split('.')
                        length = duration[0]
                        timestr = duration[0]
                        ftr = [3600,60,1]
                        try:
                            duration = sum([a*b for a,b in zip(ftr, map(int,timestr.split(':')))])
                        except:duration=3600
                    for format, color, vid_info in match1:
                        vid_info = "%s %s" % (format, vid_info)
                    for bitrate in match2:
                        br = bitrate
                except:duration=3600;vid_info = '';br='';length=''
                is_ready = f.is_ready
                info_hash = f.info_hash
                size = f.size
                try:
                    bitrate = float(size)/duration*8/1024/1024
                except:
                    bitrate = 2
                if bitrate < float(DOWNLOAD_SPEED):
                    bitrate = "[COLOR lime][%.1fMbps][/COLOR]" % (bitrate)
                else:
                    bitrate = "[COLOR orange][%.1fMbps][/COLOR]" % (bitrate)
                size = float(size)/1073741824
                size = "[%.2fGB]" % size
                if videotype=='tvshows':
                    nameroot=rootname + ' : ' + name_orig
                else:
                    nameroot=rootname
                if  is_ready == "1" and f.type == "video" and f.url_dl != None:
                    text = "[COLOR gold]%s[/COLOR] %s [COLOR cyan]%s[/COLOR] info: %s %s" %(size, bitrate, name, length, vid_info)
                    try:
                        poster = f.ss_urls_tn[0]
                    except:
                        poster = iconimage
                    if source=='addon':
                        addDir(text, id,1001,poster, nameroot,imdb,url,url,'archive_' + videotype)
                        setView('movies', 'movies-view')
                    else:
                        menu_texts.append(text)
                        menu_data.append(url)
                        menu_linkid.append(id)
                else:
                    if source=='addon':
                        text = '[COLOR red]' + "%s %s" %(size, name)+ '[/COLOR]'
                        poster = iconimage
                        id = info_hash
                        if FURK_RESULTS == 'all':
                            addDirPlayable(text,id,1009,poster,nameroot,imdb,iconimage,'url','archive_' + videotype)
        setView('movies', 'movies-view')
        countfurk=len(files)
    if source == 'library':
        menu_id = dialog.select('Select Archive', menu_texts)
        if(menu_id < 0):
            return (None, None)
            dialog.close()
        else:
            id = str(menu_linkid[menu_id])
            furk_tfiles(name_orig, id, iconimage,rootname,imdb,'archive','library','play',iconimage)
    

def furksearch(query,match):
    query=query.replace('|',' %7C ').replace('...',' ')
    files = search_furk(query, match)

    if FURK_LIM_FS:
        fs_limit = FURK_LIM_FS_NUM
    else:
        fs_limit = 100
    for f in files:
        if float(f.size)/1073741824 < fs_limit and ((f.type == "video" and f.video_info.find("mpeg2video")<0) or f.is_ready =="0"):
            name = f.name.encode('utf-8','ignore')
            url = f.url_dl
            id = f.id
            video_info = f.video_info
            match = re.compile('Duration: (.+?), start: (.+?),').findall(video_info)
            match2 = re.compile('bitrate: (.+?) ').findall(video_info)
            match1 = re.compile('Video: (.+?), (.+?), (.+?),').findall(video_info.replace('[',''))
            for duration, start in match:
                duration = duration.split('.')
                length = duration[0]
                timestr = duration[0]
                ftr = [3600,60,1]
                duration = sum([a*b for a,b in zip(ftr, map(int,timestr.split(':')))])
            for format, color, vid_info in match1:
                vid_info = "%s %s" % (format, vid_info)
            for bitrate in match2:
                br = bitrate
            is_ready = f.is_ready
            info_hash = f.info_hash
            size = f.size
            try:
                bitrate = float(size)/duration*8/1024/1024
            except:
                bitrate = 2
            if bitrate < float(DOWNLOAD_SPEED):
                bitrate = "[COLOR lime][%.1fMbps][/COLOR]" % (bitrate)
            else:
                bitrate = "[COLOR orange][%.1fMbps][/COLOR]" % (bitrate)
            size = float(size)/1073741824
            size = "[%.2fGB]" % size
            if  is_ready == "1" and f.type == "video" and f.url_dl != None:
                text = "[COLOR gold]%s[/COLOR] %s [COLOR cyan]%s[/COLOR] info: %s %s" %(size, bitrate, name, length, vid_info)
                try:
                    poster = f.ss_urls_tn[0]
                except:
                    poster = iconimage
                addDir(text, id,1001,poster, query,'na',url,url,'archive_search')


def furksearchaudio(query,match,iconimage,rootname):
    origquery=query
    query=query.replace('|',' %7C ').replace('...',' ').replace(' - ',' ')
    files = search_furk(query, match)
    for f in files:
        if f.type == "audio":
            name = f.name.encode('utf-8','ignore')
            url = f.url_dl
            id = f.id
            is_ready = f.is_ready
            info_hash = f.info_hash
            size = f.size
            size = float(size)/1073741824
            size = "[%.2fGB]" % size
            if  is_ready == "1" and f.type == "audio" and f.url_dl != None:
                text = "[COLOR gold]%s[/COLOR] [COLOR cyan]%s[/COLOR]" %(size, name)
                addDir(text, id,1002,iconimage, origquery,'',url,"",'archive_audio')
            else:
                text = '[COLOR red]' + "%s %s" %(size, name)+ '[/COLOR]'
                id = info_hash
                mode1 = "add download"
                if FURK_RESULTS == 'all':
                    addDir(text, id,1002,iconimage, origquery,'na',url,"na",'archive_audio')
					
def login_at_furk():
    if FURK_ACCOUNT:
        if FURK.login(FURK_USER, FURK_PASS):
            return True
        else:
            #dialog = xbmcgui.Dialog()
            #dialog.ok("Login failed", "The addon failed to login at Furk.net.", "Make sure you have confirmed your email and your", "login information is entered correctly in addon-settings")
            return False
    else:
        return False
		
def search_furk(query, match, sort=FURK_SORT, filter=FURK_RESULTS, moderated=FURK_MODERATED):
    query = clean_file_name(query)
    query = query.replace('\'', ' ')
    if not login_at_furk():
        return []
    
    files = []
    search_result = FURK.search(query, match, sort,filter=FURK_RESULTS, moderated=FURK_MODERATED)
    #if search_result.query_changed == None:
    files = search_result.files
    return files
	
def furk_tfiles(name, id, iconimage,rootname,imdb,videotype,source,option,image):
    menu_texts = []
    menu_data = []
    menu_linkid = [] 
    tfiles=FURK.t_file_get(id, t_files="1")
    files = tfiles.files
    for f in files:
        countvideo = int(f.files_num_video)
        try:
            poster = f.ss_urls_tn[0]
        except:
            poster = ""
        t_files = f.t_files
    all_tf = regex_get_all(str(t_files), "{", "'}")
    count=0
    countsub=0
    autoplay_url=[]
    for tf in all_tf:
        all_td = regex_get_all(tf, "{", "'}")
        name2 = regex_from_to(str(all_td), "name': u'", "', u")
        format = name2[len(name2)-3:]
        url = regex_from_to(str(all_td), "url_dl': u'", "', u")
        duration = regex_from_to(str(all_td), "u'length': u'", "',")
        size = regex_from_to(str(all_td), "size': u'", "'")
        if duration == "0":
            bitrate = 5
            MBs = bitrate/8
        else:
            bitrate = float(size)/float(duration)*8/1024/1024
            MBs = bitrate/8
        if bitrate < float(DOWNLOAD_SPEED):
            bitrate = "[COLOR lime][%.1fMbps][/COLOR]" % (bitrate)
        else:
            bitrate = "[COLOR orange][%.1fMbps][/COLOR]" % (bitrate)
        size = float(size)/1073741824
        size = "[%.2fGB]" % size
        content = regex_from_to(str(all_td), "u'ct': u'", "/")
        text = "[%s] %s %s %s" %(format, size, name2, bitrate)
        if source=='addon' and (content == "video" and 'sample' not in name2.lower()) or (DOWNLOAD_SUB and name2.endswith('.srt')):
            videotype="vfile|%s|%s" % (videotype,MBs)
            count=count+1
            autoplay_url.append(url)
            addDirPlayable(text,url,2000,iconimage,rootname,imdb,iconimage,url.replace('?','<>').replace('=','>>'),videotype)
        if source=='addon' and (DOWNLOAD_SUB and name2.endswith('.srt')):
            countsub=countsub+1
        elif source=='library' and (content == "video" and 'sample' not in name2.lower()):
            count=count+1
            menu_texts.append(text)
            menu_data.append(url)
            menu_linkid.append(url)
    if source=='addon' and count==1 and (not DOWNLOAD_SUB or countsub==0) and option=='play':
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        listitem = xbmcgui.ListItem(rootname, iconImage=iconimage, thumbnailImage=image,path=url)
        playlist.add(autoplay_url[0],listitem)
        xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
        xbmcPlayer.play(playlist)
    if source=='library':
        if count==1:
            listitem = xbmcgui.ListItem(rootname + ': ' + name, iconImage=iconimage, thumbnailImage=image,path=menu_data[0])
            listitem.setProperty("IsPlayable", "true")
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
        else:
            menu_id = dialog.select('Select File', menu_texts)
            if(menu_id < 0):
                return (None, None)
                dialog.close()
            else:
                url = str(menu_linkid[menu_id])
                play(text, url, poster, rootname + ': ' + name,videotype,'NA',image,imdb)
       
			
def furk_tfiles_audio(name, id, iconimage,rootname,imdb,videotype,clear):
    browse=False
    if iconimage==None:
        iconimage=iconart
    if ' - ' in rootname:
        artist = rootname.split(' - ')[0]
        album = rootname.split(' - ')[1]
    else:
        artist=rootname
        album=rootname
    tfiles=FURK.t_file_get(id, t_files="1")
    files = tfiles.files
    if imdb!='queue':
        if dialog.yesno("What the Furk Music", 'Browse songs or play full album?', '', '', 'Play Now','Browse'):
            browse=True
    for f in files:
        t_files = f.t_files
    all_tf = regex_get_all(str(t_files), "{", "'}")
    nItem = len(all_tf)
    playlist=[]
    if browse==True:
        for tf in all_tf:
            all_td = regex_get_all(tf, "{", "'}")
            name = regex_from_to(str(all_td), "name': u'", "', u")
            format = name[len(name)-3:]
            url = regex_from_to(str(all_td), "url_dl': u'", "', u")
            duration = regex_from_to(str(all_td), "u'length': u'", "',")
            size = regex_from_to(str(all_td), "size': u'", "'")
            size = float(size)/1073741824
            size = "[%.2fGB]" % size
            try:
                content = regex_from_to(str(all_td), "u'ct': u'", "/")
            except:
                content="na"
            #text = "Furk [%s] %s %s" %(format, size, name)
            if name.lower().find('sample')<0 and content == "audio":
                addDirPlayable(clean_file_name(name, use_blanks=False),url,2001,iconimage,rootname,'na',url,url,videotype)
                liz=xbmcgui.ListItem(clean_file_name(name, use_blanks=False), iconImage=iconimage, thumbnailImage=iconimage)
                try:
                    liz.setInfo('music', {'Artist':artist, 'Album':album})
                except:
                    liz.setInfo('music', {'Artist':clean_file_name(origquery), 'Album':''})
                liz.setProperty('mimetype', 'audio/mpeg')
                liz.setProperty('fanart_image', fanart)
                liz.setThumbnailImage(iconimage)
                playlist.append((url, liz))
    else:
        pl = get_XBMCPlaylist(clear)
        for tf in all_tf:
            all_td = regex_get_all(tf, "{", "'}")
            name = regex_from_to(str(all_td), "name': u'", "', u")
            format = name[len(name)-3:]
            url = regex_from_to(str(all_td), "url_dl': u'", "', u")
            duration = regex_from_to(str(all_td), "u'length': u'", "',")
            size = regex_from_to(str(all_td), "size': u'", "'")
            size = float(size)/1073741824
            size = "[%.2fGB]" % size
            content = regex_from_to(str(all_td), "u'ct': u'", "/")
            dp = xbmcgui.DialogProgress()
            dp.create("What the Furk",'Creating Your Playlist')
            dp.update(0)
            if name.lower().find('sample')<0 and content == "audio":
                addDirPlayable(clean_file_name(name, use_blanks=False),url,2001,iconimage,rootname,'na',url,url,videotype)
                liz=xbmcgui.ListItem(clean_file_name(name, use_blanks=False), iconImage=iconimage, thumbnailImage=iconimage)
                try:
                    liz.setInfo('music', {'Title':name, 'Artist':artist, 'Album':album })
                    #liz.setInfo('music', {'Artist':artist, 'Album':album})
                except:
                    liz.setInfo('music', {'Title':name, 'Artist':clean_file_name(origquery), 'Album':'' })
                    #liz.setInfo('music', {'Artist':clean_file_name(origquery), 'Album':''})
                liz.setProperty('mimetype', 'audio/mpeg')
                liz.setThumbnailImage(iconimage)
                liz.setProperty('fanart_image', fanart)
                playlist.append((url, liz))

                progress = len(playlist) / float(nItem) * 100               
                dp.update(int(progress), 'Adding to Your Playlist',name)
                if dp.iscanceled():
                    return

        for blob ,liz in playlist:
            try:
                if blob:
                    pl.add(blob,liz)
            except:
                pass
        if clear or (not xbmc.Player().isPlayingAudio()):
            xbmc.Player(xbmc.PLAYER_CORE_DVDPLAYER).play(pl)
			
def get_XBMCPlaylist(clear):
    pl=xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
    if clear:
        pl.clear()
    return pl

    dialog = xbmcgui.Dialog()
    if dialog.yesno("What the Furk", 'Queue album or play now?', '', '', 'Play Now','Queue') == 0:
        pl.clear()
    return pl

		
def play(name, url, iconimage, rootname,videotype,url2,image,imdb):
    if url2 != 'NA':
        url=url2.replace('<>','?').replace('>>','=').replace('<<','&')
    dp = xbmcgui.DialogProgress()
    dp.create('Opening ' + rootname)
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()
    listitem = xbmcgui.ListItem(rootname, iconImage=iconimage, thumbnailImage=iconimage,path=url)
    playlist.add(url,listitem)
    xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
	
    handle = str(sys.argv[1])    
    if handle != "-1":
        listitem.setProperty("IsPlayable", "true")
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem)
    else:
        try:
            xbmcPlayer.play(playlist)
        except:
            dialog = xbmcgui.Dialog()
            dialog.ok("Playback failed", "Check your account settings")
    dp.close()
	
def alt_movie(name, url, iconimage):
    if 'tvdb' in url:
        name=urllib.unquote_plus(regex_from_to(url,'name=','&'))
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    ALT_PATH = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.whatthefurk'), 'Alt_Source')
    create_directory(ALT_PATH, "")
    xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
    file_name = '%s.strm' % name
    file_path = os.path.join(ALT_PATH, file_name)
    f = open(file_path, 'w')
    f.write(url)
    f.close()
    playlist.clear()
    listitem = xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage,path=url)
    playlist.add(url,listitem)
    xbmcPlayer.play(playlist)
    if os.path.exists(file_path):
        os.remove(file_path)

	
def playaudio(name, url, iconimage, rootname,videotype,parms,clear):
    artist = rootname.split(' - ')[0]
    album = rootname.split(' - ')[1]
    playlist=[]
    pl = get_XBMCPlaylist(clear)
    liz=xbmcgui.ListItem(clean_file_name(name, use_blanks=False), iconImage=iconimage, thumbnailImage=iconimage)
    liz.setInfo('music', {'Title':clean_file_name(name, use_blanks=False), 'Artist':artist, 'Album':album})
    liz.setProperty('mimetype', 'audio/mpeg')
    liz.setThumbnailImage(iconimage)
    playlist.append((url, liz))
    for blob ,liz in playlist:
        try:
            if blob:
                pl.add(blob,liz)
        except:
            pass
    if clear or (not xbmc.Player().isPlayingAudio()):
        xbmc.Player().play(pl)

def download_archive(name, url, iconimage, filename,imdb,videotype):
    if 'archive_audio' in videotype:
        zipname=filename
        artist = filename.split(' - ')[0]
        album = filename.split(' - ')[1]
    TEMP_PATH=settings.temp_path()
    if os.path.exists(TEMP_PATH):
        os.remove(TEMP_PATH)
    #vfile|archive_movies|0.429094070247
    splitvt=videotype.split('|')
    videotype=splitvt[0]
    loc=splitvt[1]
    Mbs=splitvt[2]
    action=splitvt[3]
    MBs = round(float(Mbs),0)
    WAITING_TIME = (MBs * 7) + 8
    if action=='delete':
        path=DOWNLOAD_TEMP
    else:
        if loc=='archive_tvshows':
            path=DOWNLOAD_TV
        elif loc=='archive_audio':
            path=DOWNLOAD_MUSIC
        else:
            path=DOWNLOAD_MOVIES
    if path=='set':
        dialog.ok("Download Path Not Set", "Please check addon settings (Download tab) and try again")
        return
    format = url[len(url)-3:]
    filename=filename[:filename.find(' : ')]
    if LIBRARY_FORMAT:
        downloadtitle="%s.%s" % (filename,format)
    else:
        downloadtitle=name
    origname=filename
    if videotype=='vfile':
        data_path = os.path.join(path, downloadtitle)
        dlThread = DownloadFileThread(filename, url, data_path, WAITING_TIME,action)
        dlThread.start()
        if action=='play' or action=='delete':
            wait(2, "Download starting")
            dp = xbmcgui.DialogProgress()
            dp.create('Wait for first 7 seconds to download')
            while (float(os.path.getsize(data_path))/1024/1024) < WAITING_TIME and xbmc.Player().isPlayingVideo() == False and os.path.exists(data_path):
                percent = min(((os.path.getsize(data_path)/1024/1024)  * 100/ int(WAITING_TIME)), 100)
                mbs = '%.0fMB of %.0fMB downloaded' % (os.path.getsize(data_path)/1024/1024, int(WAITING_TIME)) 
                dp.update(percent, mbs)
            if os.path.exists(data_path):
                ADDON.setSetting('temp_path', value=data_path)
                play(name, data_path, iconimage, origname,videotype,'NA',iconimage,imdb)
            else:
                xbmcgui.Dialog().ok('Download failed', name)
        else:
            notify = "%s,%s,%s" % ('XBMC.Notification(Download started',origname,'4000)')
            xbmc.executebuiltin(notify)
    else:
        if loc != 'archive_audio':
            keyboard = xbmc.Keyboard(filename, 'Directory Name (extract to)', False)
            keyboard.doModal()
            if keyboard.isConfirmed():
                directoryname = keyboard.getText()
                filename = "%s%s" % (directoryname, ".zip")
                url = "%s%s" % (imdb, ".zip")
                extract_path = create_directory(path, clean_file_name(directoryname, use_blanks=False))
                data_path = os.path.join(path, filename)
                dlThread = DownloadArchiveThread(filename, url, data_path, extract_path)
                dlThread.start()
                notify = "%s,%s,%s" % ('XBMC.Notification(Download started',origname,'4000)')
                xbmc.executebuiltin(notify)
        else:
            filename = "%s%s" % (zipname, ".zip")
            url = "%s%s" % (imdb, ".zip")
            artist_path = create_directory(path, clean_file_name(artist, use_blanks=False))
            extract_path = create_directory(artist_path, clean_file_name(album, use_blanks=False))
            data_path = os.path.join(path, filename)
            dlThread = DownloadArchiveThread(filename, url, data_path, extract_path)
            dlThread.start()
            notify = "%s,%s,%s" % ('XBMC.Notification(Download started',zipname,'4000)')
            xbmc.executebuiltin(notify)

class DownloadArchiveThread(Thread):
    def __init__(self, filename, url, data_path, extract_path):
        self.data = url
        self.path = data_path
        self.extpath = extract_path
        Thread.__init__(self)

    def run(self):
        path = str(self.path)
        data = self.data
        extract = str(self.extpath)
        urllib.urlretrieve(data, path)
        notify = "%s,%s,%s" % ('XBMC.Notification(Download finished',clean_file_name(name, use_blanks=False),'4000)')
        xbmc.executebuiltin(notify)
        notify = "%s,%s,%s" % ('XBMC.Notification(Extracting songs',clean_file_name(name, use_blanks=False),'4000)')
        xbmc.executebuiltin(notify)
        time.sleep(1)
        extractfiles(path,extract)
        os.remove(path)
        notify = "%s,%s,%s" % ('XBMC.Notification(Finished',clean_file_name(name, use_blanks=False),'4000)')
        xbmc.executebuiltin(notify)
		
class DownloadFileThread(Thread):
    def __init__(self, filename, url, data_path, WAITING_TIME,action):
        self.data = url
        self.path = data_path
        self.waiting = WAITING_TIME
        self.action = action
        Thread.__init__(self)

    def run(self):
        start_time = time.time() + 30 + self.waiting
        path = str(self.path)
        data = self.data
        waiting = self.waiting
        action = self.action
        try:
            urllib.urlretrieve(data, path, lambda nb, bs, fs: self._dlhook(nb, bs, fs, self, start_time, path, waiting,action))
        except:
            if sys.exc_info()[0] in (urllib.ContentTooShortError, StopDownloading, OSError):
                time.sleep(2)
                if os.path.exists(path) and action=='delete':
                    os.remove(path)
                return False 
            else: 
                raise
            return False
        notify = "%s,%s,%s" % ('XBMC.Notification(Download finished',clean_file_name(name, use_blanks=False),'4000)')
        xbmc.executebuiltin(notify)
		
    def _dlhook(self, numblocks, blocksize, filesize, dt, start_time, path, waiting,action):
        if time.time() > start_time:
            if xbmc.Player().isPlayingVideo() == False and action == "delete":
                print "Stopped playing, stopping download, deleting file"   
                raise StopDownloading('Stopped Downloading')
                callEndOfDirectory = False
		
def extractfiles(filepath, extpath):
    import zipfile
    try:
        zipn = zipfile.ZipFile(filepath, 'r')
        zipn.extractall(extpath)
    except Exception, e:
        print str(e)
        return False
    return True
	
def test_dl_speed(name,url):
    dialog = xbmcgui.Dialog()
    dp = xbmcgui.DialogProgress()
    dp.create('Testing Download Speed')
    path = os.path.join(DOWNLOAD_MOVIES, "test_download.avi")
    start_time = time.time()
    try:
        urllib.urlretrieve(url, path, lambda nb, bs, fs: _pbhook(nb, bs, fs, dp, start_time))
    except:
        if sys.exc_info()[0] in (urllib.ContentTooShortError, StopDownloading, OSError):
            end_time = time.time()
            size = float(os.path.getsize(path)) * 8
            kbps_speed = size / (end_time - start_time)
            kbps_speed = kbps_speed / 1024 / 1024
            e = 'Download Speed: %.02f Mb/s ' % kbps_speed	
            if os.path.exists(path):
                os.remove(path)			
            xbmcgui.Dialog().ok('Download cancelled',e)
            ADDON.setSetting('download_speed', value=str(kbps_speed))
            return False 
        else: 
            raise
        return False
    end_time = time.time()
    size = float(os.path.getsize(path)) * 8
    kbps_speed = size / (end_time - start_time)
    kbps_speed = kbps_speed / 1024 / 1024
    if os.path.exists(path):
        os.remove(path)
    e = 'Download Speed: %.02f Mb/s ' % kbps_speed
    dialog.ok("Speed Test Result", e)
    ADDON.setSetting('download_speed', value=str(kbps_speed))
	
def _pbhook(numblocks, blocksize, filesize, dp, start_time):
    try: 
        percent = min(numblocks * blocksize * 100 / filesize, 100) 
        currently_downloaded = float(numblocks) * blocksize / (1024 * 1024) 
        kbps_speed = numblocks * blocksize / (time.time() - start_time) 
        if kbps_speed > 0: 
            eta = (filesize - numblocks * blocksize) / kbps_speed 
        else: 
            eta = 0 
        kbps_speed = kbps_speed / 1024 / 1024 * 8
        total = float(filesize) / (1024 * 1024) 
        mbs = '%.02f MB of %.02f MB' % (currently_downloaded, total) 
        e = 'Speed: %.02f Mb/s ' % kbps_speed 
        e += 'ETA: %02d:%02d' % divmod(eta, 60) 
        dp.update(percent, mbs, e)
    except: 
        percent = 100 
        dp.update(percent) 
    if dp.iscanceled(): 
        dp.close()
        raise StopDownloading('Stopped Downloading')
		
class StopDownloading(Exception): 
    def __init__(self, value): 
        self.value = value 
    def __str__(self): 
        return repr(self.value)

def add_favourite(name, url, rootname, imdb,iconimage, dir, text):
    list_data ="%s<>%s<>%s<>%s<>%s" % (name, url, rootname,imdb,iconimage)
    add_to_list(list_data, dir)
    notification(name, "[COLOR lime]" + text + "[/COLOR]", '5000', iconimage)
	
def remove_from_favourites(name, url, rootname, imdb,iconimage, dir, text):
    list_data ="%s<>%s<>%s<>%s<>%s" % (name, url, rootname,imdb,iconimage)
    splitdata = list_data.split('QQ')
    remove_from_list(list_data, dir)
    notification(name, "[COLOR orange]" + text + "[/COLOR]", '5000', iconimage)

def create_tv_show_strm_files(name, imdb_id, iconimage,imdb,image, ntf):
    if name.find(' (')>0:
        name = name[:-7]
    if 'trakt' in imdb_id:
        body = get_url(url, cache=CACHE_PATH).translate(trans_table)
        imdb_id=regex_from_to(body,'href="http://imdb.com/title/','"')
    n = name
    u = imdb_id
    l = iconimage
    info = TheTVDBInfo(imdb_id)
    episodes = info.episodes()
    
    tv_show_path = create_directory(TV_PATH, name)
    for episode in episodes:
        first_aired = episode.FirstAired()
        if len(first_aired) > 0:
            d = first_aired.split('-')
            episode_date = date(int(d[0]), int(d[1]), int(d[2]))
            if date.today() > episode_date:
                season_number = int(episode.SeasonNumber())
                if season_number > 0:
                    episode_number = int(episode.EpisodeNumber())
                    episode_name = episode.EpisodeName()
                    display = "[S%.2dE%.2d] %s" % (season_number, episode_number, episode_name)
                    data = '%s<|>%s<|>%d<|>%d' % (name, episode_name, season_number, episode_number)
                    season_path = create_directory(tv_show_path, str(season_number))
                    create_strm_file(display, data, '1100', season_path, l, n,u,'tvshows')
    if ntf == "true" and ENABLE_SUBS:
        if dialog.yesno("Subscribe?", 'Do you want What the Furk to automatically add new', '[COLOR gold]' + name + '[/COLOR]' + ' episodes when available?'):
            add_favourite(n, u, n, '',image, SUB, "Added to Library/Subscribed")
        else:
            notification(name, "[COLOR lime]Added to Library[/COLOR]", '5000', iconimage)
    if xbmc.getCondVisibility('Library.IsScanningVideo') == False:           
        xbmc.executebuiltin('UpdateLibrary(video)')

def remove_movie_strm_files(name, url, rootname,imdb,iconimage, dir):
    dialog = xbmcgui.Dialog()
    #try:
    path = os.path.join(dir, str(rootname) + '.strm')
    os.remove(path)
    if xbmc.getCondVisibility('Library.IsScanningVideo') == False:
        if dialog.yesno("Clean Library?", '', 'Do you want clean the library now?'):		
            xbmc.executebuiltin('CleanLibrary(video)')		
    #except:
        #xbmc.log("[What the Furk] Unable to remove %s from library" % (rootname)) 

def remove_tv_show_strm_files(name, url, iconimage,imdb,image, dir_path):
    dialog = xbmcgui.Dialog()
    try:
        path = os.path.join(dir_path, str(name))
        shutil.rmtree(path)
        remove_from_favourites(name, url, name, imdb ,image, SUB, "Removed from Library/Unsubscribed")
        if xbmc.getCondVisibility('Library.IsScanningVideo') == False:
            if dialog.yesno("Clean Library?", '', 'Do you want clean the library now?'):		
                xbmc.executebuiltin('CleanLibrary(video)')		
    except:
        xbmc.log("[What the Furk] Was unable to remove TV show: %s" % (name))
		
################CONTEXT OTHER ADDONS###############################
xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
def create_directory(dir_path, dir_name=None):
    if dir_name:
        dir_path = os.path.join(dir_path, dir_name)
    dir_path = dir_path.strip()
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
    return dir_path

def create_file(dir_path, file_name=None):
    if file_name:
        file_path = os.path.join(dir_path, file_name)
    file_path = file_path.strip()
    if not os.path.exists(file_path):
        f = open(file_path, 'w')
        f.write('')
        f.close()
    return file_path
	
DATA_PATH = os.path.join(xbmc.translatePath('special://profile/addon_data/plugin.video.whatthefurk'), '')
	
TRAKT_ID_PATH = create_file(DATA_PATH, "trakt_ids.list")
ONECH_URL_PATH = create_file(DATA_PATH, "1channel_urls.list")
TV4ME_URL_PATH = create_file(DATA_PATH, "tv4me_urls.list")

def get_trakt_ids(query,db_type):
    traktid="na"
    if os.path.isfile(TRAKT_ID_PATH):
        s = read_from_file(TRAKT_ID_PATH)
        search_list = s.split('\n')
        for list in search_list:
            if list != '':
                list1 = list.split('<>')
                name = list1[0]
                type = list1[1]
                trakt = list1[2]
                if name==query and type==db_type:
                    traktid=trakt
    if traktid=="na": 
        header_dict = {}
        header_dict['Content-Type'] = 'application/json'
        header_dict['trakt-api-key'] = traktapi
        header_dict['trakt-api-version'] = '2'
        if query.startswith('tt'):
            url = 'http://api-v2launch.trakt.tv/search?id_type=imdb&id=%s' % (query)
        else:
            if db_type=='episode':
                url = 'http://api-v2launch.trakt.tv/search?query=%s&type=show' % (query)
            else:
                url = 'http://api-v2launch.trakt.tv/search?query=%s&type=movie' % (query)
        req=requests.get(url,headers=header_dict).content
        data=json.loads(req)
        traktid=[]
        for i in data:
            try:
                traktids = i['show']['ids']['trakt']
                traktname = i['show']['title']
            except:
                traktids = i['movie']['ids']['trakt']
            traktid.append(traktids)
        text="%s<>%s<>%s" % (query,db_type,str(traktid[0]))
        add_to_list(text,TRAKT_ID_PATH)
        traktid=str(traktid[0])
    return traktid
	
def get_1channel_url(title):
    urlreturn="na"
    if os.path.isfile(ONECH_URL_PATH):
        s = read_from_file(ONECH_URL_PATH)
        search_list = s.split('\n')
        for list in search_list:
            if list != '':
                list1 = list.split('<>')
                name = list1[0]
                url = list1[1]
                if name==title:
                    urlreturn=url
    if urlreturn=="na":
        url='http://www.primewire.ag/'
        link = requests.get(url).content
        key=regex_from_to(link,'"hidden" name="key" value="', '"')
        url='http://www.primewire.ag/index.php?search_keywords=%s&key=%s&search_section=1' % (title,key)
        link = requests.get(url).content
        urlreturn=regex_from_to(link,'index_item index_item_ie"><a href="','"').replace('-online-free','').replace('watch-','tv-')
        text="%s<>%s" % (title,urlreturn)
        add_to_list(text,ONECH_URL_PATH)
    return urlreturn
	
def get_tv4me_url(query,season,episode):
    urlreturn="na"
    if os.path.isfile(TV4ME_URL_PATH):
        s = read_from_file(TV4ME_URL_PATH)
        search_list = s.split('\n')
        for list in search_list:
            if list != '':
                list1 = list.split('<>')
                name = list1[0]
                url = list1[1]
                if name==query:
                    showurl=url
    if urlreturn=="na":
        url='http://www.watch-tvseries.net/play/menulist'
        link = requests.get(url).content
        match = re.compile("<li><a href='(.+?)'>(.+?)</a></li>").findall(link)
        for url, title in match:
            if query.lower() in title.lower():
                if not 'http://www.watch-tvseries.net' in url:
                    showurl='http://www.watch-tvseries.net' + url
                    text="%s<>%s" % (query,showurl)
                    add_to_list(text,TV4ME_URL_PATH)
    link = requests.get(showurl).content
    episodes = re.compile('<a title="(.+?)" href="(.+?)"> <div class="(.+?)data-original="(.+?)"(.+?)nseasnumep"> (.+?) <br(.+?)>(.+?) </div> </div> </a>').findall(link)
    for epname, url, a, thumb, b, snum, c, epnum in episodes:
        epnum = int(epnum.replace('episode ', ''))
        snum = int(snum.replace('season ', ''))
        if str(snum)==str(season) and str(epnum)==str(episode):
            urlreturn = 'http://www.watch-tvseries.net' + url
    return urlreturn

def alt_play(select_addon, db_type, iconimage,imdb, viddetail):
    xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
    currenttvdb=""
    currentimdb=imdb
    currenttmdb=""
    currenttvrage=""
    alter='0'
    date=''
    vsplit=viddetail.split('<>')
    title=vsplit[0]
    data = "%s<>%s<>%s<>%s<>%s<>%s<>%s" % (viddetail,currenttvdb,currentimdb,currenttvrage,currenttmdb,alter,date)
    url=get_url_alt(select_addon,db_type,data,iconimage)
    if url == ' not found':
        dialog.ok("Title Not Found", "Unable to find " + title + " using: " + select_addon, "Please try a different addon")
        return
    else:
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
        playlist.clear()
        listitem = xbmcgui.ListItem(title, iconImage=iconimage, thumbnailImage=iconimage,path=url)
        playlist.add(url,listitem)
        xbmcPlayer.play(playlist)
		
			
def get_url_alt(select_addon,db_type,data,iconimage):
    dsplit=data.split('<>')
    if db_type=='tvshows':
        SE = "S%.2dE%.2d" % (int(dsplit[1]), int(dsplit[2]))
    rootname=urllib.quote(dsplit[0] + ' ' + dsplit[5])
    if dsplit[4]=="":
        imdb=dsplit[7]
    else:
        imdb=dsplit[4]
    if db_type == 'movies':
        if select_addon == 'genesis':
            url='plugin://plugin.video.genesis/?action=play&name=%s&title=%s&year=%s&imdb=%s&tmdb=' % (urllib.quote_plus(dsplit[0] + ' ' + dsplit[5]),urllib.quote_plus(dsplit[0]), urllib.quote(dsplit[5]), urllib.quote(imdb))
        if select_addon=='1channel':
            try:
                u=get_1channel_url(dsplit[0])
                url='plugin://plugin.video.1channel/?img=%s&title=%s&url=%s&imdbnum=&video_type=movie&mode=GetSources&dialog=1&year=%s' % (urllib.quote(iconimage),dsplit[0],urllib.quote(u),dsplit[5])
            except:
                url='not found'
        if select_addon == 'salts':####trakt id search
            if imdb=="":
                traktid=get_trakt_ids(dsplit[0],db_type)
            else:
                traktid=get_trakt_ids(imdb,db_type)
            url='plugin://plugin.video.salts/?title=%s&video_type=Movie&trakt_id=%s&mode=get_sources&dialog=True&year=%s' % (urllib.quote_plus(dsplit[0]),traktid,dsplit[5])
    elif db_type == 'tvshows':
        if select_addon == 'genesis':
            gtitle="%s %s" % (dsplit[0],SE)
            url='plugin://plugin.video.genesis/?action=play&name=%s&title=&year=%s&imdb=%s&tmdb=&tvdb=&tvrage=&season=%s&episode=%s&tvshowtitle=%s&alter=0&date=' % (urllib.quote_plus(gtitle), dsplit[5], urllib.quote(imdb), dsplit[1], dsplit[2], urllib.quote_plus(dsplit[0]))
        if select_addon=='1channel':
            try:
                u=get_1channel_url(dsplit[0])
                url='plugin://plugin.video.1channel/?img=&imdbnum=&url=%s/season-%s-episode-%s&title=%s&video_type=episode&mode=GetSources&dialog=1' % (urllib.quote(u),dsplit[1],dsplit[2],urllib.quote(dsplit[0]))
            except:
                url='not found'
        if select_addon == 'salts':
            if imdb=="":
                traktid=get_trakt_ids(dsplit[0],db_type)
            else:
                traktid=get_trakt_ids(imdb,db_type)
            url='plugin://plugin.video.salts/?ep_airdate=1970-01-01&trakt_id=%s&episode=%s&mode=get_sources&dialog=True&title=%s&ep_title=%s&season=%s&year=%s&video_type=Episode' % (traktid,dsplit[2],urllib.quote_plus(dsplit[0]),urllib.quote_plus(dsplit[3]),dsplit[1],dsplit[5])
        if select_addon == 'tv4me':
            gtitle="%s %s" % (dsplit[0],SE)#
            tv4meurl=get_tv4me_url(dsplit[0],int(dsplit[1]),int(dsplit[2]))
            url='plugin://plugin.video.tv4me/?name=%s&url=%s&mode=5&iconimage=%s&showname=%s' % (urllib.quote(gtitle),urllib.quote(tv4meurl),urllib.quote(iconimage),"")
    return url


def get_file_age(file_path):
    try:    
        stat = os.stat(file_path)
        fileage = datetime.fromtimestamp(stat.st_mtime)
        now = datetime.now()
        delta = now - fileage
        return delta.seconds
    except:
        return -1
	
def alternate_source(name,url,iconimage,rootname,imdb,db_type):
    addon_list_return=[]
    addon_list=[]
    count=-1
    if db_type=='movies':
        al = ["Genesis","1 Channel","SALTS"]
        alr = ["genesis", "1channel","salts"]
        title = name.split(' (')[0]
        season = ""
        epnumber = ""
        epname = ""
        imdb = imdb
        year = name.split(' (')[1].replace(')','')
        iconimage = iconimage
    else:
        al = ["Genesis","1 Channel","SALTS","TV4ME"]
        alr = ["genesis", "1channel","salts","tv4me"]
        if ' (' in rootname:
            title = rootname.split(' (')[0]
            year = rootname.split(' (')[1].replace(')','')
        else:
            title = rootname
            year=""
        season = int(regex_from_to(name,'S','E'))
        epnumber = int(regex_from_to(name,'E',' ').replace(']',''))
        epname = ""
        imdb = imdb
        iconimage = iconimage
    viddetail="%s<>%s<>%s<>%s<>%s<>%s" % (title,season,epnumber,epname,imdb,year)
    for a in alr:
        count+=1
        if os.path.exists(xbmc.translatePath("special://home/addons/plugin.video.%s") % a):
            addon_list_return.append(a)
            addon_list.append(al[count])
    addon_id = dialog.select("Play using......", addon_list)
    select_addon = addon_list_return[addon_id]
    if addon_id>-1:
        alt_play(select_addon, db_type, iconimage,imdb, viddetail)	
################END ONTEXT OTHER ADDONS###################################

		
def create_directory(dir_path, dir_name=None):
    if dir_name:
        dir_path = os.path.join(dir_path, dir_name)
    dir_path = dir_path.strip()
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
    return dir_path

def create_file(dir_path, file_name=None):
    if file_name:
        file_path = os.path.join(dir_path, file_name)
    file_path = file_path.strip()
    if not os.path.exists(file_path):
        f = open(file_path, 'w')
        f.write('')
        f.close()
    return file_path
	

	
def create_strm_file(name, url, mode, dir_path, iconimage, rootname,imdb,videotype):#(name, url, '1000', MOVIE_PATH, iconimage, rootname,imdb)
    #try:
    strm_string = create_url(name, mode, url=url, iconimage=iconimage, rootname=rootname,imdb=imdb,videotype=videotype)
    filename = clean_file_name("%s.strm" % name)
    path = os.path.join(dir_path, filename)
    if not os.path.exists(path):
        stream_file = open(path, 'w')
        stream_file.write(strm_string)
        stream_file.close()
    #except:
        #xbmc.log("[What the Furk] Error while creating strm file for : " + name)
		
def create_url(name, mode, url, iconimage, rootname,imdb,videotype):
    name = urllib.quote(str(name))
    data = urllib.quote(str(url))
    iconimage = urllib.quote(str(iconimage))
    rootname = urllib.quote(str(rootname))
    imdb = urllib.quote(str(imdb))
    mode = str(mode)
    videotype = urllib.quote(str(videotype))
    url = sys.argv[0] + '?name=%s&url=%s&mode=%s&iconimage=%s&rootname=%s&imdb=%s&videotype=%s' % (name, data, mode, iconimage, rootname,imdb,videotype)
    return url
	


def regex_from_to(text, from_string, to_string, excluding=True):
    if excluding:
        r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
    else:
        r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
    return r

def regex_get_all(text, start_with, end_with):
    r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
    return r

def strip_text(r, f, t, excluding=True):
    r = re.search("(?i)" + f + "([\S\s]+?)" + t, r).group(1)
    return r


def find_list(query, search_file):
    try:
        content = read_from_file(search_file) 
        lines = content.split('\n')
        index = lines.index(query)
        return index
    except:
        return -1
		
def find_lib(query, dir, type):
    if type=='movies':
        dir_path = os.path.join(dir, query + '.strm')
    else: dir_path = os.path.join(dir, query)
    if os.path.exists(dir_path):
        return 1
    else:
        return -1
		
def add_to_list(list, file):
    if find_list(list, file) >= 0:
        return

    if os.path.isfile(file):
        content = read_from_file(file)
    else:
        content = ""

    lines = content.split('\n')
    s = '%s\n' % list
    for line in lines:
        if len(line) > 0:
            s = s + line + '\n'
    write_to_file(file, s)
    #xbmc.executebuiltin("Container.Refresh")
    
def remove_from_list(list, file):
    index = find_list(list, file)
    if index >= 0:
        content = read_from_file(file)
        lines = content.split('\n')
        lines.pop(index)
        s = ''
        for line in lines:
            if len(line) > 0:
                s = s + line + '\n'
        write_to_file(file, s)
        #xbmc.executebuiltin("Container.Refresh")
		
def write_to_file(path, content, append=False, silent=False):
    try:
        if append:
            f = open(path, 'a')
        else:
            f = open(path, 'w')
        f.write(content)
        f.close()
        return True
    except:
        if not silent:
            print("Could not write to " + path)
        return False

def read_from_file(path, silent=False):
    try:
        f = open(path, 'r')
        r = f.read()
        f.close()
        return str(r)
    except:
        if not silent:
            print("Could not read from " + path)
        return None

def wait_dl_only(time_to_wait, title):
    print 'Waiting ' + str(time_to_wait) + ' secs'    

    progress = xbmcgui.DialogProgress()
    progress.create(title)
    
    secs = 0
    percent = 0
    
    cancelled = False
    while secs < time_to_wait:
        secs = secs + 1
        percent = int((100 * secs) / time_to_wait)
        secs_left = str((time_to_wait - secs))
        remaining_display = ' waiting ' + secs_left + ' seconds for download to start...'
        progress.update(percent, remaining_display)
        xbmc.sleep(1000)
        if (progress.iscanceled()):
            cancelled = True
            break
    if cancelled == True:     
        print 'wait cancelled'
        return False
    else:
        print 'Done waiting'
        return True

def get_meta(name,types=None,year=None,season=None,episode=None,imdb=None,episode_title=None):
    if 'movie' in types:
        meta = metainfo.get_meta('movie',name,year)
        infoLabels = {'rating': meta['rating'],'genre': meta['genre'],'mpaa':"rated %s"%meta['mpaa'],'plot': meta['plot'],'title': meta['title'],'cover_url': meta['cover_url'],'fanart': meta['backdrop_url'],'Aired': meta['premiered'],'year': meta['year'],'imdb': meta['imdb_id']}
    if 'tvshow' in types:
        meta = metainfo.get_meta('tvshow',name,imdb,year)
        infoLabels = {'rating': meta['rating'],'genre': meta['genre'],'mpaa':"rated %s"%meta['mpaa'],'plot': meta['plot'],'title': meta['title'],'cover_url': meta['cover_url'],'fanart': meta['backdrop_url'],'Episode': meta['episode'],'Aired': meta['premiered']}
    if 'episode' in types:
        meta = metainfo.get_episode_meta(name, imdb, season, episode)
        infoLabels = {'rating': meta['rating'],'genre': meta['genre'],'mpaa':"rated %s"%meta['mpaa'],'plot': meta['plot'],'title': meta['title'],'cover_url': meta['cover_url'],'fanart': meta['backdrop_url'],'Episode': meta['episode'],'Aired': meta['premiered']}
        
    return infoLabels 
	
deletemetafiles()
		
def notification(title, message, ms, nart):
    xbmc.executebuiltin("XBMC.notification(" + title + "," + message + "," + ms + "," + nart + ")")
	
def setView(content, viewType):
	# set content type so library shows more views and info
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if ADDON.getSetting('auto-view') == 'true':
		xbmc.executebuiltin("Container.SetViewMode(%s)" % ADDON.getSetting(viewType) )
   

def get_params():
        param=[]
        paramstring=sys.argv[2]
        if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param

def addDir(name,url,mode,iconimage,rootname,imdb,start,parms,videotype,infoLabels=None):
        suffix = ""
        suffix2 = ""
        if ' - ' in name:
            named=name.split(' - ')[0]
        else:named=name
        list="%s<>%s<>%s<>%s<>%s" % (named, url, rootname,imdb,iconimage)
        listp="%s<>%s<>blank<>blank<>%s" % (named, url, iconimage)
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+str(iconimage)+"&rootname="+str(rootname)+"&imdb="+str(imdb)+"&start="+urllib.quote_plus(start)+"&parms="+urllib.quote_plus(parms)+"&videotype="+urllib.quote_plus(videotype)
        ok=True
        contextMenuItems = []
        if videotype=='actors':
            if find_list(listp, FAV_PEOPLE) < 0:
                suffix = ""
                contextMenuItems.append(("[COLOR cyan]Save to My People[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=605&rootname=%s&imdb=%s&iconimage=%s)'%(sys.argv[0], name, url, rootname,imdb,iconimage)))
            else:
                suffix = ' [COLOR lime]+[/COLOR]'
                contextMenuItems.append(("[COLOR orange]Remove from My People[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=606&rootname=%s&imdb=%s&iconimage=%s)'%(sys.argv[0], name, url, rootname,imdb,iconimage)))
        if videotype.startswith('archive') or videotype=='mfd' or videotype=='mff':
            contextMenuItems.append(("[COLOR cyan]Browse Archive[/COLOR]",'XBMC.Container.Update(%s?name=%s&url=%s&mode=1003&iconimage=%s&rootname=%s&imdb=%s&videotype=%s&parms=%s)'%(sys.argv[0], urllib.quote(name), urllib.quote(url), urllib.quote(iconimage),urllib.quote(rootname),urllib.quote(imdb),urllib.quote(videotype),urllib.quote(parms))))
            contextMenuItems.append(("[COLOR cyan]Download Archive[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=3001&iconimage=%s&rootname=%s&imdb=%s&videotype=%s)'%(sys.argv[0], urllib.quote(name), urllib.quote(start), urllib.quote(iconimage),urllib.quote(rootname),urllib.quote(start),urllib.quote(videotype))))
        if videotype.startswith('archive') or videotype=='mfd':
            contextMenuItems.append(("Add to My Files",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=551)'%(sys.argv[0], urllib.quote(name), urllib.quote(url))))
        if videotype=='mfd':
            contextMenuItems.append(("Clear deleted file",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=553)'%(sys.argv[0], urllib.quote(name), urllib.quote(url))))
        if videotype=='mff':
            contextMenuItems.append(("Remove from My Files",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=552)'%(sys.argv[0], urllib.quote(name), urllib.quote(url))))
            contextMenuItems.append(("Protect - My Files",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=554)'%(sys.argv[0], urllib.quote(name), urllib.quote(url))))
            contextMenuItems.append(("Unprotect - My Files",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=555)'%(sys.argv[0], urllib.quote(name), urllib.quote(url))))
        if name == "TV Subscriptions":
            contextMenuItems.append(("[COLOR cyan]Refresh Subscriptions[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=18)'%(sys.argv[0], urllib.quote(name), urllib.quote(url))))
        if videotype == "movies":
            title=rootname.split(' (')[0]
            year=rootname.split(' (')[1].replace(')','')
            contextMenuItems.append(('Movie Information', 'XBMC.Action(Info)'))
            contextMenuItems.append(("[COLOR cyan]Use Alternative Addon[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=5000&iconimage=%s&rootname=%s&imdb=%s&videotype=%s)'%(sys.argv[0], urllib.quote(name), urllib.quote(url), urllib.quote(iconimage),urllib.quote(rootname),urllib.quote(imdb),urllib.quote(videotype))))
            contextMenuItems.append(("[COLOR cyan]View Trailer[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=150&iconimage=%s)'%(sys.argv[0], urllib.quote(name), urllib.quote(url), urllib.quote(iconimage))))
            contextMenuItems.append(("[COLOR cyan]IMDB users also like....[/COLOR]",'XBMC.Container.Update(%s?name=%s&url=%s&mode=151&iconimage=%s&imdb=%s)'%(sys.argv[0], urllib.quote(name), urllib.quote(url), urllib.quote(iconimage),urllib.quote(imdb))))
            if find_list(list, FAV) < 0:
                suffix = ""
                contextMenuItems.append(("[COLOR lime]Add to WtF Favourites[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=11&rootname=%s&imdb=%s&iconimage=%s)'%(sys.argv[0], name, url, rootname,imdb,iconimage)))
            else:
                suffix = ' [COLOR lime]+[/COLOR]'
                contextMenuItems.append(("[COLOR orange]Remove from WtF Favourites[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=13&rootname=%s&imdb=%s&iconimage=%s)'%(sys.argv[0], name, url, rootname,imdb,iconimage)))
            if find_lib(rootname, MOVIE_PATH,"movies") < 0:
                suffix2 = ""
                contextMenuItems.append(("[COLOR lime]Add to Library[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=20&rootname=%s&imdb=%s&iconimage=%s)'%(sys.argv[0], name, url, rootname,imdb,iconimage)))
            else:
                suffix2 = ' [COLOR cyan][L][/COLOR]'
                contextMenuItems.append(("[COLOR orange]Remove from Library[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=21&rootname=%s&imdb=%s&iconimage=%s)'%(sys.argv[0], name, url, rootname,imdb,iconimage)))
        if videotype == "tvshows":
            contextMenuItems.append(('TV Show Information', 'XBMC.Action(Info)'))
            if ' - ' in name:
                contextMenuItems.append(("[COLOR cyan]Use Alternative Addon[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=5000&iconimage=%s&rootname=%s&imdb=%s&videotype=%s)'%(sys.argv[0], urllib.quote(name), urllib.quote(url), urllib.quote(iconimage),urllib.quote(rootname),urllib.quote(imdb),urllib.quote(videotype))))
                episode = name.split(' - ')[0]
                epname = name.split(' - ')[1]
                sn=int(regex_from_to(episode,'S','E'))
                en=int(episode[episode.find('E')+1:])
                title=rootname.split(' (')[0]
                gtitle="%s %s" % (title,episode)
                try:
                    year=rootname.split(' (')[1].replace(')','')
                except:year=""
            if find_list(list, FAV_TV) < 0:
                suffix = ""
                contextMenuItems.append(("[COLOR lime]Add to WtF Favourites[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=132&rootname=%s&imdb=%s&iconimage=%s)'%(sys.argv[0], name, url, rootname,imdb,iconimage)))
            else:
                suffix = ' [COLOR lime]+[/COLOR]'
                contextMenuItems.append(("[COLOR orange]Remove from WtF Favourites[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=133&rootname=%s&imdb=%s&iconimage=%s)'%(sys.argv[0], name, url, rootname,imdb,iconimage)))
            if find_list(list, SUB) < 0:
                suffix2 = ""
                contextMenuItems.append(("[COLOR lime]Add to Library/Subscribe[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=14&rootname=%s&imdb=%s&iconimage=%s)'%(sys.argv[0], name, url, rootname,imdb,iconimage)))
            else:
                suffix2 = ' [COLOR cyan][s][/COLOR]'
                contextMenuItems.append(("[COLOR orange]Remove from Library[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=15&rootname=%s&imdb=%s&iconimage=%s)'%(sys.argv[0], name, url, rootname,imdb,iconimage)))
        if videotype == "archive_audio":
            contextMenuItems.append(("[COLOR cyan]Queue Archive[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=1004&iconimage=%s&rootname=%s&imdb=%s&videotype=%s)'%(sys.argv[0], urllib.quote(name), urllib.quote(url), urllib.quote(iconimage),urllib.quote(rootname),'queue',urllib.quote(videotype))))
        if videotype == "musicartist":
            contextMenuItems.append(("[COLOR lime]Add to Favourite Artists[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=810&iconimage=%s&rootname=%s&imdb=%s&videotype=%s)'%(sys.argv[0], urllib.quote(name), urllib.quote(url), urllib.quote(iconimage),urllib.quote(rootname),'fav',urllib.quote(videotype))))
        if videotype == "musicalbum":
            contextMenuItems.append(("[COLOR lime]Add to Favourite Albums[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=811&iconimage=%s&rootname=%s&imdb=%s&videotype=%s)'%(sys.argv[0], urllib.quote(name), urllib.quote(url), urllib.quote(iconimage),urllib.quote(rootname),'fav',urllib.quote(videotype))))
        liz=xbmcgui.ListItem(name + suffix + suffix2, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        if mode == 1001:
            liz.setInfo( type="Video",infoLabels={ "Title": rootname } )
        else:
            liz.setInfo( type="Video", infoLabels=infoLabels)
        if SHOW_FANART:
            try:
                liz.setProperty( "fanart_image", infoLabels['fanart'] )
            except:
                liz.setProperty('fanart_image', fanart )
        else:liz.setProperty('fanart_image', fanart )
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return ok
		
def addDirPlayable(name,url,mode,iconimage,rootname,imdb,start,parms,videotype,infoLabels=None):
        u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+str(iconimage)+"&rootname="+str(rootname)+"&imdb="+str(imdb)+"&start="+str(start)+"&parms="+str(parms)+"&videotype="+urllib.quote_plus(videotype)
        ok=True
        contextMenuItems = []
        if videotype=='archive_audio':
            contextMenuItems.append(("[COLOR cyan]Queue Song[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=2002&iconimage=%s&rootname=%s&videotype=%s&parms=%s)'%(sys.argv[0], urllib.quote(name), urllib.quote(url), urllib.quote(iconimage),urllib.quote(rootname),urllib.quote(videotype),'queue')))
        else:
            contextMenuItems.append(("[COLOR cyan]Download[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=3002&iconimage=%s&rootname=%s&imdb=%s&videotype=%s)'%(sys.argv[0], urllib.quote(name), urllib.quote(url), urllib.quote(iconimage),urllib.quote(rootname),urllib.quote(imdb),urllib.quote(videotype))))
            contextMenuItems.append(("[COLOR cyan]Download & Play[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=3003&iconimage=%s&rootname=%s&imdb=%s&videotype=%s)'%(sys.argv[0], urllib.quote(name), urllib.quote(url), urllib.quote(iconimage),urllib.quote(rootname),urllib.quote(imdb),urllib.quote(videotype))))
            contextMenuItems.append(("[COLOR cyan]Download, Play, Delete[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=3005&iconimage=%s&rootname=%s&imdb=%s&videotype=%s)'%(sys.argv[0], urllib.quote(name), urllib.quote(url), urllib.quote(iconimage),urllib.quote(rootname),urllib.quote(imdb),urllib.quote(videotype))))
            contextMenuItems.append(("[COLOR cyan]Test download speed for this file[/COLOR]",'XBMC.RunPlugin(%s?name=%s&url=%s&mode=3004)'%(sys.argv[0], urllib.quote(name), urllib.quote(url))))
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video",infoLabels={ "Title": rootname } )#,infoLabels={ "Title": name }
        if SHOW_FANART:
            try:
                liz.setProperty( "fanart_image", infoLabels['fanart'] )
            except:
                liz.setProperty('fanart_image', fanart )
        else:liz.setProperty('fanart_image', fanart )
        liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
        return ok
		
def addDirPlayableResolve(name,url,mode,iconimage,rootname,imdb,start,parms,videotype,infoLabels=None):
        u=sys.argv[0]+"?url="+urllib.quote(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+str(iconimage)+"&rootname="+str(rootname)+"&imdb="+str(imdb)+"&start="+str(start)+"&parms="+str(parms)+"&videotype="+urllib.quote_plus(videotype)
        ok=True
        #contextMenuItems = []
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        liz.setInfo( type="Video",infoLabels={ "Title": rootname } )#,infoLabels={ "Title": name }
        if SHOW_FANART:
            try:
                liz.setProperty( "fanart_image", infoLabels['fanart'] )
            except:
                liz.setProperty('fanart_image', fanart )
        else:liz.setProperty('fanart_image', fanart )
        #liz.addContextMenuItems(contextMenuItems, replaceItems=False)
        ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz)
        return ok
        
params=get_params()

url=None
name=None
mode=None
iconimage=None
rootname=None
imdb=None
parms=None
videotype=None
start=None

print mode

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        mode=int(params["mode"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:
        start=urllib.unquote_plus(params["start"])
except:
        pass
try:
        rootname=urllib.unquote_plus(params["rootname"])
except:
        pass
try:
        imdb=urllib.unquote_plus(params["imdb"])
except:
        pass
try:
        videotype=urllib.unquote_plus(params["videotype"])
except:
        pass
try:
        parms=urllib.unquote_plus(params["parms"])
except:
        pass


if mode==None or url==None or len(url)<1:
        MENU(name)
        
elif mode == 100:
    movie_menu(name)

elif mode == 101:
    movie_results(name,url,start,rootname,imdb,start,parms,videotype)
	
elif mode == 102:
    movie_sort(name,url,start,rootname,imdb,start,parms,videotype)
	
elif mode == 104:
    movies_mpaas_menu()
	
elif mode == 105:
    movies_genres_menu()
	
elif mode == 106:
    movies_groups_menu()
	
elif mode == 107:
    movies_studios_menu()
	
elif mode == 108:
    scene_releases_menu()
	
elif mode == 109:
    scene_releases_list(url)
	
elif mode == 110:
    three_d_menu()
	
elif mode == 111:
    three_d_releases(url)
	
elif mode == 120:
    dvd_release_menu()
	
elif mode == 121:
    dvd_release_results(name,url,iconimage)
	
elif mode == 130:
    trakt_movies(name,url,start)
	
elif mode == 200:
    tv_menu(name)
	
elif mode == 204:
    tv_mpaas_menu()
	
elif mode == 205:
    tv_genres_menu()
	
elif mode == 206:
    tv_groups_menu()
	
elif mode == 210:
    tv_seasons(name,url,iconimage,rootname,imdb,videotype)
	
elif mode == 211:
    tv_episodes(name,url,iconimage,start,rootname,imdb,videotype)
	
elif mode == 230:
    trakt_shows(name,url,start)
	
elif mode == 300:
    music_menu(name)
	
elif mode == 302:
    chart_lists(name, url)
	
elif mode == 303:
    furksearchaudio(name,"all",iconimage,rootname)
	
elif mode == 304:
    search_artist(url)
	
elif mode == 305:
    discography(name,url,iconimage)
	
elif mode == 500:
    furk_menu(name)
	
elif mode == 501:
    myfiles(url)
	
elif mode==551:
    myfiles_add(name, url)
	
elif mode==552:
    myfiles_remove(name, url)
	
elif mode==553:
    myfiles_clear(name, url)
	
elif mode==554:
    myfiles_protect(name, url)
	
elif mode==555:
    myfiles_unprotect(name, url)
	
elif mode==556:
    get_downloads(url)
	
elif mode == 502:
    search_imdb(name,url)
	
elif mode == 503:
    account_info(name)
	
elif mode == 600:
    mypeople_menu(name)
	
elif mode == 601:
    search_actors()
	
elif mode == 602:
    movies_actors(name, url,iconimage)
	
elif mode == 605:
    add_favourite(name, url, rootname, imdb,iconimage, FAV_PEOPLE, "Added to My People")
	
elif mode == 606:
    remove_from_favourites(name, url, rootname, imdb,iconimage, FAV_PEOPLE, "Removed from My People")
	
elif mode == 700:
    watchlists(name)
	
elif mode == 701:
    watchlist_menu(name,url,start,rootname,imdb,start,parms,videotype)
	
elif mode == 750:
    subscriptions()
	
elif mode == 800:
    favourites_menu(name)
	
elif mode == 801:
    favourites_movies(name)
	
elif mode == 802:
    favourites_tv(name)
	
elif mode == 803:
    favourites_artists(name)
	
elif mode == 804:
    favourites_albums(name)
	
elif mode == 810:
        add_favourite(name, url, rootname, imdb,iconimage, FAV_ARTISTS, "Added to Favourites")
		
elif mode == 811:
        add_favourite(name, url, rootname, imdb,iconimage, FAV_ALBUMS, "Added to Favourites")
	
elif mode == 900:
    maintenance_menu(name)
   
elif mode == 902:
   deletepackages()
elif mode == 901:
    deletecachefiles()
elif mode == 903:
    rebuild_subscriptions()
	
elif mode==1:
        MENU2(url)
		
elif mode==3:
        tv_show(name, url, iconimage)
		
elif mode==4:
        tv_show_episodes(name, rootname, iconimage, imdb)
		
elif mode==2000:
        play(name, url, iconimage, rootname,videotype,parms,start,imdb)
		
elif mode==2001:
        playaudio(name, url, iconimage, rootname,videotype,parms,True)
		
elif mode==2002:
        playaudio(name, url, iconimage, rootname,videotype,parms,False)
		
elif mode==6:
        search()
		
elif mode==7:
        grouped_shows(url)
		
elif mode == 1500:
        search_imdb(name,url)
		
elif mode == 8:
        a_to_z(url)
		
elif mode == 9:
        watched_list(url)
		
elif mode == 10:
        report_error(name, url, showname)
		
elif mode == 11:
        add_favourite(name, url, rootname, imdb,iconimage, FAV, "Added to Favourites")
		
elif mode == 132:
        add_favourite(name, url, rootname, imdb,iconimage, FAV_TV, "Added to Favourites")
		
elif mode == 12:
        favourites()
		
elif mode == 13:
        remove_from_favourites(name, url, rootname, imdb,iconimage, FAV, "Removed from Favourites")
		
elif mode == 133:
        remove_from_favourites(name, url, rootname, imdb,iconimage, FAV_TV, "Removed from Favourites")
		
elif mode == 14:
        create_tv_show_strm_files(name, url, rootname,imdb,iconimage, "true")
		
elif mode == 15:
        remove_tv_show_strm_files(name, url, rootname,imdb,iconimage, TV_PATH)
		
elif mode == 20:#name, url, rootname,imdb,iconimage
        create_strm_file(name, url, '1100', MOVIE_PATH, iconimage, rootname,imdb,'movies')
        if xbmc.getCondVisibility('Library.IsScanningVideo') == False:           
            xbmc.executebuiltin('UpdateLibrary(video)')
		
elif mode == 21:
        remove_movie_strm_files(name, url, rootname,imdb,iconimage, MOVIE_PATH)
		
elif mode == 18:
        get_subscriptions(name,url)
		
elif mode == 150:
        view_trailer(name, url, iconimage)
		
elif mode == 151:
        movie_similar(name, url, iconimage,imdb)
		
elif mode == 1000:
        video_search(name, url, iconimage,rootname,imdb,videotype,'addon')

elif mode == 1100:
        video_search(name, url, iconimage,rootname,imdb,videotype,'library')
		
elif mode == 1001:furk_tfiles(name, url, iconimage,rootname,imdb,videotype,'addon','play',start)

elif mode == 1009:add_download(name, url)

elif mode == 1003:furk_tfiles(name, url, iconimage,rootname,imdb,videotype,'addon','skip',start)

elif mode == 1002:furk_tfiles_audio(name, url, iconimage,rootname,imdb,videotype,True)

elif mode == 1004:furk_tfiles_audio(name, url, iconimage,rootname,imdb,videotype,False)

elif mode == 3001:download_archive(name, url, iconimage, rootname,imdb,'archive|' + videotype + '|1|download')

elif mode == 3002:download_archive(name, url, iconimage, rootname,imdb,videotype + '|download')

elif mode == 3003:download_archive(name, url, iconimage, rootname,imdb,videotype + '|play')

elif mode == 3005:download_archive(name, url, iconimage, rootname,imdb,videotype + '|delete')

elif mode == 3004:test_dl_speed(name, url)

elif mode == 5000:alternate_source(name,url,iconimage,rootname,imdb,videotype)
		
xbmcplugin.endOfDirectory(int(sys.argv[1])) 


