This XBMC plugin parses and displays information from the SpeedFan log. While this plugin works on any platform, SpeedFan only works on Windows, so it is optimally built for people using XBMC on Windows.

For more information and usage directions, please see:

<http://wiki.xbmc.org/index.php?title=Add-on:SpeedFan_Information_Display>