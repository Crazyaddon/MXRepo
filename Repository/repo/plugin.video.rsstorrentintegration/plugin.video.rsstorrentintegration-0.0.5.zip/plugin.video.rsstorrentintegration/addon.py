# coding: utf-8
# Main Addon
__author__ = 'mancuniancol'

from xbmcswift2 import Plugin
from xbmcswift2 import actions
from tools import *
import feedparser

storage = Storage(settings.storageName, type="dict")

plugin = Plugin()


###############################
###  MENU    ##################
###############################

@plugin.route('/')
def index():
    items = [
        {'label': plugin.get_string(32005),
         'path': plugin.url_for('add'),
         'thumbnail': settings.icon,
         'properties': {'fanart_image' : settings.fanart}
         }
    ]
    items.extend(read())
    return items


@plugin.route('/remove/<name>')
def remove(name):
    if settings.dialog.yesno(settings.cleanName, plugin.get_string(32006) % name):
        storage.remove(name)
        storage.save()


@plugin.route('/modify/<name>')
def modify(name):
    selection = settings.dialog.input(plugin.get_string(32007), storage.database[name][0])
    storage.database[name] = (selection, storage.database[name][1])
    storage.save()


@plugin.route('/add')
def add():
    selection = settings.dialog.input(plugin.get_string(32007))
    name = ''
    while name is '':
        name = settings.dialog.input(plugin.get_string(32008)).title()
    storage.database[name] = (selection, False)
    storage.save()


# read the information from rss url
@plugin.route('/readRss/<url>/')
def readRss(url):
    items = []
    titlesMovie, magnetsMovie, titlesShow, magnetsShow, titlesAnime, magnetsAnime = _readRss(url)
    movies = plugin.get_storage('movies')
    shows = plugin.get_storage('shows')
    animes = plugin.get_storage('animes')
    movies.clear()
    shows.clear()
    animes.clear()

    if len(titlesMovie) > 0:
        movies.update({
            'titles': titlesMovie,
            'magnets': magnetsMovie
        })
        items.append(
            {'label': plugin.get_string(32022),
             'path': plugin.url_for('readList', type="Movie"),
             'properties': {'fanart_image' : settings.fanart}
             }

        )
    if len(titlesShow) > 0:
        shows.update({
            'titles': titlesShow,
            'magnets': magnetsShow
        })
        items.append(
            {'label': plugin.get_string(32023),
             'path': plugin.url_for('readList', type="Show"),
             'properties': {'fanart_image' : settings.fanart}
             }

        )
    if len(titlesAnime) > 0:
        animes.update({
            'titles': titlesAnime,
            'magnets': magnetsAnime,
            'type': "Anime"
        })
        items.append(
            {'label': plugin.get_string(32024),
             'path': plugin.url_for('readList', type="Anime"),
             'properties': {'fanart_image' : settings.fanart}
             }
        )
    return items


@plugin.route('/readList/<type>')
def readList(type):
    movies = plugin.get_storage('movies')
    shows = plugin.get_storage('shows')
    animes = plugin.get_storage('animes')
    info = {}
    info['titles'] = ""
    info['magnets'] = ""
    if type == "Movie":
        plugin.set_content("movies")
        info = movies
    elif type == "Show":
        plugin.set_content("tvshows")
        info = shows
    elif type == "Anime":
        plugin.set_content("tvshows")
        info = animes
    items = []
    for (title, magnet) in zip(info['titles'], info['magnets']):
        title = safeName(title)
        items.append({'label': title,
                      'path': plugin.url_for('play', magnet=magnet),
                      'properties': {'fanart_image' : settings.fanart},
                      'context_menu': [
                          (plugin.get_string(32009),
                           'XBMC.RunPlugin(%s)' % plugin.url_for('importOne', title=title, magnet=magnet))
                      ]
                      })
    return items


@plugin.route('/play/<magnet>')
def play(magnet):
    # Set-up the plugin
    uri_string = quote_plus(uncodeName(magnet))
    if settings.value["plugin"] == 'Pulsar':
        link = 'plugin://plugin.video.pulsar/play?uri=%s' % uri_string
    elif settings.value["plugin"] == 'KmediaTorrent':
        link = 'plugin://plugin.video.kmediatorrent/play/%s' % uri_string
    elif settings.value["plugin"] == "Torrenter":
        link = 'plugin://plugin.video.torrenter/?action=playSTRM&url=' + uri_string + \
               '&not_download_only=True'
    elif settings.value["plugin"] == "YATP":
        link = 'plugin://plugin.video.yatp/?action=play&torrent=' + uri_string
    else:
        link = 'plugin://plugin.video.xbmctorrent/play/%s' % uri_string
    # play media
    xbmc.executebuiltin("PlayMedia(%s)" % link)


@plugin.route('/importAll/<name>')
def importAll(name):
    url = storage.database[name][0]
    storage.database[name] = (url, True)
    storage.save()
    titlesMovie, magnetsMovie, titlesShow, magnetsShow, titlesAnime, magnetsAnime = _readRss(url)
    if len(titlesMovie) > 0:
        integration(filenames=titlesMovie, magnets=magnetsMovie, typeList='MOVIE',
                    folder=settings.movieFolder, silence=True)
    if len(titlesShow) > 0:
        integration(filenames=titlesShow, magnets=magnetsShow, typeList='SHOW',
                    folder=settings.showFolder, silence=True)
    if len(titlesAnime) > 0:
        integration(filenames=titlesAnime, magnets=magnetsAnime, typeList='ANIME',
                    folder=settings.animeFolder, silence=True)


@plugin.route('/importOne/<title>/<magnet>')
def importOne(title, magnet):
    info = format_title(title)
    if 'MOVIE' in info['type']:
        integration(filenames=[title], magnets=[magnet], typeList='MOVIE',
                    folder=settings.movieFolder, silence=True)
    if 'SHOW' in info['type']:
        integration(filenames=[title], magnets=[magnet], typeList='SHOW',
                    folder=settings.showFolder, silence=True)
    if 'ANIME' in info['type']:
        integration(filenames=[title], magnets=[magnet], typeList='ANIME',
                    folder=settings.animeFolder, silence=True)


@plugin.route('/unsubscribe/<name>')
def unsubscribe(name):
    storage.database[name] = (storage.database[name][0], False)
    storage.save()


###############################
###  FONCTIONS    #############
###############################
# read the url list
def read():
    # list of rss available
    items = []
    for (name, (RSS, isIntegrated)) in zip(storage.database.keys(), storage.database.values()):
        if isIntegrated:
            importInfo = (plugin.get_string(32001),
                          'XBMC.Container.Update(%s)' % plugin.url_for('unsubscribe', name=name))
        else:
            importInfo = (plugin.get_string(32002),
                          'XBMC.Container.Update(%s)' % plugin.url_for('importAll', name=name))
        items.append({'label': name + ": " + RSS,
                      'path': plugin.url_for('readRss', url=RSS),
                      'properties': {'fanart_image' : settings.fanart},
                      'context_menu': [
                          (plugin.get_string(32003), 'XBMC.Container.Update(%s)' % plugin.url_for('remove', name=name)),
                          (plugin.get_string(32004), 'XBMC.Container.Update(%s)' % plugin.url_for('modify', name=name)),
                          importInfo
                      ]
                      })
    return items


def _readRss(url):
    magnetsMovie = []
    titlesMovie = []
    magnetsShow = []
    titlesShow = []
    magnetsAnime = []
    titlesAnime = []
    if url is not '':
        settings.log(url)
        response = feedparser.parse(url)
        for entry in response.entries:
            isMagnet = False
            for key in entry.keys():
                if "magnet" in key:
                    isMagnet = True
                    tag = key
                    break
            if isMagnet:
                value = entry[tag]
            else:
                for link in entry.links:
                    value = link.href  # Taking the last link
            info = format_title(entry.title)
            if 'MOVIE' in info['type']:
                titlesMovie.append(entry.title)
                magnetsMovie.append(value)
            if 'SHOW' in info['type']:
                titlesShow.append(entry.title)
                magnetsShow.append(value)
            if 'ANIME' in info['type']:
                titlesAnime.append(entry.title)
                magnetsAnime.append(value)
    return titlesMovie, magnetsMovie, titlesShow, magnetsShow, titlesAnime, magnetsAnime


if __name__ == '__main__':
    plugin.run()
