# coding: utf-8

import requests
import base64
import json

browser = requests.session()
headers = {'Content-Type': 'application/json',
           'X-Pagination-Page': '2',
           'X-Pagination-Limit': '10',
           'X-Pagination-Page-Count': '100',
           'X-Pagination-Item-Count': '100',
           'trakt-api-version': '2',
           'trakt-api-key': base64.urlsafe_b64decode(
                   'd4161a7a106424551add171e5470112e4afdaf2438e6ef2fe0548edc75924868')}

# response = browser.get('https://api-v2launch.trakt.tv/movies/trending', headers=headers)
response = browser.get('https://api-v2launch.trakt.tv/movies/popular', headers=headers)
data = response.json()

print data

# from urllib2 import Request, urlopen
# request = Request('https://api-v2launch.trakt.tv/movies/trending', headers=headers)
# response_body = urlopen(request).read()
#
# print response_body
