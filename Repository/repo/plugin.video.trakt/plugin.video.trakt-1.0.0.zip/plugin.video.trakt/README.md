Introduction
===================
This is addon is a viewer for TRAKT site and it allows to play its torrents from RARBG directly with the help of Pulsar, KmediaTorrent, XBMCTorrent, Torrenter V2 and YATP.

It also integrates the feed in the local library allowing to use all the tools from local library as trailer, cinema experience, etc.

It is possible to write the list manually or create them from internet.

Requeriments
===================
This addon needs to have installed the module:
script.module.mctools
https://github.com/mancuniancol/script.module.mctools/releases