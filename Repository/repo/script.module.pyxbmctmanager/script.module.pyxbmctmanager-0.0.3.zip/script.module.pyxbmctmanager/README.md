script.module.pyxbmct.manager
======================

