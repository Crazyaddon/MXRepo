======================
Viooz
======================

About
-----
Watch a wide selection of movies from viooz.co


Attributions
---------------------
- Decrypter by shani_08 | http://tvaddons.ag
- Main icon and fanart by jokster | http://tvaddons.ag
- Dutch translation by falos | http://tvaddons.ag
- French translation by nek | http://tvaddons.ag
- Polish translation by kodishu | http://tvaddons.ag
- Portuguese translation by enen92 | http://tvaddons.ag
- Romanian translation by timmygotcha | http://tvaddons.ag
- Main icon set is based on work done by DryIcons | http://dryicons.com
- Additional icons are based on work done by David Lanham | http://www.dlanham.com


License
-------
This software is released under the [GPL 3.0 license] [1].
[1]: http://www.gnu.org/licenses/gpl-3.0.html