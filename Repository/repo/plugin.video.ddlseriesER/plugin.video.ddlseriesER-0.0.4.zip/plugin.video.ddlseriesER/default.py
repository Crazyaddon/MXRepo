import xbmc, xbmcgui, xbmcaddon, xbmcplugin
import re, string, sys, os
import urlresolver
import HTMLParser
from TheYid.common.addon import Addon
from TheYid.common.net import Net

addon_id = 'plugin.video.ddlseriesER'
plugin = xbmcaddon.Addon(id=addon_id)
DB = os.path.join(xbmc.translatePath("special://database"), 'ddlseriesER.db')
net = Net()
addon = Addon('plugin.video.ddlseriesER', sys.argv)
BASE_URL = 'http://www.ddlseries.net/'
AddonPath = addon.get_path()
IconPath = AddonPath + "/icons/"
FanartPath = AddonPath + "/icons/"
mode = addon.queries['mode']
url = addon.queries.get('url', None)
content = addon.queries.get('content', None)
query = addon.queries.get('query', None)
startPage = addon.queries.get('startPage', None)
numOfPages = addon.queries.get('numOfPages', None)
listitem = addon.queries.get('listitem', None)
urlList = addon.queries.get('urlList', None)
section = addon.queries.get('section', None)
img = addon.queries.get('img', None)
text = addon.queries.get('text', None)

#----------------------------------------------------------------------------movies-----------------------------------------------------------------------------------------#

def GetTitles4(section, url): 
        pageUrl = url
        html = net.http_GET(url).content
        listitem = GetMediaInfo(html)
        content = html                    
        match = re.compile('<h2><a href="(.+?)">(.+?)<span style=".+?">.+?</span></a></h2></center>.+? <h1 class="rtype">(.+?)</h1><br>\s*?<img src="(.+?)"', re.DOTALL).findall(html)
        match1 = re.compile('<a href="(.+?)"><i class="fa fa-angle-right"></i></a>').findall(content) 
        for movieUrl, name, name1, img in match:
                addon.add_directory({'mode': 'GetLinks1', 'section': section, 'url': movieUrl, 'img': img , 'text': name}, {'title':  name.strip() + ' '  + name1}, img= img, fanart=FanartPath + 'fanart.jpg')     
        for url in match1:
                addon.add_directory({'mode': 'GetTitles4', 'url': url, 'listitem': listitem}, {'title': '[COLOR blue][B][I]Next page...[/B][/I][/COLOR]'}, img=IconPath + 'nextpage.png', fanart=FanartPath + 'fanart.jpg')      
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def GetLinks1(section, url, img, text):
        html = net.http_GET(url).content
        listitem = GetMediaInfo(html)
        content = html
        match = re.compile('<a href="(.+?)"  target="_blank">(.+?)<').findall(content)
        match1 = re.compile('<b>Release Name :</b>(.+?)<br>').findall(content)
        listitem = GetMediaInfo(content)
        for name in match1:
                addon.add_directory({'url': url, 'listitem': listitem, 'img': img }, {'title': '[COLOR powderblue][B]' + name.strip() + '[/COLOR][/B]'}, img=img, fanart=FanartPath + 'fanart.jpg') 
        for url, name in match:
                host = GetDomain(url)
                if urlresolver.HostedMediaFile(url= url):
                        title = url.rpartition('/')
                        title = title[2].replace('.html', '')
                        title = title.replace('.htm', '')
                        host = host.replace('embed.','')
                        addon.add_directory({'mode': 'PlayVideo', 'url': url, 'listitem': listitem}, {'title': text + ' ' + name + ' : ' + host}, img= img, fanart=FanartPath + 'fanart.jpg') 
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

#----------------------------------------------------------------------------tv-----------------------------------------------------------------------------------------#

def GetTitles(section, url): 
        pageUrl = url
        html = net.http_GET(url).content
        listitem = GetMediaInfo(html)
        content = html                    
        match = re.compile('<div class="col xs12 s6 m3 l2 animated bounceInUp">\s*?<a href="(.+?)" title="Watch .+?">\s*?<div class="card">\s*?<img class="hide-on-med-and-down" alt=".+?" src=".+?src=(.+?)&amp.+?" width="100%">\s*?<img class="hide-on-large-only" alt=".+?" src=".+?" width="100%">\s*?<p class="smalltitle">\s*?(.+?)\s*?</p>\s*?<p class="tinytitle">\s*?(.+?)\s*?</p>', re.DOTALL).findall(html)
        match1 = re.compile('''<li class='current'><a href=".+?">.+?</a></li> <li><a href="(.+?)">.+?</a></li>''').findall(content) 
        for movieUrl, img, name, name1 in match:
                addon.add_directory({'mode': 'GetTitles1', 'section': section, 'url': movieUrl, 'img': img }, {'title':  name.strip() + '  ' + name1}, img= img, fanart=FanartPath + 'fanart.jpg')     
        for url in match1:
                addon.add_directory({'mode': 'GetTitles', 'url': url, 'listitem': listitem}, {'title': 'next page'}, img='http://www.megatoner.si/media/mw_promobox/icon/open-left.png', fanart=FanartPath + 'fanart.jpg')      
        setView('tvshows', 'tvshows-view')
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def GetTitles1(url, img):
        html = net.http_GET(url).content
        listitem = GetMediaInfo(html)
        content = html
        match = re.compile("<li><a href='http://streamthis.tv/show/(.+?)'>(.+?)</a></li>").findall(content) 
        for url, name in match:
                addon.add_directory({'mode': 'GetTitles2', 'url': 'http://streamthis.tv/show/' + url, 'listitem': listitem, 'img': img }, {'title':  name.strip()}, img=img, fanart=FanartPath + 'fanart.jpg') 
        setView('tvshows', 'tvshows-view')
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def GetTitles2(url, img):
        html = net.http_GET(url).content
        listitem = GetMediaInfo(html)
        content = html
        match = re.compile('<a class="collection-item black-text" href="(.+?)">(.+?)</a>').findall(content) 
        match1 = re.compile('twitter:description" content="(.+?)"').findall(content) 
        match2 = re.compile('<div class="col-xs-12 streamystats">\s*?<ul>\s*?<li class="stat">\s*?(IMDB rating:)\s*?<span>\s*?(.+?)\s*?</span>\s*?</li>').findall(content) 
        for name in match1:
                addon.add_directory({'url': url, 'listitem': listitem, 'img': img }, {'title': '[COLOR powderblue][B]' + name.strip() + '[/COLOR][/B]'}, img=img, fanart=FanartPath + 'fanart.jpg') 
        for name, name2 in match2:
                addon.add_directory({'url': url, 'listitem': listitem, 'img': img }, {'title': '[COLOR pink][B]' + name.strip() + ' ' + name2 + '[/COLOR][/B]'}, img=img, fanart=FanartPath + 'fanart.jpg') 
        for url, name in match:
                addon.add_directory({'mode': 'GetLinks', 'url': url, 'listitem': listitem, 'img': img }, {'title':  name.strip().replace('<b>',' - ').replace('</b>','')}, img=img, fanart=FanartPath + 'fanart.jpg') 
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def GetLinks(section, url, img, text):
        html = net.http_GET(url).content
        listitem = GetMediaInfo(html)
        content = html
        match = re.compile('<a class="collection-item black-text" href="(.+?)"').findall(content)
        match1 = re.compile('<meta name=description content="(.+?)"/>').findall(content)
        listitem = GetMediaInfo(content)
        for name in match1:
                addon.add_directory({'url': url, 'listitem': listitem, 'img': img }, {'title': '[COLOR powderblue][B]' + name.strip() + '[/COLOR][/B]'}, img=img, fanart=FanartPath + 'fanart.jpg') 
        for url in match:
                host = GetDomain(url)
                if urlresolver.HostedMediaFile(url= url):
                        title = url.rpartition('/')
                        title = title[2].replace('.html', '')
                        title = title.replace('.htm', '')
                        host = host.replace('embed.','')
                        addon.add_directory({'mode': 'PlayVideo', 'url': url, 'listitem': listitem}, {'title': host + ' : ' + title }, img= img, fanart=FanartPath + 'fanart.jpg') 
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def PlayVideo(url, listitem):
    try:
        print 'in PlayVideo %s' % url
        stream_url = urlresolver.HostedMediaFile(url).resolve()
        xbmc.Player().play(stream_url)
        addon.add_directory({'mode': 'help'}, {'title':  '[COLOR slategray][B]^ Press back ^[/B] [/COLOR]'},'','')
    except:
        xbmc.executebuiltin("XBMC.Notification([COLOR red][B]Sorry Link may have been removed ![/B][/COLOR],[COLOR lime][B]Please try a different link/host !![/B][/COLOR],7000,"")")

def GetDomain(url):
        tmp = re.compile('//(.+?)/').findall(url)
        domain = 'Unknown'
        if len(tmp) > 0 :
            domain = tmp[0].replace('www.', '')
        return domain

def GetMediaInfo(html):
        listitem = xbmcgui.ListItem()
        match = re.search('og:title" content="(.+?) \((.+?)\)', html)
        if match:
                print match.group(1) + ' : '  + match.group(2)
                listitem.setInfo('video', {'Title': match.group(1), 'Year': int(match.group(2)) } )
        return listitem

def MainMenu():  
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/hd/hd-720p/'}, {'title':  '[B]Episodes & Seasons : [COLOR blue]720p HD[/COLOR][/B]'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg')
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/hd/hd-1080p/'}, {'title':  '[B]Episodes & Seasons : [COLOR blue]1080p HD[/COLOR][/B]'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg')
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/sd/sd-xvid/'}, {'title':  '[B]Episodes & Seasons : [COLOR blue]xvid SD[/COLOR][/B]'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg')
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/sd/sd-x264/'}, {'title':  '[B]Episodes & Seasons : [COLOR blue]x264 SD[/COLOR][/B]'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg')
        addon.add_directory({'mode': 'GenreMenu1'}, {'title':  '[B]Full Seasons : [COLOR blue]Genre[/COLOR][/B]'}, img=IconPath + 'gen.png', fanart=FanartPath + 'fanart.jpg') 

        addon.add_directory({'mode': 'GetSearchQuery'},  {'title':  '[COLOR green]Search[/COLOR]'}, img=IconPath + 'search.png', fanart=FanartPath + 'fanart.jpg') 

        addon.add_directory({'mode': 'ResolverSettings'}, {'title':  '[COLOR red]Resolver Settings[/COLOR]'}, img=IconPath + 'url1.png', fanart=FanartPath + 'fanart.jpg') 
        addon.add_directory({'mode': 'home'}, {'title':  '[B][COLOR yellow] www.entertainmentrepo.com  [/B][/COLOR]'}, img=IconPath + 'newart.jpg', fanart=IconPath +  'newart.jpg')
        xbmcplugin.endOfDirectory(int(sys.argv[1]))


def GenreMenu1(): 
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/genre/action/'}, {'title':  '[COLOR lightskyblue]action [/COLOR] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg') 
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/genre/adventure/'}, {'title':  '[COLOR lightskyblue]adventure [/COLOR] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg') 
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/genre/animation/'}, {'title':  '[COLOR lightskyblue]animation [/COLOR] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg') 
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/genre/biography/'}, {'title':  '[COLOR lightskyblue]biography [/COLOR] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg') 
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/genre/comedy/'}, {'title':  '[COLOR lightskyblue]comedy [/COLOR] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg') 
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/genre/crime/'}, {'title':  '[COLOR lightskyblue]crime [/COLOR] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg') 
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/genre/documentary/'}, {'title':  '[COLOR lightskyblue]documentary [/COLOR] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg')
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/genre/drama/'}, {'title':  '[COLOR lightskyblue]drama [/COLOR] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg')
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/genre/family/'}, {'title':  '[COLOR lightskyblue]family [/COLOR] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg') 
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/genre/fantasy/'}, {'title':  '[COLOR lightskyblue]fantasy [/COLOR] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg') 
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/genre/history/'}, {'title':  '[COLOR lightskyblue]history [/COLOR] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg') 
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/genre/horror/'}, {'title':  '[COLOR lightskyblue]horror [/COLOR] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg')
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/genre/musical/'}, {'title':  '[COLOR lightskyblue]musical [/COLOR] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg') 
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/genre/mystery/'}, {'title':  '[COLOR lightskyblue]mystery [/COLOR] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg')   
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/genre/romance/'}, {'title':  '[COLOR lightskyblue]romance [/COLOR] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg') 
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/genre/sci-fi/'}, {'title':  '[COLOR lightskyblue]sci-fi [/COLOR] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg') 
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/genre/short/'}, {'title':  '[COLOR lightskyblue]short [/COLOR] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg') 
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/genre/sport/'}, {'title':  '[COLOR lightskyblue]sport [/COLOR] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg')  
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/genre/thriller/'}, {'title':  '[COLOR lightskyblue]thriller [/COLOR] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg')
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/genre/war/'}, {'title':  '[COLOR lightskyblue]war [/COLOR] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg') 
        addon.add_directory({'mode': 'GetTitles4', 'section': 'ALL', 'url': BASE_URL + '/genre/western/'}, {'title':  '[COLOR lightskyblue]western [/COLOR] >>'}, img=IconPath + 'tv.png', fanart=FanartPath + 'fanart.jpg') 
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

def GetSearchQuery():
	last_search = addon.load_data('search')
	if not last_search: last_search = ''
	keyboard = xbmc.Keyboard()
        keyboard.setHeading('Search')
	keyboard.setDefault(last_search)
	keyboard.doModal()
	if (keyboard.isConfirmed()):
                query = keyboard.getText()
                addon.save_data('search',query)
                Search(query)
	else:
                return

def Search(query):
        url = 'http://www.ddlseries.net/index.php?story=' + query + '&do=search&subaction=search'
        url = url.replace(' ', '+')
        print url
        html = net.http_GET(url).content
        match = re.compile('<h2><a href="(.+?)">(.+?)</a></h2></center>\s*?<a href=".+?" class="btn btn-black comlink" title=".+?"><i class=".+?"></i>.+?</a>\s*?</div>\s*?</div>\s*?<div class="box-content">\s*?<div class="box-section" style=".+?">\s*?<center> <h1 class="rtype">(.+?)</h1><br>\s*?<img src="(.+?)"', re.DOTALL).findall(html)
        for movieUrl, name, name1, img in match:
                addon.add_directory({'mode': 'GetLinks1', 'section': section, 'url': movieUrl, 'img': img , 'text': name}, {'title':  name.strip() + ' ' + name1}, img= img, fanart=FanartPath + 'fanart.jpg') 
	xbmcplugin.endOfDirectory(int(sys.argv[1]))


def setView(content, viewType):
	if content:
		xbmcplugin.setContent(int(sys.argv[1]), content)
	if addon.get_setting('auto-view') == 'true':
		xbmc.executebuiltin("Container.SetViewMode(%s)" % addon.get_setting(viewType) )
	xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_UNSORTED )
	xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_LABEL )
	xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RATING )
	xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_DATE )
	xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_PROGRAM_COUNT )
	xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_VIDEO_RUNTIME )
	xbmcplugin.addSortMethod( handle=int( sys.argv[ 1 ] ), sortMethod=xbmcplugin.SORT_METHOD_GENRE )

if mode == 'main': 
	MainMenu()
elif mode == 'GenreMenu':
        GenreMenu()
elif mode == 'GenreMenu1':
        GenreMenu1()
elif mode == 'GetTitles': 
	GetTitles(section, url)
elif mode == 'GetTitles1': 
	GetTitles1(url, img)
elif mode == 'GetTitles2': 
	GetTitles2(url, img)
elif mode == 'GetTitles4': 
	GetTitles4(section, url)
elif mode == 'GetLinks':
	GetLinks(section, url, img, text)
elif mode == 'GetLinks1':
	GetLinks1(section, url, img, text)
elif mode == 'GetSearchQuery':
	GetSearchQuery()
elif mode == 'Search':
	Search(query)
elif mode == 'PlayVideo':
	PlayVideo(url, listitem)	
elif mode == 'ResolverSettings':
        urlresolver.display_settings()
xbmcplugin.endOfDirectory(int(sys.argv[1]))