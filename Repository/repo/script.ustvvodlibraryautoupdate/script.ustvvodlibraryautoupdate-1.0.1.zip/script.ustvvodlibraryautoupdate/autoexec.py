import xbmc

#use this if you are running Weather+ to avoid a startup conflict
#xbmc.executebuiltin('AlarmClock(ustvvodupdatelibrary,XBMC.RunScript(script.ustvvodlibraryautoupdate),1,true)')

#otherwise this one should be fine
xbmc.executebuiltin('RunScript(script.ustvvodlibraryautoupdate)')
