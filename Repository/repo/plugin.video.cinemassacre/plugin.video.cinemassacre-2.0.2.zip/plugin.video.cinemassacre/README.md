plugin.video.cinemassacre
=========================

Kodi/XBMC plugin for cinemassacre.com videos