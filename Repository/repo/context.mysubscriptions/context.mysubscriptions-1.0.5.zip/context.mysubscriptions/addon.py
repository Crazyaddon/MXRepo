# -*- coding: utf-8 -*-		
		
import xbmc,xbmcgui,xbmcaddon,re,urllib,urllib2,os
import requests
import json
import xbmcvfs
import settings

def create_directory(dir_path, dir_name=None):
    if dir_name:
        dir_path = os.path.join(dir_path, dir_name)
    dir_path = dir_path.strip()
    if not os.path.exists(dir_path):
        os.makedirs(dir_path)
    return dir_path

def create_file(dir_path, file_name=None):
    if file_name:
        file_path = os.path.join(dir_path, file_name)
    file_path = file_path.strip()
    if not os.path.exists(file_path):
        f = open(file_path, 'w')
        f.write('')
        f.close()
    return file_path

ADDON = xbmcaddon.Addon(id='context.mysubscriptions')	
DATA_PATH = create_directory(os.path.join(xbmc.translatePath('special://profile/addon_data'), ''),'context.mysubscriptions')
TRAKT_ID_PATH = create_file(DATA_PATH, "trakt_ids.list")
ONECH_URL_PATH = create_file(DATA_PATH, "1channel_urls.list")
TV4ME_URL_PATH = create_file(DATA_PATH, "tv4me_urls.list")
YIFY_URL_PATH = create_file(DATA_PATH, "yify_urls.list")
OMP_URL_PATH = create_file(DATA_PATH, "omp_urls.list")
RESTRICT_MOVIE=ADDON.getSetting('restrict_mv_addon')
RESTRICT_MOVIE_SELECT=settings.select_mv_addon()
RESTRICT_TV=ADDON.getSetting('restrict_tv_addon')
RESTRICT_TV_SELECT=settings.select_tv_addon()
xbmcPlayer = xbmc.Player(xbmc.PLAYER_CORE_AUTO)
dialog = xbmcgui.Dialog()

tmdbapi = '1b0d3c6ac6a6c0fa87b55a1069d6c9c8'
traktapi='f801f9d16b1d8d1ffbeaa306ceaed040ac1303883a0b9be27ac0838058e91eed'

def get_trakt(query,db_type):
    traktid="na"
    if os.path.isfile(TRAKT_ID_PATH):
        s = read_from_file(TRAKT_ID_PATH)
        search_list = s.split('\n')
        for list in search_list:
            if list != '':
                list1 = list.split('<>')
                name = list1[0]
                type = list1[1]
                trakt = list1[2]
                if name==query and type==db_type:
                    traktid=trakt
    if traktid=="na": 
        header_dict = {}
        header_dict['Content-Type'] = 'application/json'
        header_dict['trakt-api-key'] = traktapi
        header_dict['trakt-api-version'] = '2'
        if query.startswith('tt'):
            url = 'http://api-v2launch.trakt.tv/search?id_type=imdb&id=%s' % (query)
        else:
            if db_type=='episode':
                url = 'http://api-v2launch.trakt.tv/search?query=%s&type=show' % (query)
            else:
                url = 'http://api-v2launch.trakt.tv/search?query=%s&type=movie' % (query)
        req=requests.get(url,headers=header_dict).content
        data=json.loads(req)
        traktid=[]
        for i in data:
            try:
                traktids = i['show']['ids']['trakt']
                traktname = i['show']['title']
            except:
                traktids = i['movie']['ids']['trakt']
            traktid.append(traktids)
        text="%s<>%s<>%s" % (query,db_type,str(traktid[0]))
        add_to_list(text,TRAKT_ID_PATH)
        traktid=str(traktid[0])
    return traktid
	
def get_tmdb(imdb):
    header_dict = {}
    header_dict['Accept'] = 'application/json'
    #header_dict['Content-Type'] = 'application/json'
    url = 'http://api.themoviedb.org/3/movie/' + imdb + '?api_key=' + tmdbapi
    req=requests.get(url,headers=header_dict).content
    try:
        tmdbid=regex_from_to(req,'"id":',',"name')
    except:
        tmdbid=""
    return tmdbid
	
def get_1channel_url(title):
    urlreturn="na"
    if os.path.isfile(ONECH_URL_PATH):
        s = read_from_file(ONECH_URL_PATH)
        search_list = s.split('\n')
        for list in search_list:
            if list != '':
                list1 = list.split('<>')
                name = list1[0]
                url = list1[1]
                if name==title:
                    urlreturn=url
    if urlreturn=="na":
        url='http://www.primewire.ag/'
        link = requests.get(url).content
        key=regex_from_to(link,'"hidden" name="key" value="', '"')
        url='http://www.primewire.ag/index.php?search_keywords=%s&key=%s&search_section=1' % (title,key)
        link = requests.get(url).content
        urlreturn=regex_from_to(link,'index_item index_item_ie"><a href="','"').replace('-online-free','').replace('watch-','tv-')
        text="%s<>%s" % (title,urlreturn)
        add_to_list(text,ONECH_URL_PATH)
    return urlreturn
	
def get_tv4me_url(query,season,episode):
    urlreturn="na"
    if os.path.isfile(TV4ME_URL_PATH):
        s = read_from_file(TV4ME_URL_PATH)
        search_list = s.split('\n')
        for list in search_list:
            if list != '':
                list1 = list.split('<>')
                name = list1[0]
                url = list1[1]
                if name==query:
                    showurl=url
    if urlreturn=="na":
        url='http://www.watch-tvseries.net/play/menulist'
        link = requests.get(url).content
        match = re.compile("<li><a href='(.+?)'>(.+?)</a></li>").findall(link)
        for url, title in match:
            if query.lower() in title.lower():
                if not 'http://www.watch-tvseries.net' in url:
                    showurl='http://www.watch-tvseries.net' + url
                    text="%s<>%s" % (query,showurl)
                    add_to_list(text,TV4ME_URL_PATH)
    link = requests.get(showurl).content
    episodes = re.compile('<a title="(.+?)" href="(.+?)"> <div class="(.+?)data-original="(.+?)"(.+?)nseasnumep"> (.+?) <br(.+?)>(.+?) </div> </div> </a>').findall(link)
    for epname, url, a, thumb, b, snum, c, epnum in episodes:
        epnum = int(epnum.replace('episode ', ''))
        snum = int(snum.replace('season ', ''))
        if str(snum)==str(season) and str(epnum)==str(episode):
            urlreturn = 'http://www.watch-tvseries.net' + url
    return urlreturn
	
def get_yify_url(title,year):
    urlreturn="na"
    if os.path.isfile(YIFY_URL_PATH):
        s = read_from_file(YIFY_URL_PATH)
        search_list = s.split('\n')
        for list in search_list:
            if list != '':
                list1 = list.split('<>')
                name = list1[0]
                yr = list1[1]
                url = list1[2]
                if name==title and yr==year:
                    urlreturn=url
    if urlreturn=="na":
        url='http://yify.tv/?s=%s' % title
        link = requests.get(url).content
        data=regex_from_to(link,'<h1>Watch Movies Online</h1>','<div class')
        match=re.compile('<a href="(.+?)">Watch (.+?) Online</a>').findall(data)
        for u,qt in match:
            t=qt[:-5]
            y=qt[-4:]
            if t.lower()==title.lower() and y==year:
                urlreturn=u
                text="%s<>%s<>%s" % (title,year,urlreturn)
                add_to_list(text,YIFY_URL_PATH)
    return urlreturn
	
def get_omp_url(title,year):
    import urlresolver
    urlreturn="na"
    if os.path.isfile(OMP_URL_PATH):
        s = read_from_file(OMP_URL_PATH)
        search_list = s.split('\n')
        for list in search_list:
            if list != '':
                list1 = list.split('<>')
                name = list1[0]
                yr = list1[1]
                url = list1[2]
                if name==title and yr==year:
                    urlresolve=url
                    link = requests.get(urlresolve).content.replace("'",'"')
                    data=regex_from_to(link,'<div class="video-embed">','</div>')
                    url=regex_from_to(data,'src="','" allowFullScreen></iframe>')
                    urlreturn=urlresolver.resolve(url)
    if urlreturn=="na":
        url='http://onlinemovies.pro/?s=%s' % title
        link = requests.get(url).content
        data=regex_from_to(link,'<ul class="listing-videos listing-tube">','</ul>')
        match=re.compile('<a href="(.+?)" title="(.+?)"><span>(.+?)</span></a>').findall(data)
        for u,qt,qt1 in match:
            if ' (' in qt:
                t=qt.split(' (')[0]
                y=qt.split(' (')[1].replace(')','')
            else:
                t=qt
                y='na'
                year='na'
            if title.lower() in t.lower() and y==year:
                urlresolve=u
                text="%s<>%s<>%s" % (title,year,urlresolve)
                link = requests.get(urlresolve).content.replace("'",'"')
                data=regex_from_to(link,'<div class="video-embed">','</div>')
                url=regex_from_to(data,'src="','" allowFullScreen></iframe>')
                urlreturn=urlresolver.resolve(url) 
                add_to_list(text,OMP_URL_PATH)
    return urlreturn

def regex_from_to(text, from_string, to_string, excluding=True):
    if excluding:
        r = re.search("(?i)" + from_string + "([\S\s]+?)" + to_string, text).group(1)
    else:
        r = re.search("(?i)(" + from_string + "[\S\s]+?" + to_string + ")", text).group(1)
    return r

def regex_get_all(text, start_with, end_with):
    r = re.findall("(?i)(" + start_with + "[\S\s]+?" + end_with + ")", text)
    return r
		
def find_list(query, search_file):
    try:
        content = read_from_file(search_file) 
        lines = content.split('\n')
        index = lines.index(query)
        return index
    except:
        return -1
		
def add_to_list(list, file):
    if find_list(list, file) >= 0:
        return

    if os.path.isfile(file):
        content = read_from_file(file)
    else:
        content = ""

    lines = content.split('\n')
    s = '%s\n' % list
    for line in lines:
        if len(line) > 0:
            s = s + line + '\n'
    write_to_file(file, s)
	
def write_to_file(path, content, append=False, silent=False):
    try:
        if append:
            f = open(path, 'a')
        else:
            f = open(path, 'w')
        f.write(content)
        f.close()
        return True
    except:
        if not silent:
            print("Could not write to " + path)
        return False

def read_from_file(path, silent=False):
    try:
        f = open(path, 'r')
        r = f.read()
        f.close()
        return str(r)
    except:
        if not silent:
            print("Could not read from " + path)
        return None

def alt_play(select_addon, db_type, iconimage, stream_file,viddetail):
    xbmcPlayer = xbmc.Player()
    #Open stream_file
    try:
        f = xbmcvfs.File(stream_file, 'r')
        r = f.read()
        f.close()
        currentaddon=regex_from_to(r,'plugin.video.','/')
    except:
        currentaddon="video"
        r=""
    try:currenttvdb=regex_from_to(r,'tvdb=','&')
    except:currenttvdb=""
    try:imdb=regex_from_to(r,'imdb=','&')
    except:imdb="n"
    try:currenttmdb=regex_from_to(r,'tmdb=','&')
    except:currenttmdb=""
    try:currenttvrage=regex_from_to(r,'tvrage=','&')
    except:currenttvrage=""
    alter='0'
    date=''
    vsplit=viddetail.split('<>')
    title=vsplit[0]
    season=vsplit[1]
    epnumber=vsplit[2]
    epname=vsplit[3]
    imdb=vsplit[4]
    year=vsplit[5]
    if db_type=='episode':
        SE = "S%.2dE%.2d" % (int(vsplit[1]), int(vsplit[2]))
    if currentaddon==select_addon:
        xbmcPlayer.play(stream_file)
    elif select_addon == 'program.super.favourites':
        xbmc.executebuiltin('ActivateWindow(%d,"plugin://%s/?mode=%d&keyword=%s")' % (10025,'plugin.program.super.favourites', 0, urllib.quote_plus(title)))
    elif select_addon == 'video.theroyalwe':
        if imdb=="":
            imdb="0"
        if db_type != 'episode':
            tmdbid=get_tmdb(imdb)
            xbmc.executebuiltin('ActivateWindow(%d,"plugin://%s/?imdb_id=%s&mode=get_movie_sources&title=%s&tmdb_id=%s&year=%s")' % (10025,'plugin.video.theroyalwe', urllib.quote(imdb),urllib.quote_plus(title),urllib.quote_plus(tmdbid), year))
        else:
            traktid=get_trakt(imdb,db_type)
            xbmc.executebuiltin('ActivateWindow(%d,"plugin://%s/?display=%s&episode=%s&imdb_id=%s&mode=get_episode_sources&season=%s&showtitle=%s&tmdb_id=0&trakt_id=%s&year=%s")' % (10025,'plugin.video.theroyalwe', urllib.quote(title),epnumber,imdb, season,urllib.quote(title),traktid,year))
    #,"video.velocity"
    elif select_addon == 'video.velocity':
        if imdb=="":
            imdb="0"
        if db_type != 'episode':
            xbmc.executebuiltin('ActivateWindow(%d,"plugin://%s/?media=movies&mode=findsource&movie_title=%s&name=%s&thumb=&trakt_id&url")' % (10025,'plugin.video.velocity', urllib.quote(title),urllib.quote(title + " (" + year + ")")))
        else:
            xbmc.executebuiltin('ActivateWindow(%d,"plugin://%s/?media=shows&mode=findsource&movie_title=%s&name=%s&thumb=&trakt_id&url")' % (10025,'plugin.video.velocity', urllib.quote(title + " (" + year + ")"),SE + " " + urllib.quote(epname)))
    else:
        data = "%s<>%s<>%s<>%s<>%s<>%s<>%s" % (viddetail,currenttvdb,imdb,currenttvrage,currenttmdb,alter,date)
        url=get_url(select_addon,db_type,data,iconimage)
        if url == ' not found':
            dialog.ok("Title Not Found", "Unable to find " + title + " using: " + select_addon, "Please try a different addon")
            return
        else:
            playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
            xbmcPlayer = xbmc.Player()
            playlist.clear()
            listitem = xbmcgui.ListItem(title, iconImage=iconimage, thumbnailImage=iconimage,path=url)
            playlist.add(url,listitem)
            xbmcPlayer.play(playlist)
		
			
def get_url(select_addon,db_type,data,iconimage):
    dsplit=data.split('<>')
    if db_type=='episode':
        SE = "S%.2dE%.2d" % (int(dsplit[1]), int(dsplit[2]))
    rootname=urllib.quote(dsplit[0] + ' ' + dsplit[5])
    if dsplit[4]=="":
        imdb=dsplit[7]
    else:
        imdb=dsplit[4]
    if db_type == 'movie':
        if select_addon == 'video.whatthefurk':#(
            url='plugin://plugin.video.whatthefurk/?name=%s&url=imdb&mode=1100&iconimage=%s&rootname=%s&imdb=%s&videotype=movies' % (rootname,urllib.quote(iconimage),rootname,imdb)
        if select_addon == 'video.genesis':
            url='plugin://plugin.video.genesis/?action=play&name=%s&title=%s&year=%s&imdb=%s&tmdb=' % (urllib.quote_plus(dsplit[0] + ' ' + dsplit[5]),urllib.quote_plus(title), urllib.quote(year), urllib.quote(imdb))
        if select_addon=='video.1channel':
            try:
                u=get_1channel_url(dsplit[0])
                url='plugin://plugin.video.1channel/?img=%s&title=%s&url=%s&imdbnum=&video_type=movie&mode=GetSources&dialog=1&year=%s' % (urllib.quote(iconimage),dsplit[0],urllib.quote(u),dsplit[5])
            except:
                url='not found'
        if select_addon == 'video.salts':####trakt id search
            if imdb=="":
                traktid=get_trakt(dsplit[0],db_type)
            else:
                traktid=get_trakt(imdb,db_type)
            url='plugin://plugin.video.salts/?title=%s&video_type=Movie&trakt_id=%s&mode=get_sources&dialog=True&year=%s' % (urllib.quote_plus(dsplit[0]),traktid,dsplit[5])
        if select_addon=='video.yifymovies.hd':
            try:
                u=get_yify_url(dsplit[0],dsplit[5])
                url='plugin://plugin.video.yifymovies.hd/?action=play&name=%s&url=%s' % (urllib.quote_plus(dsplit[0] + ' (' + dsplit[5] + ')'),urllib.quote(u))
            except:
                url='not found'
        if select_addon=='video.onlinemovies':
            #try:
            url=get_omp_url(dsplit[0],dsplit[5])
                #url='plugin://plugin.video.onlinemovies/?url=%s&site=None&mode=100&name%s' % (urllib.quote(u),urllib.quote_plus(dsplit[0] + ' (' + dsplit[5] + ')'))
            #except:
                #url='not found'
        if select_addon == 'video.theroyalwe':
            tmdbid=get_tmdb(imdb)
            url='plugin://plugin.video.theroyalwe/?imdb_id=%s&mode=get_movie_sources&title=%s&tmdb_id=%s&year=%s' % (urllib.quote(imdb),urllib.quote_plus(title),urllib.quote_plus(tmdbid), urllib.quote(year))
    elif db_type == 'episode':
        if select_addon == 'video.whatthefurk':#(
            data = '%s<|>%s<|>%s<|>%s' % (dsplit[0], dsplit[3], dsplit[1], dsplit[2])
            url='plugin://plugin.video.whatthefurk/?name=%s&url=%s&mode=1100&iconimage=%s&rootname=%s&imdb=%s&videotype=tvshows' % (urllib.quote(SE + ' ' + dsplit[3]),urllib.quote(data),urllib.quote(dsplit[0] + ' (' + dsplit[5] + ')'),urllib.quote(dsplit[0]),dsplit[7])
        if select_addon == 'video.genesis':
            gtitle="%s %s" % (dsplit[0],SE)
            url='plugin://plugin.video.genesis/?action=play&name=%s&title=%s&year=%s&imdb=%s&tmdb=&tvdb=&tvrage=&season=%s&episode=%s&tvshowtitle=%s&alter=0&date=' % (urllib.quote_plus(gtitle),urllib.quote_plus(epname), urllib.quote(year), urllib.quote(imdb), dsplit[1], dsplit[2], urllib.quote_plus(dsplit[0]))
        if select_addon=='video.1channel':
            try:
                u=get_1channel_url(dsplit[0])
                url='plugin://plugin.video.1channel/?img=&imdbnum=&url=%s/season-%s-episode-%s&title=%s&video_type=episode&mode=GetSources&dialog=1' % (urllib.quote(u),dsplit[1],dsplit[2],urllib.quote(dsplit[0]))
            except:
                url='not found'
        if select_addon == 'video.salts':
            if imdb=="":
                traktid=get_trakt(dsplit[0],db_type)
            else:
                traktid=get_trakt(imdb,db_type)
            url='plugin://plugin.video.salts/?ep_airdate=1970-01-01&trakt_id=%s&episode=%s&mode=get_sources&dialog=True&title=%s&ep_title=%s&season=%s&year=%s&video_type=Episode' % (traktid,dsplit[2],urllib.quote_plus(dsplit[0]),urllib.quote_plus(dsplit[3]),dsplit[1],dsplit[5])
        if select_addon == 'video.tv4me':
            gtitle="%s %s" % (dsplit[0],SE)#
            tv4meurl=get_tv4me_url(dsplit[0],int(dsplit[1]),int(dsplit[2]))
            url='plugin://plugin.video.tv4me/?name=%s&url=%s&mode=5&iconimage=%s&showname=%s' % (urllib.quote(gtitle),urllib.quote(tv4meurl),urllib.quote(iconimage),"")
    return url


def get_file_age(file_path):
    try:    
        stat = os.stat(file_path)
        fileage = datetime.fromtimestamp(stat.st_mtime)
        now = datetime.now()
        delta = now - fileage
        return delta.seconds
    except:
        return -1
	
if __name__ == '__main__':
    db_type = xbmc.getInfoLabel('ListItem.DBTYPE')
    addon_list_return=[]
    addon_list=[]
    count=-1
    if db_type=='movie':
        al = ["What the Furk","Genesis","1 Channel","SALTS","Yify Movies HD","iSearch (Super Favourites)","Online Movies Pro","The Royal We","Velocity"]
        alr = ["video.whatthefurk", "video.genesis", "video.1channel","video.salts","video.yifymovies.hd","program.super.favourites","video.onlinemovies","video.theroyalwe","video.velocity"]
        title = xbmc.getInfoLabel('ListItem.Title')
        season = ""
        epnumber = ""
        epname = ""
        imdb = xbmc.getInfoLabel('ListItem.IMDBNumber')
        year = xbmc.getInfoLabel('ListItem.Year')
        iconimage = xbmc.getInfoLabel('ListItem.Art(poster)')
    else:
        al = ["What the Furk","Genesis","1 Channel","SALTS","iSearch (Super Favourites)","TV4ME","The Royal We","Velocity"]
        alr = ["video.whatthefurk", "video.genesis", "video.1channel","video.salts","program.super.favourites","video.tv4me","video.theroyalwe","video.velocity"]
        title = xbmc.getInfoLabel('ListItem.TVShowTitle')
        season = xbmc.getInfoLabel('ListItem.Season')
        epnumber = xbmc.getInfoLabel('ListItem.Episode')
        epname = xbmc.getInfoLabel('ListItem.Title')
        imdb = xbmc.getInfoLabel('ListItem.IMDBNumber')
        year = xbmc.getInfoLabel('ListItem.Year')
        iconimage = xbmc.getInfoLabel('ListItem.Art(tvshow.poster)')
    viddetail="%s<>%s<>%s<>%s<>%s<>%s" % (title,season,epnumber,epname,imdb,year)
    stream_file = xbmc.getInfoLabel('ListItem.FileNameAndPath')
    print stream_file
    for a in alr:
        count+=1
        if os.path.exists(xbmc.translatePath("special://home/addons/plugin.%s") % a):
            addon_list_return.append(a)
            addon_list.append(al[count])
    if db_type=='movie' and RESTRICT_MOVIE=='true':
        addon_id=1
        select_addon = RESTRICT_MOVIE_SELECT
    elif db_type=='episode' and RESTRICT_TV=='true':
        addon_id=1
        select_addon = RESTRICT_TV_SELECT
    else:
        addon_id = dialog.select("Play using......", addon_list)
        select_addon = addon_list_return[addon_id]
    if addon_id>-1:
        alt_play(select_addon, db_type, iconimage, stream_file,viddetail)
		

	

