media.ccc.de for Kodi/XBMC
==========================

This is the official Kodi/XBMC plugin to browse content on media.ccc.de and
watch live streams from streaming.media.ccc.de.

The latest version should be available through Kodi's official plugin
repository: http://addons.kodi.tv/show/plugin.video.media-ccc-de/
