plugin.video.virginradio.it
==================

Kodi unofficial plugin for Virgin Radio Italia (tested on Kodi 15.1 Isengard).
