Paramount Vault
===============

Watch movies from the Paramount Vault, including classics like Masters of the Universe, Hamlet, Missing In Action and There Goes The Neighbourhood.

**PLEASE NOTE:** 
The content in this addon is geoblocked for viewership in only the United States. The YouTube plugin for Kodi is required to be installed to use this plugin.