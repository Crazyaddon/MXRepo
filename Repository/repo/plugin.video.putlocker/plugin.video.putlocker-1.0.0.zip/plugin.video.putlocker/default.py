#!/usr/bin/python
# -*- coding: latin-1 -*-
import xbmc,xbmcaddon, xbmcplugin
import xbmcgui
import sys
import urllib, urllib2
import time
import re
from htmlentitydefs import name2codepoint as n2cp
import httplib
import urlparse
from os import path, system
import socket
from urllib2 import Request, URLError, urlopen
from urlparse import parse_qs
from urllib import unquote_plus

thisPlugin = int(sys.argv[1])
addonId = "plugin.video.putlocker"
adn = xbmcaddon.Addon('plugin.video.1channel')
Host = "http://putlocker.is/"
pass#print "Host =", Host
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
if not path.exists(dataPath):
       cmd = "mkdir -p " + dataPath
       system(cmd)

def getUrl(url):
        pass#print "Here in getUrl url =", url
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link
	
def showContent():
        names = []
        urls = []
        modes = []
        names.append("TV Shows")
        names.append("Movie Genres")
        urls.append("http://putlocker.is/tv")
        urls.append(Host)
        modes.append("3")
        modes.append("1")
        i1 = 0           
        while i1 < 2:
                for name in names:
                        pic = " "
                        url = urls[i1]
                        mode = modes[i1]
                        i1 = i1+1
                        ##pass#print "Here in Showcontent url1 =", url1
                        addDirectoryItem(name, {"name":name, "url":url, "mode":mode}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)

def showContent2(name, url):
                content = getUrl(url)
	        pass#print "content A=", content
                regexcat = 'http://putlocker\.is/genre/(.*?)/.*?>(.*?)<'
                match = re.compile(regexcat,re.DOTALL).findall(content)
                pass#print "match =", match
                for url, name in match:
                        pic = " "
                        url1 = 'http://putlocker.is/genre/' + url
                        ##pass#print "Here in Showcontent url1 =", url1
                        addDirectoryItem(name, {"name":name, "url":url1, "mode":2}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)
                
#https://putlocker.unblocked.pw/genre/action/                
#https://putlocker.unblocked.pw/genre/action/3                            
def getPage(name, url):
                pages = [1, 2, 3, 4, 5, 6]
                pass#print "In getPage name A=", name
                pass#print "In getPage url A=", url
                for page in pages:
                        url1 = url + "/" + str(page)
                        name1 = name + " - Page " + str(page)
                        pic = " "
                        addDirectoryItem(name1, {"name":name1, "url":url1, "mode":3}, pic)       
                xbmcplugin.endOfDirectory(thisPlugin)

def getVideos(name, url):
                f = open("/tmp/xbmc_search.txt", "r")
                icount = 0
                for line in f.readlines(): 
                    sline = line
                    icount = icount+1
                    if icount > 0:
                           break

                name = sline.replace(" ", "+")
                url1 = Hostmain + "/index.php?search_keywords=" + name
                pages = [1, 2, 3]
                for page in pages:
                        url = url1 + "&page=" + str(page)
                        pass#print "Here in getVideos2 url =", url
                        name = "Page " + str(page)
                        pic = " "
                        addDirectoryItem(name, {"name":name, "url":url, "mode":31}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)

        
def getVideos2(name, urlmain):
	content = getUrl(urlmain)
	pass#print "content B =", content
	if "Shows" in name: mode = 31
	else: mode = 4
	names = []
	urls = []
	pics = []
	start = 0
        i1 = 0
        while i1 < 50:
	       n1 = content.find('style="padding-top', start)
	       pass#print "Here in getVideos pass#print n1=", n1
	       if n1<0: break
	       n2 = content.find('href="', n1)
	       pass#print "Here in getVideos pass#print n2=", n2
	       if n2<0: break
	       n3 = content.find('" title="', n2)
	       pass#print "Here in getVideos pass#print n3=", n3
	       if n3<0: break
	       n4 = content.find('"><img src="', n3)
	       pass#print "Here in getVideos pass#print n4=", n4
	       if n4<0: break
	       n5 = content.find('"', (n4+14))
	       pass#print "Here in getVideos pass#print n5=", n5
	       if n5<0: break
	       url = content[(n2+6):n3] 
	       name = content[(n3+9):n4]
	       pic = content[(n4+12):n5]
#	regexvideo = 'style="padding-top.*?;"><a href="(.*?)" title="(.*?))"><img src="(.*?)"'
#	match = re.compile(regexvideo,re.DOTALL).findall(content)
#        pass#print "In getVideos2 match =", match
#        for url, name, pic in match:
#                 url1 = url
               pass#print "Here in getVideos url =", url
               start = n5
               i1 = i1+1  
	       addDirectoryItem(name, {"name":name, "url":url, "mode":mode}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)
                
def getVideos21(name1, urlmain):
	content = getUrl(urlmain)
	pass#print "content B21 =", content
	regexvideo = 'td class="entry"><img src="(.*?)".*?width="100%" class="entry"><a href="(.*?)" title="(.*?)"'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "In getVideos21 match =", match
        for pic, url, name in match:
                 pass#print "Here in getVideos21 url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":4}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)
                

def getVideos3(name1, urlmain):
	content = getUrl(urlmain)
	pass#print "In getVideos3 content B =", content
        n1 = content.find("Alternative Versions</h2>")
        n2 = content.find("</table><h2 style=")
        content = content[n1:n2]
        regexvideo = 'href="(.*?)"'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "In getVideos match =", match
        urlLast = " "
        for url in match:
                  pic = " "
                  if url == urlLast: continue
                  urlLast = url
                  if "vodlocker" in url:
                          name = "Vodlocker"
                  elif "vidbull" in url:
                          name = "Vidbull"
                  elif "nowvideo" in url:
                          name = "Nowvideo"
                  elif "vidto" in url:
                          name = "Vidto"
                  else:
                          continue        
                 ##pass#print "Here in getVideos url =", url
	          addDirectoryItem(name, {"name":name, "url":url, "mode":5}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)   
        
               
    
def getVideos3X(name1, urlmain):
	content = getUrl(urlmain)
	pass#print "In getVideos3 content B =", content
	regexvideo = '<a href="/external.php?(.*?)".*?document.writeln(.*?);<'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "In getVideos3 match =", match
        for url, name in match:
            if ("divxstage" in name) or ("nowvideo" in name) or ("vodlocker" in name) or ("vidbull" in name) or ("vidto" in name) :
                 name = name.replace('(', '')
                 name = name.replace(')', '')
                 name = name.replace("'", "")
                 url = Hostmain + "/external.php?" + url
                 pic = " " 
                 pass#print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":5}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)
        
def LINKS(name, murl):
        import urlresolver
        pass#print "movie25 PUTLINKS name =", name
        pass#print "movie25 PUTLINKS murl D =", murl
###        get_stream_link().check_link(murl, got_link, False)
        stream_url = urlresolver.HostedMediaFile(url=murl).resolve()
        got_link(stream_url)

def got_link(stream_url):
        pass#print "got_link stream_url =", stream_url
        if stream_url:
                    xbmc.executebuiltin("XBMC.Notification(Please Wait!,Resolving Link,3000)")
                    img = " "
                    name = " "
                    listitem = xbmcgui.ListItem(name, iconImage=img, thumbnailImage=img)
#                    stream_url = source.resolve()
                    pass#print "movie25-py stream_url =", stream_url
                    listitem.setPath(stream_url)
                    playfile = xbmc.Player()
#                    stream_url = "*download*" + stream_url
                    pass#print "movie25-py stream_url B=", stream_url
                    playfile.play(stream_url, listitem)
        else:
                  stream_url = False
                  return
        
        
        
def getVideos4(name, urlmain):        
     content = getUrl(urlmain)
     pass#print "In getVideos4 content B =", content
     if "divxstage.to" in content:
	n1 = content.find('<div class="embed_opt">', 0)
	if n1<0:
	       return
	n2 = content.find('<script', n1)
	if n2<0:
	       return
	n3 = content.find('</script>', n2)
	if n3<0:
	       return       
	content = content[n2:n3]
	regexvideo = "width:(.*?); height:(.*?)' src='(.*?)'"
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "In getVideos4 match =", match
        for name1, name2, url in match:
                 name = name1 + "x" + name2
                 pic = " "
                 pass#print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":12}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)   

     elif "NowVideo" in content:   
        regexvideo = 'input id="direct_link.*?value="(.*?)"'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "In getVideos match =", match 
        url = match[0]
        LINKS(name, url)                    

     elif "vidbull.com" in content:   
        regexvideo = 'h2>Download Link</h2>.*?copy.*?>(.*?)<'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "In getVideos match =", match 
        url = match[0]
        LINKS(name, url)                    

     elif "vodlocker.com" in content:   
#        url = "http://vodlocker.com/z850v1gfe4hd"
        regexvideo = 'name="id" value="(.*?)"'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "In getVideos match =", match 
        id = match[0]
        url = "http://vodlocker.com/" + id
        pass#print "vod url =", url
        LINKS(name, url)                   

     elif "vidto.me" in content:   
#        url = "http://vidto.me/m2yj6o1ccpd1.html"
        regexvideo = 'name="id" value="(.*?)"'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "In getVideos match =", match 
        id = match[0]
        url = "http://vidto.me/" + id + ".html"
        LINKS(name, url)   

     elif "vodlockerX.com" in content:
        url = "http://www.movshare.net/video/4975c9e90835f"
        LINKS(name, url) 
        
def getVideos11(name, url):
        pass#print "In getVideos11 url =", url
        LINKS(name, url)  
        
def getVideos5(name1, urlmain):
	content = getUrl(urlmain)
	pass#print "In getVideos5 content B =", content
	n1 = content.find('class="opener-menu-genre', 0)
	if n1<0:
	       return
	n2 = content.find('class="clearer">', n1)
	if n2<0:
	       return
	n3 = content.find('<div class="pagination">', n2)
	if n3<0:
	       return       
	content = content[n2:n3]
	
	regexvideo = 'item_categories"><a href="(.*?)">(.*?)<'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "In getVideos match =", match
        for url, name in match:
                 name1 = "All-Movies-" + name
                 url = Host + url
                 pic = " "
                 pass#print "Here in getVideos url =", url
	         addDirectoryItem(name1, {"name":name1, "url":url, "mode":2}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)        
                     
def getVideos6(name1, urlmain):
	content = getUrl(urlmain)
	pass#print "In getVideos content D =", content
	n1 = content.find("<strong>Just Added</strong>", 0)
	if n1<0:
	       return
	n2 = content.find('class="clearer">', n1)
	if n2<0:
	       return
	n3 = content.find('<div class="pagination">', n2)
	if n3<0:
	       return       
	content = content[n2:n3]
	
	regexvideo = 'index_item index_item_ie"><a href="(.*?)" title="(.*?)"><img src=.*?imagesp(.*?)"'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "In getVideos match =", match
        for url, name, pic in match:
                 url = Hostmain + url
                 ##pass#print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":4}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)
                
def getVideos7(name1, urlmain):
	content = getUrl(urlmain)
	pass#print "In getVideos7 content E =", content
	n1 = content.find('span> TV Shows > <strong>', 0)
	if n1<0:
	       return
	n2 = content.find('class="clearer">', n1)
	if n2<0:
	       return
	n3 = content.find('<div class="pagination">', n2)
	if n3<0:
	       return       
	content = content[n2:n3]
	
	regexvideo = 'item_categories"><a href="(.*?)">(.*?)<'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "getVideos7 match =", match
        for url, name in match:
                 name1 = "TV-" + name
                 url = url.replace("/", "/index.php")
                 url = Hostmain + url
                 pic = " "
	         addDirectoryItem(name1, {"name":name1, "url":url, "mode":2}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)        
                            
def getVideos8(name1, urlmain):
	content = getUrl(urlmain)
	pass#print "In getVideos8 content E =", content
	n1 = content.find('class="opener-menu', 0)
	if n1<0:
	       return
	n2 = content.find('class="clearer">', n1)
	if n2<0:
	       return
	n3 = content.find('<div class="pagination">', n2)
	if n3<0:
	       n3 = content.find('<div class=clearer></div>', (n2+5))      
	content = content[n2:n3]
	
	regexvideo = 'index_item index_item_ie"><a href="(.*?)" title="(.*?)"'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "In getVideos8 match =", match
        for url, name in match:
                 url = Hostmain + url
                 name = name.replace("Watch", "")
                 pic = " "
                 pass#print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":10}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)        
                            

def getVideos9(name1, urlmain):
	content = getUrl(urlmain)
	pass#print "In getVideos9 content F =", content
		
	regexvideo = 'div class="tv_episode_item.*?a href="(.*?)".*?name">(.*?)<'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "In getVideos9 match =", match
        for url, name in match:
                 ln = len(url)
                 n1 = url.rfind("/",0, ln)
                 nam = url[(n1+1):]
                 name = nam + "-" + name 
                 name = name.replace("season", "s")
                 name = name.replace("episode", "ep")       
                 url = Hostmain + url
                 pic = " "
                 pass#print "Here in getVideos9 url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":4}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)        
                            
def getVideos10(name1, urlmain):
	content = getUrl(urlmain)
	pass#print "In getVideos10 content G =", content
		
	regexvideo = '<a data-id.*?a href="(.*?)".*?Season(.*?)<'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "In getVideos9 match =", match
        for url, name in match:
                 url = Hostmain + url
                 pic = " "
                 pass#print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":11}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)        
                            
def getVideos12(name1, urlmain):
                f = open("/tmp/xbmc_search.txt", "r")
                icount = 0
                for line in f.readlines(): 
                    sline = line
                    icount = icount+1
                    if icount > 0:
                           break

                name = sline.replace(" ", "+")
                url1 = Hostmain + "/index.php?search_keywords=" + name
                pages = [1, 2, 3]
                for page in pages:
                        url = url1 + "&page=" + str(page)
                        pass#print "Here in getVideos2 url =", url
                        name = "Page " + str(page)
                        pic = " "
                        addDirectoryItem(name, {"name":name, "url":url, "mode":9}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)


                
def playVideo(name, url):
           #pass#print "Here in playVideo url =", url
           fpage = getUrl(url)
	   #pass#print "fpage C =", fpage
           start = 0
           pos1 = fpage.find(".flv", start)
           if (pos1 < 0):
                           return
  	   pos2 = fpage.find("a href", pos1)
 	   if (pos2 < 0):
                           return
           pos3 = fpage.find('"', (pos2+10))
 	   if (pos3 < 0):
                           return                
           url = fpage[(pos2+8):pos3]
                    
           pic = "DefaultFolder.png"
           pass#print "Here in playVideo url B=", url
           li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
           player = xbmc.Player()
           player.play(url, li)

std_headers = {
	'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
	'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'en-us,en;q=0.5',
}  

def addDirectoryItem(name, parameters={},pic=""):
    li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
    url = sys.argv[0] + '?' + urllib.urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)


def parameters_string_to_dict(parameters):
    ''' Convert parameters encoded in a URL to a dict. '''
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict

params = parameters_string_to_dict(sys.argv[2])
name =  str(params.get("name", ""))
url =  str(params.get("url", ""))
url = urllib.unquote(url)
mode =  str(params.get("mode", ""))

if not sys.argv[2]:
	ok = showContent()
else:
        if mode == str(1):
                ok = showContent2(name, url)
	elif mode == str(2):
	        ok = getPage(name, url)	
        elif mode == str(3):
		ok = getVideos2(name, url)
	elif mode == str(31):
		ok = getVideos21(name, url)	
        elif mode == str(4):
		ok = getVideos3(name, url)	        	
        elif mode == str(5):
		ok = LINKS(name, url)
        elif mode == str(6):
		ok = getVideos5(name, url)
        elif mode == str(7):
		ok = getVideos6(name, url)
        elif mode == str(8):
		ok = getVideos7(name, url)
        elif mode == str(9):
		ok = getVideos8(name, url)
        elif mode == str(10):
		ok = getVideos9(name, url)
        elif mode == str(11):
		ok = getVideos10(name, url)
        elif mode == str(12):
		ok = getVideos11(name, url)
        elif mode == str(13):
		ok = getVideos12(name, url)






























