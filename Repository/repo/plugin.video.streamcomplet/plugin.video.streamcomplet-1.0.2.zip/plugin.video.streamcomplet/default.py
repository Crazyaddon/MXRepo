#!/usr/bin/python
# -*- coding: latin-1 -*-

import xbmc,xbmcplugin
import xbmcgui
import sys
import urllib, urllib2
import time
import re
from htmlentitydefs import name2codepoint as n2cp
import httplib
import urlparse
from os import path, system
import socket
from urllib2 import Request, URLError, urlopen
from urlparse import parse_qs
from urllib import unquote_plus



thisPlugin = int(sys.argv[1])
addonId = "plugin.video.streamcomplet"
dataPath = xbmc.translatePath('special://profile/addon_data/%s' % (addonId))
if not path.exists(dataPath):
       cmd = "mkdir -p " + dataPath
       system(cmd)
       
Host = "http://streamcomplet.biz/"

def getUrl(url):
        pass#print "Here in getUrl url =", url
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link

def getUrl2(url, referer):
        pass#print "Here in getUrl url =", url
	req = urllib2.Request(url)
	req.add_header('User-Agent', 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
        req.add_header('Referer', referer)
	response = urllib2.urlopen(req)
	link=response.read()
	response.close()
	return link	

def showContent():
        content = getUrl(Host)
        pass#print "content A =", content
        n1 = content.find('class="top-node" title="Films par genre', 0)
        n2 = content.find('<li aria-haspopup="true">', n1)
        content = content[n1:n2]
             
        i1 = 0           
        if i1 == 0:
                regexcat = 'a href="(.*?)">(.*?)<'
                match = re.compile(regexcat,re.DOTALL).findall(content)
                pass#print "match =", match
                for url, name in match:
                        pic = " "
                        url1 = Host + url
                        ##pass#print "Here in Showcontent url1 =", url1
                        addDirectoryItem(name, {"name":name, "url":url1, "mode":1}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)

#http://en.luxuretv.com/channels/55/amateurs/page3.html
def getPage(name, url):
                pages = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
                for page in pages:
                        url1 = url + "page/" + str(page) + "/"
                        name = "Page " + str(page)
                        pic = " "
                        addDirectoryItem(name, {"name":name, "url":url1, "mode":2}, pic)
                xbmcplugin.endOfDirectory(thisPlugin)

def getVideos(name1, urlmain):
	content = getUrl(urlmain)
	pass#print "content B =", content

        regexvideo = 'div class="movie movie-block.*?g src="(.*?)" alt="(.*?)".*?window.location.href=\'(.*?)\''
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "match =", match
        for pic, name, url in match:
                 name = name.replace('"', '')
                 ##pass#print "Here in getVideos url =", url
	         addDirectoryItem(name, {"name":name, "url":url, "mode":3}, pic)
        xbmcplugin.endOfDirectory(thisPlugin)	         


def getVideos2(name1, urlmain):
	content = getUrl(urlmain)
	pass#print "content BB =", content
        regexvideo = 'youtube.*?watch(.*?)"'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
	pass#print "match =", match
	if len(match) > 0: 
                 url = "https://www.youtube.com/watch" + match[0]
                 name = "Youtube preview"
                 pic = " "
                 pass#print "url A =", url
                 addDirectoryItem(name, {"name":name, "url":url, "mode":5}, pic)
        regexvideo = 'IFRAME SRC=".*?exashare(.*?)"'
	match2 = re.compile(regexvideo,re.DOTALL).findall(content)
	pass#print "match2 =", match2
        if len(match2) > 0: 
	         url = "http://www.exashare" + match2[0]
                 name = "Exashare"
                 pic = " "
                 pass#print "url B =", url
                 addDirectoryItem(name, {"name":name, "url":url, "mode":6}, pic)
                 
        regexvideo = 'src="http://stream-the.net(.*?)"'
	match = re.compile(regexvideo,re.DOTALL).findall(content)
        pass#print "match =", match
        n1 = 0
        for url in match:
                 if "ba.php" in url:
                       continue
                 url = "http://stream-the.net" + url
                 content2 = getUrl2(url, urlmain)
                 pass#print "content2 =", content2
                 regexvideo = 'file: "(.*?)".*?label: "(.*?)"'
	         match2 = re.compile(regexvideo,re.DOTALL).findall(content2)
	         pass#print "match2 =", match2
                 for url1, name in match2:
                       url1 = url1.replace("\\", "")
                       pass#print "Here in getVideos name =", name
                       pass#print "Here in getVideos url1 =", url1
                       pic = " "
                       addDirectoryItem(name, {"name":name, "url":url1, "mode":4}, pic)
#                 if n1 == 0:
#                       break      
        xbmcplugin.endOfDirectory(thisPlugin)
        
      
        
def getVideos3(name, urlmain):
        LINKS(name, urlmain)
        
def LINKS(name, murl):
        import urlresolver
        pass#pass#print "movie25 PUTLINKS url =", url
        pass#pass#print "movie25 PUTLINKS name =", name
        pass#print "movie25 PUTLINKS murl D =", murl
###        get_stream_link().check_link(murl, got_link, False)
        stream_url = urlresolver.HostedMediaFile(url=murl).resolve()
        got_link(stream_url)

def got_link(stream_url):
        pass#pass#print "got_link stream_url =", stream_url
        if stream_url:
                    xbmc.executebuiltin("XBMC.Notification(Please Wait!,Resolving Link,3000)")
                    img = " "
                    name = " "
                    listitem = xbmcgui.ListItem(name, iconImage=img, thumbnailImage=img)
#                    stream_url = source.resolve()
                    pass#pass#print "movie25-py stream_url =", stream_url
                    listitem.setPath(stream_url)
                    playfile = xbmc.Player()
#                    stream_url = "*download*" + stream_url
                    pass#pass#print "movie25-py stream_url B=", stream_url
                    playfile.play(stream_url, listitem)
        else:
                  stream_url = False
                  return
        
        
        
        	         
                
def playVideo(name, url):
           pic = "DefaultFolder.png"
           pass#print "Here in playVideo url B=", url
           li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
           player = xbmc.Player()
           player.play(url, li)
           
def playVideo2(name, url):           
        import YDStreamExtractor
        YDStreamExtractor.disableDASHVideo(True) #Kodi (XBMC) only plays the video for DASH streams, so you don't want these normally. Of course these are the only 1080p streams on YouTube
#        url = "https://www.youtube.com/watch?v=" + url #a youtube ID will work as well and of course you could pass the url of another site
        vid = YDStreamExtractor.getVideoInfo(url,quality=1) #quality is 0=SD, 1=720p, 2=1080p and is a maximum
        stream_url = vid.streamURL() #This is what Kodi (XBMC) will play
        pass#print "stream_url =", stream_url
        img = " "
        playfile = xbmc.Player()
        playfile.play(stream_url)

def playVideo3(name, url):           
               pass#print "In getVideos4 exashare url =", url
               content2 = getUrl(url)
               pass#print "In getVideos4 content2 =", content2
               pass#print "In getVideos4 youwatch content2 =", content2
               regexvideo = 'src="(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content2)
	       url = match[0]
	       content3 = getUrl2(url, url)
               pass#print "In getVideos4 youwatch content3 =", content3
               regexvideo = 'file: "(.*?)"'
	       match = re.compile(regexvideo,re.DOTALL).findall(content3)
	       vidurl = match[0]
               playfile = xbmc.Player()
               playfile.play(vidurl)          
               
std_headers = {
	'User-Agent': 'Mozilla/5.0 (X11; U; Linux x86_64; en-US; rv:1.9.2.6) Gecko/20100627 Firefox/3.6.6',
	'Accept-Charset': 'ISO-8859-1,utf-8;q=0.7,*;q=0.7',
	'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
	'Accept-Language': 'en-us,en;q=0.5',
}  

def addDirectoryItem(name, parameters={},pic=""):
    li = xbmcgui.ListItem(name,iconImage="DefaultFolder.png", thumbnailImage=pic)
    url = sys.argv[0] + '?' + urllib.urlencode(parameters)
    return xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=url, listitem=li, isFolder=True)


def parameters_string_to_dict(parameters):
    ''' Convert parameters encoded in a URL to a dict. '''
    paramDict = {}
    if parameters:
        paramPairs = parameters[1:].split("&")
        for paramsPair in paramPairs:
            paramSplits = paramsPair.split('=')
            if (len(paramSplits)) == 2:
                paramDict[paramSplits[0]] = paramSplits[1]
    return paramDict

params = parameters_string_to_dict(sys.argv[2])
name =  str(params.get("name", ""))
url =  str(params.get("url", ""))
url = urllib.unquote(url)
mode =  str(params.get("mode", ""))

if not sys.argv[2]:
	ok = showContent()
else:
        if mode == str(1):
		ok = getPage(name, url)
	elif mode == str(2):
		ok = getVideos(name, url)	
	elif mode == str(3):
                ok = getVideos2(name, url)
	elif mode == str(4):
                ok = playVideo(name, url)                
	elif mode == str(5):
                ok = playVideo2(name, url)                
	elif mode == str(6):
                ok = playVideo3(name, url)                



































