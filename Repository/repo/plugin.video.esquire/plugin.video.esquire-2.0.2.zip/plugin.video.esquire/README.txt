plugin.video.esquire
================

Kodi Addon for Esquire TV website
for Kodi Isengard and later

Version 2.0.2 cleanup for release
Version 2.0.1 initial v2 release

