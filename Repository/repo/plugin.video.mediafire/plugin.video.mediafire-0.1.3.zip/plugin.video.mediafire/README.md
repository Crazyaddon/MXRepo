KODI-MediaFire
==============

A MediaFire Video/Music add-on for Kodi / XBMC
