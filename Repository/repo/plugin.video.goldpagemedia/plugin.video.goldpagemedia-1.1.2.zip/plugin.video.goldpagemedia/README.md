plugin.video.goldpagemedia
==========================

This is video plugin used for XBMC