plugin.video.lacosa
=============

Kodi unofficial plugin for La Cosa (tested on Kodi 15.2 Isengard).
